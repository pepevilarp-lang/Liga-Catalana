'use strict';
/* =========================================================
   POLO A, LLIGA CATALANA 2026-27
   Fuentes oficiales: calendario FCT (grupo 4622), plantilla del capitán,
   clasificación FCT tras la J1.
   Formato: cada eliminatoria la juegan 4 jugadores en 4 individuales.
   Si quedan 2-2 se juega un dobles decisivo. Partidos a dos sets;
   con un set cada uno, tercer set.
   ========================================================= */
const SEASON_ID = '2026-27';
let SEASON_PATH = 'seasons/' + SEASON_ID;
let viewSeason = SEASON_ID;
const POLO = 'polo';
const COMP = { name:'13a Lliga Catalana Absolut i Sènior per Equips', group:'Absolut masculino, Barcelona, Divisió 1', memorial:'Memorial Carlos Punzano' };

const TEAMS0 = [
  {id:'polo',      name:'RC de Polo',            short:'Polo',            abbr:'RCP'},
  {id:'masram',    name:'CE Mas-Ram',            short:'Mas-Ram',         abbr:'MR'},
  {id:'pompeia',   name:'RST Pompeia',           short:'Pompeia',         abbr:'RSTP'},
  {id:'turo',      name:'Club Turò David Lloyd', short:'Turò David Lloyd',abbr:'TDL'},
  {id:'vallparc',  name:'CT Vall Parc',          short:'Vall Parc',       abbr:'VP'},
  {id:'vallhebron',name:"Vall d'Hebron",         short:"Vall d'Hebron",   abbr:'VH'},
  {id:'rctb',      name:'RCT Barcelona-1899',    short:'Barcelona-1899',  abbr:'RCTB'}
];
const FIX0 = [
 [1,'2026-10-17','turo','vallparc',4,1],[1,'2026-10-17','pompeia','polo',5,0],[1,'2026-10-17','masram','vallhebron',4,1],
 [2,'2026-10-31','polo','masram'],[2,'2026-10-31','vallparc','pompeia'],[2,'2026-10-31','rctb','turo'],
 [3,'2026-11-07','pompeia','rctb'],[3,'2026-11-07','masram','vallparc'],[3,'2026-11-07','vallhebron','polo'],
 [4,'2026-11-21','vallparc','vallhebron'],[4,'2026-11-21','rctb','masram'],[4,'2026-11-21','turo','pompeia'],
 [5,'2026-12-12','masram','turo'],[5,'2026-12-12','vallhebron','rctb'],[5,'2026-12-12','polo','vallparc'],
 [6,'2026-12-19','rctb','polo'],[6,'2026-12-19','turo','vallhebron'],[6,'2026-12-19','pompeia','masram'],
 [7,'2027-01-09','vallhebron','pompeia'],[7,'2027-01-09','polo','turo'],[7,'2027-01-09','vallparc','rctb'],
 [8,'2027-01-16','vallparc','turo'],[8,'2027-01-16','polo','pompeia'],[8,'2027-01-16','vallhebron','masram'],
 [9,'2027-01-30','masram','polo'],[9,'2027-01-30','pompeia','vallparc'],[9,'2027-01-30','turo','rctb'],
 [10,'2027-02-13','rctb','pompeia'],[10,'2027-02-13','vallparc','masram'],[10,'2027-02-13','polo','vallhebron'],
 [11,'2027-02-27','vallhebron','vallparc'],[11,'2027-02-27','masram','rctb'],[11,'2027-02-27','pompeia','turo'],
 [12,'2027-03-13','turo','masram'],[12,'2027-03-13','rctb','vallhebron'],[12,'2027-03-13','vallparc','polo'],
 [13,'2027-04-03','polo','rctb'],[13,'2027-04-03','vallhebron','turo'],[13,'2027-04-03','masram','pompeia'],
 [14,'2027-04-10','pompeia','vallhebron'],[14,'2027-04-10','turo','polo'],[14,'2027-04-10','rctb','vallparc']
];
const PLAYERS0 = [
 [1,'Joan Villaseca Sitjar','Joan Villaseca','Absolut',184],[2,'Alvaro Dagoberto Garcia Ramírez','Alvaro Garcia','Absolut',182],
 [3,'Ignacio Corbat Duffo','Ignacio Corbat','Sènior +35',147],[4,'Carlos Rovira Arazuri','Carlos Rovira','Sènior +25',143],
 [5,'Marc Huet Franquet','Marc Huet','Absolut',104],[6,'Carlos Miarnau Pascual','Carlos Miarnau','Sènior +30',54],
 [7,'Carlos Casacuberta Bausili','Carlos Casacuberta','Sènior +35',46],[8,'Alejandro Sanjuan Gancedo','Alejandro Sanjuan','Sènior +30',45],
 [9,'Carlos Franco Alavedra','Carlos Franco','Absolut',41],[10,'Ignacio Velasco Piera','Ignacio Velasco','Sènior +30',40],
 [11,'Pepe Vilar Prat','Pepe Vilar','Absolut',30],[12,'Ricardo Manen De Yzaguirre','Ricardo Manen','Sènior +25',23],
 [13,'Pablo Bosch Garcia','Pablo Bosch','Sènior +30',13],[14,'Pablo Manen De Yzaguirre','Pablo Manen','Sènior +25',10],
 [15,'Ignacio Viola Perez','Ignacio Viola','Sènior +35',3],[16,'Erik Roig Cortasa','Erik Roig','Absolut',1],
 [17,'Pau Masana Preciado','Pau Masana','Sènior +30',0],[18,'Javier Oliver Tarre','Javier Oliver','Sènior +25',0],
 [19,'Antonio Mañas Vilaclara','Antonio Mañas','Sènior +30',0]
];
const slug = s => s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const RUBBERS = [{n:1,type:'S',label:'Individual 1'},{n:2,type:'S',label:'Individual 2'},{n:3,type:'S',label:'Individual 3'},{n:4,type:'S',label:'Individual 4'},{n:5,type:'D',label:'Dobles decisivo'}];

const DEFAULT_Q = [
 {id:'q_jornada',   scope:'team', type:'scale',  text:'¿Cómo valorarías la jornada del equipo?'},
 {id:'q_destacado', scope:'peer', type:'player', text:'¿Qué jugador ha sido el más destacado?'},
 {id:'q_actitud',   scope:'peer', type:'player', text:'¿Quién ha tenido la mejor actitud competitiva?'},
 {id:'q_sorpresa',  scope:'peer', type:'player', text:'¿Quién ha sorprendido más?'},
 {id:'q_determinante',scope:'peer',type:'player',text:'¿Quién ha sido el más determinante?'},
 {id:'q_sufrido',   scope:'peer', type:'player', text:'¿Quién ha sufrido más?'},
 {id:'q_momento',   scope:'peer', type:'player', text:'¿Quién ha protagonizado el mejor momento?'},
 {id:'q_companero', scope:'peer', type:'player', text:'¿Quién ha sido el mejor compañero?'},
 {id:'q_ambiente',  scope:'team', type:'scale',  text:'¿Qué nota le das al ambiente del equipo?'},
 {id:'s_rend',      scope:'self', type:'scale',  text:'¿Cómo valorarías tu propio rendimiento?'},
 {id:'s_fisico',    scope:'self', type:'scale',  text:'¿Cómo te has sentido físicamente?'},
 {id:'s_conc',      scope:'self', type:'scale',  text:'¿Cómo valorarías tu nivel de concentración?'},
 {id:'s_actitud',   scope:'self', type:'scale',  text:'¿Cómo valorarías tu actitud competitiva?'},
 {id:'s_mejor',     scope:'self', type:'text',   text:'¿Qué crees que has hecho mejor?'},
 {id:'s_mejorar',   scope:'self', type:'text',   text:'¿Qué deberías mejorar para la próxima jornada?'},
 {id:'o_anecdota',  scope:'open', type:'text',   text:'Una anécdota o un momento de la jornada'}
];
const DEFAULT_MSGS = {
  req: '¡Buenas equipo! 🎾\n\nTenemos eliminatoria contra {rival} el próximo {fecha} a las {hora} ({lugar}).\n\nNecesitamos saber quién está disponible para organizar la convocatoria.\n\nPor favor, responded a través de este enlace antes del {limite}:\n\n{enlace}\n\n¡Vamos Polo!',
  rem: 'Recordatorio 🎾\n\nAún nos falta saber si podéis jugar contra {rival} el {fecha} a las {hora}: {pendientes}.\n\nResponded antes del {limite} aquí:\n{enlace}\n\n¡Gracias!',
  remOne: '¡Hola {nombre}! 🎾 ¿Puedes jugar contra {rival} el {fecha} a las {hora}? Responde antes del {limite} aquí: {enlace}',
  lineup: '📋 Convocatoria jornada {jornada}\n\nPolo contra {rival}, {fecha} a las {hora} ({lugar}).\n\n{lista}\n\nTodo en la app: {enlaceJornada}\n\n¡Vamos Polo!'
};
const AV_LABEL = {yes:'Disponible', no:'No disponible', maybe:'Pendiente de confirmar', none:'Sin respuesta'};
const AV_CHIPS = ['Puedo jugar, pero solo a partir de las 12:00','Tengo molestias','Estoy pendiente de confirmar','Puedo jugar individual o dobles','Prefiero dobles','Llego justo de tiempo'];
const SCOPE_LABEL = {team:'Sobre el equipo', peer:'Sobre tus compañeros', self:'Sobre ti (privado)', open:'Comentarios (privado)'};
const SELF_DIMS = [['s_rend','Rendimiento'],['s_fisico','Estado físico'],['s_conc','Concentración'],['s_actitud','Actitud']];

function seed(){
  return {
    seasonId: SEASON_ID,
    comp: {...COMP},
    rules: {win:3, loss:1, availDays:6, deadlineDays:2, deadlineTime:'21:00'},
    msgs: {...DEFAULT_MSGS},
    teams: TEAMS0.map(t=>({...t})),
    players: PLAYERS0.map(([o,full,short,cat,pts])=>({id:slug(short), order:o, full, name:short, cat, pts, captain: short==='Pablo Bosch', active:true})),
    fixtures: FIX0.map(([j,date,home,away,hs,as])=>({j,date,time:'15:00',home,away,hs:hs??null,as:as??null})),
    ties: {},
    survey: {closed:{}, questions: DEFAULT_Q.map(q=>({...q}))},
    published: {},
    official: {asOf:1, order:['masram','pompeia','turo','vallparc','polo','vallhebron','rctb']},
    updatedAt: null
  };
}
function normalize(d){
  const s=seed(); if(!d||typeof d!=='object') return s;
  const o={...s,...d}; o.rules={...s.rules,...(d.rules||{})}; o.survey={...s.survey,...(d.survey||{})};
  o.comp={...s.comp,...(d.comp||{})}; o.msgs={...s.msgs,...(d.msgs||{})};
  if(!o.survey.closed) o.survey.closed={};
  if(!Array.isArray(o.survey.questions)||!o.survey.questions.length) o.survey.questions=s.survey.questions;
  for(const k of ['teams','players','fixtures']) if(!Array.isArray(o[k])) o[k]=s[k];
  o.teams.forEach(t=>{ if(!t.abbr) t.abbr=(TEAMS0.find(x=>x.id===t.id)||{}).abbr||t.short.slice(0,3).toUpperCase(); });
  o.ties=o.ties||{}; o.published=o.published||{}; if(!d.official) o.official=s.official;
  Object.values(o.ties).forEach(t=>{ t.rubbers = RUBBERS.map((R,i)=>({n:R.n,type:R.type,polo:[],score:'',res:null,note:'',...(t.rubbers?.[i]||{}), n:R.n, type:R.type})); t.convocados=t.convocados||[]; t.subs=t.subs||[]; t.poster=t.poster||{}; });
  return o;
}

/* ===================== BACKEND: Firebase o vista previa ===================== */
const CFG = window.POLO_CONFIG || {};
const clone = x => x==null? x : JSON.parse(JSON.stringify(x));
function makeDemo(){
  const KEY='polo-preview-v2'; let mem={}; let u=null; const L=[]; let authCb=()=>{};
  try{ mem=JSON.parse(localStorage.getItem(KEY)||'{}'); u=JSON.parse(localStorage.getItem(KEY+'-u')||'null'); }catch(e){}
  const persist=()=>{ try{ localStorage.setItem(KEY,JSON.stringify(mem)); }catch(e){} };
  const fire=l=>{ if(l.coll){ const out={}, d=l.path.split('/').length+1; Object.keys(mem).forEach(k=>{ if(k.startsWith(l.path+'/') && k.split('/').length===d) out[k.split('/').pop()]=clone(mem[k]); }); l.cb(out); } else l.cb(clone(mem[l.path]??null)); };
  const emit=()=>setTimeout(()=>L.slice().forEach(fire),0);
  const watch=(path,cb,coll)=>{ const l={path,cb,coll}; L.push(l); setTimeout(()=>fire(l),0); return ()=>{ const i=L.indexOf(l); if(i>=0) L.splice(i,1); }; };
  return {
    mode:'demo',
    onAuth(cb){ authCb=cb; setTimeout(()=>cb(u),0); },
    async signIn(){ u={uid:'preview-user', email:'jugador.prueba@gmail.com', name:'Vista previa'}; try{ localStorage.setItem(KEY+'-u',JSON.stringify(u)); }catch(e){} authCb(u); },
    async signOut(){ u=null; try{ localStorage.removeItem(KEY+'-u'); }catch(e){} authCb(null); },
    watchDoc:(p,cb)=>watch(p,cb,false), watchColl:(p,cb)=>watch(p,cb,true),
    async set(p,d){ mem[p]=clone(d); persist(); emit(); },
    async del(p){ delete mem[p]; persist(); emit(); },
    async claim(pid){ const c=mem['claims/'+pid]; if(c && c.email!==u.email) throw new Error('Ese nombre ya está elegido'); Object.keys(mem).forEach(k=>{ if(k.startsWith('claims/') && mem[k].email===u.email) delete mem[k]; }); mem['claims/'+pid]={uid:u.uid,email:u.email,at:Date.now()}; mem['users/'+u.uid]={pid,email:u.email}; persist(); emit(); },
    async relink(){ return null; },
    async isAdmin(){ return true; },
    async reset(){ mem={}; persist(); emit(); }
  };
}
function makeFirebase(){
  firebase.initializeApp(CFG.firebase); const auth=firebase.auth(); const fs=firebase.firestore();
  const pathRef=p=>fs.doc(p);
  return {
    mode:'firebase',
    onAuth(cb){ auth.getRedirectResult().catch(e=>toast(authMsg(e))); auth.onAuthStateChanged(x=>cb(x? {uid:x.uid,email:(x.email||'').toLowerCase(),name:x.displayName,photo:x.photoURL} : null)); },
    async signIn(){ const p=new firebase.auth.GoogleAuthProvider(); p.setCustomParameters({prompt:'select_account'});
      try{ await auth.signInWithPopup(p); }catch(e){ if(['auth/popup-blocked','auth/operation-not-supported-in-this-environment','auth/web-storage-unsupported'].includes(e.code)) return auth.signInWithRedirect(p); if(e.code!=='auth/popup-closed-by-user' && e.code!=='auth/cancelled-popup-request') toast(authMsg(e)); } },
    signOut:()=>auth.signOut(),
    watchDoc(p,cb){ return pathRef(p).onSnapshot(s=>cb(s.exists? s.data():null), e=>console.warn(p,e.code)); },
    watchColl(p,cb){ return fs.collection(p).onSnapshot(q=>{ const o={}; q.forEach(d=>o[d.id]=d.data()); cb(o); }, e=>console.warn(p,e.code)); },
    set:(p,d)=>pathRef(p).set(clone(d)),
    del:(p)=>pathRef(p).delete(),
    async claim(pid){ const u=auth.currentUser; const email=(u.email||'').toLowerCase(); const b=fs.batch();
      b.set(fs.doc('claims/'+pid),{uid:u.uid,email,at:Date.now()}); b.set(fs.doc('users/'+u.uid),{pid,email}); await b.commit(); },
    async relink(){ const u=auth.currentUser; const email=(u.email||'').toLowerCase(); const q=await fs.collection('claims').where('email','==',email).limit(1).get();
      if(q.empty) return null; const d=q.docs[0];
      if(d.data().uid!==u.uid){ const b=fs.batch(); b.set(d.ref,{uid:u.uid,email,at:Date.now()}); b.set(fs.doc('users/'+u.uid),{pid:d.id,email}); await b.commit(); }
      return d.id; },
    async isAdmin(email,uid){ try{ const [a,b]=await Promise.all([fs.doc('admins/'+uid).get(), fs.doc('admins/'+email).get()]); return a.exists||b.exists; }catch(e){ return false; } }
  };
}
function authMsg(e){ if(e?.code==='auth/unauthorized-domain') return 'Este dominio no está autorizado en Firebase > Authentication > Configuración'; return 'No se ha podido entrar: '+(e?.code||e?.message||'error'); }
const B = (window.firebase && CFG.firebase && CFG.firebase.apiKey) ? makeFirebase() : makeDemo();

/* ===================== ESTADO ===================== */
let S = seed();
let authUser=null, authReady=false, me=null, isAdmin=false, adminSkip=false;
let claims={}, avail={}, picks={}, ballots={}, myBallot=null, notes={}, photos={}, phones={}, meta=null;
let subs=[], mineSub=null;
const ui = { ligaAll:false, statsTab:'equipo', rankFilter:'season', sortKey:'w', cmpA:null, cmpB:null, adminTab:'jornada', jTab:'disp', compose:null, poster:null, adminJ:null, survey:null, pendingRender:false, revealed:{} };
const RM = matchMedia('(prefers-reduced-motion: reduce)');

const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const team = id => S.teams.find(t=>t.id===id) || {id, name:id, short:id, abbr:'?'};
const player = id => S.players.find(p=>p.id===id);
const pname = id => player(id)?.name || 'Por designar';
const jid = n => 'j'+n;
const NJ = () => Math.max(0,...S.fixtures.map(f=>+f.j||0));
const pct = (a,b) => b ? Math.round(a*100/b) : 0;
const dec = n => (Math.round(n*10)/10).toLocaleString('es-ES');
const sum = a => a.reduce((x,y)=>x+y,0);
const fdate = (f, opt={weekday:'short',day:'numeric',month:'short'}) => new Date(f.date+'T'+(f.time||'15:00')).toLocaleDateString('es-ES',opt);
const kickoff = f => new Date(f.date+'T'+(f.time||'15:00')+':00');
function daysTo(f){ const a=new Date(); a.setHours(0,0,0,0); return Math.round((new Date(f.date+'T00:00:00')-a)/864e5); }
function countdown(f){ const d=daysTo(f); if(d<0) return 'Disputada'; if(d===0) return 'Hoy'; if(d===1) return 'Mañana'; return 'En '+d+' días'; }

/* ===================== LÓGICA DE COMPETICIÓN ===================== */
const isPlayed = f => f.hs!=null && f.as!=null && (f.hs+f.as)>0;
const poloFix = j => S.fixtures.find(f=>f.j===j && (f.home===POLO||f.away===POLO));
function persp(f){ const home=f.home===POLO; return {home, rival: home? f.away : f.home, ps: home? f.hs : f.as, rs: home? f.as : f.hs, played:isPlayed(f)}; }
const tie = j => S.ties[jid(j)];
const blankTie = () => ({convocados:[], subs:[], lineupPub:false, poster:{}, rubbers: RUBBERS.map(R=>({n:R.n,type:R.type,polo:[],score:'',res:null,note:''})), moment:''});
function ensureTie(j){ const k=jid(j); if(!S.ties[k]) S.ties[k]=blankTie(); return S.ties[k]; }
function parseScore(str){ if(!str) return []; return String(str).split(/[\s,;]+/).map(x=>x.match(/^(\d{1,2})[-\/](\d{1,2})$/)).filter(Boolean).map(m=>[+m[1],+m[2]]); }
function rubberCalc(r){
  const sets=parseScore(r.score); let sw=0,sl=0,gw=0,gl=0,lostFirst=false,bagelsW=0,tbs=0;
  sets.forEach(([a,b],i)=>{ if(a>b) sw++; else if(b>a) sl++; gw+=a; gl+=b; if(a===6&&b===0) bagelsW++; if((a===7&&b===6)||(a===6&&b===7)) tbs++; if(i===0&&b>a) lostFirst=true; });
  const res = r.res || (sets.length>=2 && sw!==sl ? (sw>sl?'W':'L') : null);
  return {sets, sw, sl, gw, gl, res, three: sets.length===3, comeback: res==='W'&&lostFirst, bagelsW, tbs};
}
function tieFromRubbers(j){
  const t=tie(j); if(!t) return null; let w=0,l=0,singles=0;
  t.rubbers.forEach(r=>{ const c=rubberCalc(r); if(!c.res) return; if(r.type==='S') singles++; c.res==='W'? w++ : l++; });
  const needsDoubles = singles===4 && w===2 && l===2;
  return {w,l,decided:w+l,singles,needsDoubles,complete: singles===4 && !needsDoubles};
}
function standings(uptoJ){
  const rows=S.teams.map(t=>({id:t.id,pj:0,g:0,p:0,pts:0,rw:0,rl:0,form:[]})); const R=Object.fromEntries(rows.map(r=>[r.id,r]));
  S.fixtures.filter(f=>isPlayed(f)&&(uptoJ==null||f.j<=uptoJ)).sort((a,b)=>a.j-b.j).forEach(f=>{ const h=R[f.home],a=R[f.away]; if(!h||!a) return;
    h.pj++; a.pj++; h.rw+=f.hs; h.rl+=f.as; a.rw+=f.as; a.rl+=f.hs;
    if(f.hs>f.as){ h.g++; a.p++; h.pts+=S.rules.win; a.pts+=S.rules.loss; h.form.push('W'); a.form.push('L'); }
    else if(f.as>f.hs){ a.g++; h.p++; a.pts+=S.rules.win; h.pts+=S.rules.loss; a.form.push('W'); h.form.push('L'); } });
  const lastJ = uptoJ ?? Math.max(0,...S.fixtures.filter(isPlayed).map(f=>f.j));
  const off = S.official && S.official.asOf===lastJ && Array.isArray(S.official.order)? S.official.order : null;
  const oi = id => { const i=off? off.indexOf(id) : -1; return i<0? 99 : i; };
  rows.sort((x,y)=> off? (oi(x.id)-oi(y.id)||y.pts-x.pts) : (y.pts-x.pts||(y.rw-y.rl)-(x.rw-x.rl)||y.rw-x.rw||team(x.id).short.localeCompare(team(y.id).short)));
  rows.forEach((r,i)=>r.pos=i+1); return rows;
}
const playedJornadas = () => [...new Set(S.fixtures.filter(isPlayed).map(f=>f.j))].sort((a,b)=>a-b);
function nextPoloFix(){ const now=Date.now(); return S.fixtures.filter(f=>(f.home===POLO||f.away===POLO)&&!isPlayed(f)&&kickoff(f).getTime()>now-8*3600e3).sort((a,b)=>a.j-b.j)[0]||null; }
function lastPoloPlayed(){ return S.fixtures.filter(f=>(f.home===POLO||f.away===POLO)&&isPlayed(f)).sort((a,b)=>b.j-a.j)[0]||null; }
function currentJ(){ const now=Date.now(); const up=S.fixtures.filter(f=>!isPlayed(f)&&kickoff(f).getTime()>now-8*3600e3).sort((a,b)=>a.j-b.j)[0]; return up? up.j : NJ(); }
const clubName = id => team(id).name;

/* ---------- Disponibilidad y participantes ---------- */
function avOf(pid,j){ const v=avail[pid]?.j?.[jid(j)]; if(!v) return null; return typeof v==='string'? {s:v} : v; }
function noteOf(pid,j){ return notes[pid]?.j?.[jid(j)] || null; }
function availFor(j){ const out={yes:[],no:[],maybe:[],none:[]}; S.players.filter(p=>p.active!==false).forEach(p=>{ const v=avOf(p.id,j); (out[v?.s]||out.none).push(p.id); }); out.total=out.yes.length+out.no.length+out.maybe.length+out.none.length; out.answered=out.total-out.none.length; out.pct=out.total? out.yes.length/out.total : 0; return out; }
function deadline(j){ const t=tie(j); if(t?.deadline) return new Date(t.deadline); const f=poloFix(j); if(!f) return null; const d=new Date(f.date+'T'+(S.rules.deadlineTime||'21:00')+':00'); d.setDate(d.getDate()-(+S.rules.deadlineDays||0)); return d; }
function deadlinePassed(j){ const d=deadline(j); return d? Date.now()>d.getTime() : true; }
function availOpen(f){ if(!f||isPlayed(f)) return false; if(deadlinePassed(f.j)) return false; return !!tie(f.j)?.availReq || daysTo(f)<=S.rules.availDays; }
const lineupVisible = j => { const t=tie(j); return !!(t && (t.lineupPub || isAdmin || t.rubbers.some(r=>rubberCalc(r).res))); };
function convocados(j){ const t=tie(j); if(t?.convocados?.length && (t.lineupPub||isAdmin)) return t.convocados; const pl=new Set(); (t?.rubbers||[]).forEach(r=>{ if(rubberCalc(r).res) (r.polo||[]).forEach(x=>pl.add(x)); }); return [...pl]; }
function officialConv(j){ const t=tie(j), f=poloFix(j); if(!t) return []; if(t.lineupPub || (f&&isPlayed(f))){ const set=new Set(t.convocados||[]); t.rubbers.forEach(r=>(r.polo||[]).forEach(x=>set.add(x))); (t.subs||[]).forEach(x=>set.add(x)); return [...set]; } return []; }
function closedJornadas(){ return S.fixtures.filter(f=>(f.home===POLO||f.away===POLO) && (isPlayed(f) || deadlinePassed(f.j))).map(f=>f.j).sort((a,b)=>a-b); }
function availStats(pid){
  const js=closedJornadas(), o={total:js.length,yes:0,no:0,maybe:0,none:0,conv:0,yesNotConv:0,seq:[]};
  js.forEach(j=>{ const v=avOf(pid,j)?.s||'none'; o[v]++; const c=officialConv(j).includes(pid); if(c) o.conv++; if(v==='yes'&&!c&&officialConv(j).length) o.yesNotConv++; o.seq.push({j,s:v,c}); });
  o.pct=o.total? o.yes/o.total : null; o.respPct=o.total? (o.total-o.none)/o.total : null; return o;
}
function rolesOf(j){ const t=tie(j), roles={}; if(!t) return roles; t.rubbers.forEach(r=>(r.polo||[]).forEach(pid=>{ (roles[pid] ||= []).push(r.type==='D'?'Dobles':'Individual '+r.n); })); (t.subs||[]).forEach(pid=>{ if(!roles[pid]) roles[pid]=['Suplente']; }); (t.convocados||[]).forEach(pid=>{ if(!roles[pid]) roles[pid]=['Convocado']; }); return roles; }
function lineupList(j){ const t=tie(j); if(!t) return []; const order=[]; const add=x=>{ if(x&&!order.includes(x)) order.push(x); };
  t.rubbers.filter(r=>r.type==='S').forEach(r=>add(r.polo[0])); (t.rubbers.find(r=>r.type==='D')?.polo||[]).forEach(add); (t.convocados||[]).forEach(add); (t.subs||[]).forEach(add);
  const custom=(t.poster?.order||[]).filter(x=>order.includes(x)); const rest=order.filter(x=>!custom.includes(x)); return [...custom,...rest].filter(x=>!(t.poster?.hidden||[]).includes(x)); }
const relTime = ts => { if(!ts) return ''; const m=Math.round((Date.now()-ts)/6e4); if(m<1) return 'ahora'; if(m<60) return 'hace '+m+' min'; const h=Math.round(m/60); if(h<24) return 'hace '+h+' h'; const d=Math.round(h/24); return d===1? 'ayer' : 'hace '+d+' días'; };
const fmtDT = d => d? d.toLocaleString('es-ES',{weekday:'long',day:'numeric',month:'long',hour:'2-digit',minute:'2-digit'}) : '';
function participants(j){ const t=tie(j); const played=new Set(); (t?.rubbers||[]).forEach(r=>{ if(rubberCalc(r).res) (r.polo||[]).forEach(p=>played.add(p)); }); return played.size? [...played] : convocados(j); }
function pendingSurveys(){
  if(!me) return [];
  return playedJornadas().filter(j=>{ const f=poloFix(j); if(!f) return false; const k=jid(j);
    return !S.survey.closed?.[k] && tie(j) && participants(j).includes(me) && !myBallot?.j?.[k]; });
}

/* ---------- Estadísticas ---------- */
function playerStats(pid, onlyJ){
  const st={pid,pj:0,w:0,l:0,sw:0,sl:0,gw:0,gl:0,seq:[],byJ:{},byPos:{},three:{w:0,l:0},dbl:{w:0,l:0},comebacks:0,bagels:0,tbs:0,jornadas:new Set(),matches:[],vs:{}};
  for(let j=1;j<=NJ();j++){ if(onlyJ&&onlyJ!==j) continue; const t=tie(j); if(!t) continue; const f=poloFix(j);
    t.rubbers.forEach(r=>{ if(!(r.polo||[]).includes(pid)) return; const c=rubberCalc(r); if(!c.res) return; const W=c.res==='W';
      st.pj++; st.jornadas.add(j); W? st.w++ : st.l++; st.sw+=c.sw; st.sl+=c.sl; st.gw+=c.gw; st.gl+=c.gl; st.seq.push(c.res);
      (st.byJ[j] ||= {w:0,l:0})[W?'w':'l']++; const pos=r.type==='D'?'D':r.n; (st.byPos[pos] ||= {w:0,l:0})[W?'w':'l']++;
      if(c.three) st.three[W?'w':'l']++; if(r.type==='D') st.dbl[W?'w':'l']++; if(c.comeback) st.comebacks++; st.bagels+=c.bagelsW; st.tbs+=c.tbs;
      if(f){ const rv=persp(f).rival; (st.vs[rv] ||= {w:0,l:0})[W?'w':'l']++; }
      st.matches.push({j,r,c}); }); }
  st.wr=st.pj? st.w/st.pj : 0;
  let cur=0,t=null; for(let i=st.seq.length-1;i>=0;i--){ if(t===null) t=st.seq[i]; if(st.seq[i]===t) cur++; else break; } st.streak={n:cur,t};
  let best=0,run=0; st.seq.forEach(x=>{ run=x==='W'?run+1:0; best=Math.max(best,run); }); st.bestStreak=best;
  const js=[...st.jornadas]; st.njor=js.length; st.consist=js.length? js.filter(j=>st.byJ[j].w>=st.byJ[j].l).length/js.length : 0;
  return st;
}
function teamStats(){
  const fx=S.fixtures.filter(f=>(f.home===POLO||f.away===POLO)&&isPlayed(f)).sort((a,b)=>a.j-b.j);
  const o={ties:fx.length,tw:0,tl:0,rw:0,rl:0,sw:0,sl:0,gw:0,gl:0,byJ:[],vs:{},dbl:{w:0,l:0}};
  fx.forEach(f=>{ const p=persp(f); o.rw+=p.ps; o.rl+=p.rs; p.ps>p.rs? o.tw++ : o.tl++; o.byJ.push({j:f.j,ps:p.ps,rs:p.rs,rival:p.rival,home:p.home});
    const v=(o.vs[p.rival] ||= {w:0,l:0,rw:0,rl:0}); p.ps>p.rs? v.w++ : v.l++; v.rw+=p.ps; v.rl+=p.rs; });
  Object.values(S.ties).forEach(t=>t.rubbers.forEach(r=>{ const c=rubberCalc(r); if(!c.res) return; o.sw+=c.sw; o.sl+=c.sl; o.gw+=c.gw; o.gl+=c.gl; if(r.type==='D') o.dbl[c.res==='W'?'w':'l']++; }));
  return o;
}
function clubSeason(id){ const r=standings().find(x=>x.id===id)||{}; return r; }
function votesFor(pid,qid,onlyJ){ let n=0; Object.entries(S.published).forEach(([k,p])=>{ if(onlyJ&&k!==jid(onlyJ)) return; n+=(p.votes?.[qid]?.[pid])||0; }); return n; }
const mvpCount = (pid,onlyJ) => Object.entries(S.published).filter(([k,p])=>(!onlyJ||k===jid(onlyJ))&&p.mvp===pid).length;
function totalVotes(pid,onlyJ){ let n=0; S.survey.questions.filter(q=>q.scope==='peer'&&q.id!=='q_sufrido').forEach(q=>n+=votesFor(pid,q.id,onlyJ)); return n; }

/* ---------- Crónica automática ---------- */
function listNames(arrs){ const n=[...new Set(arrs.map(a=>(a||[]).map(pname).join(' y ')).filter(Boolean))]; if(n.length<=1) return n[0]||'el equipo'; return n.slice(0,-1).join(', ')+' y '+n.at(-1); }
function cronica(j){
  const f=poloFix(j); if(!f||!isPlayed(f)) return null; const p=persp(f); const rv=clubName(p.rival);
  const where = p.home? 'en casa ante el '+rv : 'en las pistas del '+rv;
  let s = p.ps>p.rs? `El Polo ${p.rs===0?'arrasa':'se impone'} ${p.ps}-${p.rs} ${where}` : `El Polo ${p.ps===0?'cae con claridad':'cae'} ${p.ps}-${p.rs} ${where}`;
  const t=tie(j), bits=[];
  if(t){ const calc=t.rubbers.map(r=>({r,c:rubberCalc(r)})).filter(x=>x.c.res);
    const dbl=calc.find(x=>x.r.type==='D'); const cb=calc.filter(x=>x.c.comeback); const clean=calc.filter(x=>x.c.res==='W'&&x.c.sets.length===2&&x.c.gl<=4); const three=calc.filter(x=>x.c.three);
    if(dbl) bits.push(`con el dobles decisivo ${dbl.c.res==='W'?'ganado':'perdido'} por ${listNames([dbl.r.polo])}`);
    if(cb.length) bits.push(`${cb.length>1?'remontadas':'una remontada'} de ${listNames(cb.map(x=>x.r.polo))} tras perder el primer set`);
    else if(clean.length) bits.push(`${clean.length>1?'victorias rotundas':'una victoria rotunda'} de ${listNames(clean.map(x=>x.r.polo))}`);
    else if(three.length) bits.push(`${three.length} ${three.length>1?'partidos se fueron':'partido se fue'} al tercer set`); }
  let txt=s+(bits.length? ', '+bits.slice(0,2).join(' y ') : '')+'.';
  const pub=S.published[jid(j)]; if(pub?.mvp) txt+=` El equipo eligió a ${pname(pub.mvp)} MVP de la jornada.`;
  return {txt, partial: !(t && t.rubbers.some(r=>rubberCalc(r).res))};
}

/* ---------- Insights ---------- */
const QSHORT={q_destacado:'más destacado',q_actitud:'mejor actitud',q_sorpresa:'el que más sorprende',q_determinante:'más determinante',q_sufrido:'el que más ha sufrido',q_momento:'mejor momento',q_companero:'mejor compañero'};
function insights(pid){
  const st=playerStats(pid), out=[];
  if(st.pj){ const last=st.seq.slice(-5), lw=last.filter(x=>x==='W').length;
    out.push({t: last.length===1? (lw?'Ganó el único partido que ha jugado.':'Perdió el único partido que ha jugado.') : `Ha ganado ${lw} de sus últimos ${last.length} partidos.`, s:'Resultados'});
    if(st.streak.n>=2) out.push({t:`Lleva ${st.streak.n} ${st.streak.t==='W'?'victorias':'derrotas'} seguidas.`, s:'Resultados'});
    if(st.three.w+st.three.l>=2) out.push({t:`En partidos a tres sets su balance es de ${st.three.w}-${st.three.l}.`, s:'Resultados'});
    if(st.comebacks) out.push({t:`Ha remontado ${st.comebacks} ${st.comebacks>1?'veces':'vez'} tras perder el primer set.`, s:'Resultados'});
    if(st.dbl.w+st.dbl.l) out.push({t:`En dobles decisivos: ${st.dbl.w}-${st.dbl.l}.`, s:'Resultados'});
    const pos=Object.entries(st.byPos).filter(([k,v])=>k!=='D'&&v.w+v.l>=2).sort((a,b)=>(b[1].w/(b[1].w+b[1].l))-(a[1].w/(a[1].w+a[1].l)));
    if(pos.length) out.push({t:`Su mejor rendimiento llega como individual ${pos[0][0]} (${pos[0][1].w}-${pos[0][1].l}).`, s:'Resultados'});
    if(st.njor>=3) out.push({t:`Ha cerrado con balance positivo o igualado ${Math.round(st.consist*st.njor)} de sus ${st.njor} jornadas.`, s:'Resultados'}); }
  const peer=S.survey.questions.filter(q=>q.scope==='peer'&&q.id!=='q_sufrido').map(q=>({q,n:votesFor(pid,q.id)})).filter(x=>x.n>0).sort((a,b)=>b.n-a.n);
  if(peer.length) out.push({t:`Sus compañeros le votan sobre todo como «${QSHORT[peer[0].q.id]||peer[0].q.text}» (${peer[0].n} ${peer[0].n>1?'votos':'voto'}).`, s:'Encuestas, votos agregados'});
  const m=mvpCount(pid); if(m) out.push({t:`${m>1?m+' veces':'Una vez'} MVP de la jornada.`, s:'MVP publicado'});
  return out;
}
function selfSeries(dim){ if(!myBallot?.j) return []; return Object.entries(myBallot.j).map(([k,v])=>({j:+k.slice(1),v:+v.a?.[dim]})).filter(x=>x.v>0).sort((a,b)=>a.j-b.j); }
function privateInsights(){
  const out=[], r=selfSeries('s_rend');
  if(r.length>=3){ const a=r.slice(-3); if(a[2].v>a[1].v&&a[1].v>a[0].v) out.push('Tu autovaloración de rendimiento ha subido en las tres últimas jornadas.'); else if(a[2].v<a[1].v&&a[1].v<a[0].v) out.push('Tu autovaloración de rendimiento ha bajado en las tres últimas jornadas.'); }
  const avgs=SELF_DIMS.map(([k,l])=>{ const s=selfSeries(k); return {l,avg:s.length? sum(s.map(x=>x.v))/s.length : null}; }).filter(x=>x.avg!=null);
  if(avgs.length>=2){ avgs.sort((a,b)=>b.avg-a.avg); if(avgs[0].avg>avgs.at(-1).avg) out.push(`Te ves más fuerte en ${avgs[0].l.toLowerCase()} (${dec(avgs[0].avg)}) y más flojo en ${avgs.at(-1).l.toLowerCase()} (${dec(avgs.at(-1).avg)}).`); }
  if(me && r.length){ const st=playerStats(me), sr=sum(r.map(x=>x.v))/r.length;
    if(st.pj) out.push(`Te pones un ${dec(sr)} de media y en pista llevas un ${pct(st.w,st.pj)} % de victorias. Son medidas distintas: úsalas como contraste, no como veredicto.`);
    const v=totalVotes(me); if(v) out.push(`Has recibido ${v} ${v>1?'votos':'voto'} de tus compañeros en las encuestas publicadas.`); }
  return out;
}

/* ===================== COMPONENTES ===================== */
function avatar(p, cls=''){
  if(!p) return `<span class="av ${cls}">?</span>`;
  const ini=p.name.split(' ').map(x=>x[0]).slice(0,2).join('');
  const src = photos[p.id]?.d;
  return `<span class="av ${cls}">${esc(ini)}${src?`<img src="${esc(src)}" alt="" loading="lazy" onerror="this.remove()">`:''}</span>`;
}
const crest = (id,cls='') => `<span class="crest ${cls}" aria-hidden="true">${esc(team(id).abbr)}</span>`;
const plink = (id, txt) => `<button class="lnk" data-player="${esc(id)}">${esc(txt ?? pname(id))}</button>`;
const resBadge = r => `<span class="res ${r||'P'}">${r==='W'?'G':r==='L'?'P':'–'}</span>`;
function formStrip(seq,n=5){ const a=seq.slice(-n); while(a.length<n) a.unshift(''); return `<span class="form" aria-label="Últimos resultados">${a.map((x,k)=>`<i class="${x}" style="--k:${k}"></i>`).join('')}</span>`; }
const count = (v, suf='') => `<span data-count="${v}" data-suf="${suf}">${v}${suf}</span>`;

function scoreboard(f, big=false){
  const t=tieFromRubbers(f.j), p=persp(f), rubs=tie(f.j)?.rubbers||[];
  const rows=[f.home,f.away].map(id=>{ const us=id===POLO; let k=0;
    const cells=RUBBERS.map((R,i)=>{ const c=rubs[i]? rubberCalc(rubs[i]).res : null; const won=c&&((us&&c==='W')||(!us&&c==='L'));
      const na = R.type==='D' && !c && !(t&&t.needsDoubles); return `<span class="cell ${won?'w':''} ${na?'na':''}" style="--i:${won?k++:0}">${won?'●':''}</span>`; }).join('');
    const tot = isPlayed(f)? (id===f.home? f.hs : f.as) : (t&&t.decided? (us? t.w : t.l) : '–');
    return `<span class="board-n ${us?'us':''}">${esc(us? 'Polo' : team(id).short)}${id===f.home?'<i class="loc">Local</i>':''}</span>${cells}<span class="board-t ${tot==='–'?'dim':''}">${tot}</span>`; }).join('');
  const status = isPlayed(f)? 'Final' : (t&&t.decided? '<span class="live">En juego</span>' : countdown(f));
  return `<a class="board ${big?'big':''}" href="#jornada-${f.j}">
    <div class="board-top"><b>Jornada ${f.j}</b><span>${esc(fdate(f,{weekday:'long',day:'numeric',month:'long'}))}, ${esc(f.time)} h</span><span>${status}</span></div>
    <div class="board-grid"><span></span>${RUBBERS.map(R=>`<span class="board-h">${R.type==='D'?'D':R.n}</span>`).join('')}<span class="board-h">Total</span>${rows}</div>
    <div class="board-foot"><span>${p.home? 'En casa, Real Club de Polo' : 'Fuera, en las pistas del '+esc(clubName(p.rival))}</span><span>${big?'':'Ver jornada'}</span></div></a>`;
}
function courtSVG(){ return `<svg class="court" viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><g fill="none" stroke="#E2C47C" stroke-opacity=".32" stroke-width="1"><rect x="60" y="30" width="280" height="240"/><rect x="85" y="30" width="230" height="240"/><path d="M85 95h230M85 205h230M200 95v110"/><path d="M60 150h280"/></g></svg>`; }
const titleLetters = t => [...t].map((c,i)=>c===' '?' ':`<span style="--i:${i}">${esc(c)}</span>`).join('');
function lineChart(points,{h=180,invert=false,min=1,max=7,labels=true,unit=''}={}){
  const W=600,pad={l:28,r:12,t:12,b:24},n=NJ(); const x=j=>pad.l+(j-1)*(W-pad.l-pad.r)/Math.max(1,n-1); const y=v=>{const t=(v-min)/(max-min||1); return pad.t+(invert?t:1-t)*(h-pad.t-pad.b);};
  let g=''; for(let v=min;v<=max;v++){ g+=`<line x1="${pad.l}" x2="${W-pad.r}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)"/>`; if(labels) g+=`<text x="${pad.l-8}" y="${y(v)+4}" text-anchor="end">${v}${unit}</text>`; }
  for(let j=1;j<=n;j++) g+=`<text x="${x(j)}" y="${h-6}" text-anchor="middle">J${j}</text>`;
  const path=points.map((p,i)=>`${i?'L':'M'}${x(p.j)},${y(p.v)}`).join('');
  return `<svg class="chart" viewBox="0 0 ${W} ${h}" role="img">${g}${points.length>1?`<path class="ln" d="${path}" fill="none" stroke="var(--brass)" stroke-width="2.5" stroke-linejoin="round"/>`:''}${points.map((p,k)=>`<circle class="dt" style="--k:${k}" cx="${x(p.j)}" cy="${y(p.v)}" r="5" fill="var(--brass)" stroke="var(--bg)" stroke-width="2"/>`).join('')}</svg>`;
}
function barsChart(items,h=170){
  const W=600,pad={l:24,r:8,t:10,b:24},n=Math.max(1,NJ()),max=5,bw=(W-pad.l-pad.r)/n; let g='';
  for(let v=0;v<=max;v++){ const yy=pad.t+(1-v/max)*(h-pad.t-pad.b); g+=`<line x1="${pad.l}" x2="${W-pad.r}" y1="${yy}" y2="${yy}" stroke="var(--line)"/><text x="${pad.l-6}" y="${yy+4}" text-anchor="end">${v}</text>`; }
  for(let j=1;j<=n;j++){ const it=items.find(i=>i.j===j), cx=pad.l+(j-.5)*bw; g+=`<text x="${cx}" y="${h-6}" text-anchor="middle">J${j}</text>`;
    if(it){ const ha=(it.a/max)*(h-pad.t-pad.b), hb=(it.b/max)*(h-pad.t-pad.b), base=h-pad.b;
      g+=`<rect class="br" style="--k:${j}" x="${cx-bw*.32}" y="${base-ha}" width="${bw*.3}" height="${ha}" rx="2" fill="var(--win)"/><rect class="br" style="--k:${j}" x="${cx+bw*.02}" y="${base-hb}" width="${bw*.3}" height="${hb}" rx="2" fill="var(--loss)" opacity=".75"/>`; } }
  return `<svg class="chart" viewBox="0 0 ${W} ${h}" role="img">${g}</svg>`;
}
function ring(v,label){ const C=2*Math.PI*46; return `<div class="ring"><svg width="110" height="110" viewBox="0 0 110 110"><circle class="bg" cx="55" cy="55" r="46"/><circle class="v" cx="55" cy="55" r="46" stroke-dasharray="${C}" stroke-dashoffset="${C}" data-off="${C*(1-(v||0))}"/></svg><b>${v==null?'–':count(Math.round(v*100),'%')}</b><small>${esc(label)}</small></div>`; }
function meter(l,s,v,txt,cls=''){ return `<div class="meter"><span>${l}<small>${s}</small></span><span class="bar"><i class="${cls}" data-w="${v==null?0:Math.round(Math.max(0,Math.min(1,v))*100)}"></i></span><b>${txt}</b></div>`; }
function standingsTable(rows,compact=false){
  return `<div class="tscroll"><table><thead><tr><th>Equipo</th><th>PJ</th>${compact?'':'<th>G</th><th>P</th><th>Partidos</th><th class="l">Forma</th>'}<th>Pts</th></tr></thead><tbody class="stagger">
  ${rows.map(r=>`<tr class="${r.id===POLO?'us':''}"><td><span class="pos">${r.pos}</span>${esc(compact? team(r.id).short : team(r.id).name)}</td><td>${r.pj}</td>${compact?'':`<td>${r.g}</td><td>${r.p}</td><td>${r.rw}-${r.rl}</td><td class="l">${formStrip(r.form,4)}</td>`}<td><b>${r.pts}</b></td></tr>`).join('')}</tbody></table></div>`;
}

/* Carteles de partido */
function posters(j){
  const f=poloFix(j); if(!f) return ''; const t=tie(j); const p=persp(f); const tr=tieFromRubbers(j);
  const any = t && t.rubbers.some(r=>(r.polo||[]).length);
  if(!any || !lineupVisible(j)) return '';
  return `<div class="posters stagger">${t.rubbers.map((r,i)=>{ const c=rubberCalc(r);
    if(r.type==='D' && !(r.polo||[]).length && !(tr&&tr.needsDoubles)) return '';
    const left = r.type==='D'? `<span class="duo">${(r.polo.length?r.polo:['','']).map(id=>avatar(player(id))).join('')}</span><span>${r.polo.length? r.polo.map(id=>esc(pname(id).split(' ')[0])).join(' y ') : 'Pareja por decidir'}</span>` : `${avatar(player(r.polo[0]))}<span>${esc(pname(r.polo[0]))}</span>`;
    return `<button class="poster press" data-present="${j}:${i}">${c.res? resBadge(c.res):''}<span class="lab">${RUBBERS[i].label}</span>
      <span class="side">${left}</span><span class="vsx">VS</span><span class="side">${crest(p.rival)}<span>${esc(team(p.rival).short)}</span></span>
      <span class="score">${c.sets.length? c.sets.map(s=>s.join('-')).join('  ') : 'Toca para ver la presentación'}</span></button>`; }).join('')}</div>`;
}

/* ===================== VISTAS ===================== */
function vInicio(){
  const nx=nextPoloFix(), last=lastPoloPlayed(), st=standings(), mine=st.find(r=>r.id===POLO), ts=teamStats();
  const photo = `${courtSVG()}<span class="ball" aria-hidden="true"></span>${photos._team?.d?`<div class="hero-media"><img src="${esc(photos._team.d)}" alt="Equipo masculino absoluto del Real Club de Polo"></div>`:''}`;
  let h=`<section class="hero">${photo}<div class="wrap hero-in">
    <p class="hero-comp">${esc(S.comp.name)}, ${esc(S.comp.group)}</p>
    <h1 class="hero-title" aria-label="Polo A">${titleLetters('Polo A')}</h1>
    <p class="hero-sub">Real Club de Polo de Barcelona, temporada ${esc(S.seasonId||viewSeason)}</p>
    ${nx? scoreboard(nx) : ''}</div></section><div class="wrap">`;
  h+=callouts(nx);
  h+=`<section class="sec"><div class="figs stagger">
    <div class="fig"><b>${mine.pj? count(mine.pos,'º'):'–'}</b><span>en la clasificación</span></div>
    <div class="fig"><b>${count(mine.pts)}</b><span>puntos</span></div>
    <div class="fig"><b>${ts.tw}-${ts.tl}</b><span>eliminatorias</span></div>
    <div class="fig"><b>${ts.rw}-${ts.rl}</b><span>partidos individuales</span></div></div></section>`;
  if(nx){ const p=persp(nx);
    h+=`<section class="sec"><div class="sec-h"><h2>Jornada ${nx.j}</h2><a href="#jornada-${nx.j}">Abrir</a></div>
      <p class="lede">Polo contra ${esc(clubName(p.rival))}, ${esc(fdate(nx,{weekday:'long',day:'numeric',month:'long'}))} a las ${esc(nx.time)} h. ${p.home?'Jugamos en casa.':'Jugamos fuera.'}</p>
      <div style="margin-top:16px">${posters(nx.j) || availBlock(nx)}</div></section>`; }
  if(last){ const c=cronica(last.j);
    h+=`<section class="sec"><div class="sec-h"><h2>Última jornada</h2><a href="#jornada-${last.j}">Ver jornada ${last.j}</a></div>
    <div class="split"><div>${scoreboard(last,true)}</div><div><p class="cronica" style="margin-top:0">${esc(c.txt)}${c.partial?'<small>Faltan los resultados individuales; la crónica se completará cuando se carguen.</small>':''}</p>${mvpCard(last.j)}</div></div></section>`; }
  h+=`<section class="sec"><div class="split"><div><div class="sec-h"><h2>Clasificación</h2><a href="#liga">Liga completa</a></div>${standingsTable(st,true)}<p class="source">${standingsSource()}</p></div>
    <div><div class="sec-h"><h2>Momentos</h2></div>${momentsList()}</div></div></section></div>`;
  return h;
}
function standingsSource(){ return S.official && S.official.asOf===Math.max(0,...playedJornadas())? `Orden oficial FCT tras la jornada ${S.official.asOf}. Victoria ${S.rules.win} puntos, derrota ${S.rules.loss}.` : `Calculada con los resultados introducidos. Victoria ${S.rules.win} puntos, derrota ${S.rules.loss}.`; }
function callouts(nx){
  let h=''; const ps=pendingSurveys();
  ps.forEach(j=>{ h+=`<div class="callout"><div><b>Encuesta de la jornada ${j}</b><span>Jugaste contra ${esc(clubName(persp(poloFix(j)).rival))}. Tardas dos minutos.</span></div><div class="row"><a class="btn light" href="#votar">Responder</a></div></div>`; });
  S.fixtures.filter(f=>(f.home===POLO||f.away===POLO)&&availOpen(f)).forEach(f=>{ if(!me || avOf(me,f.j)) return; const p=persp(f);
    h+=`<div class="callout"><div><b>¿Puedes jugar el ${esc(fdate(f,{weekday:'long',day:'numeric'}))}?</b><span>Jornada ${f.j} contra ${esc(clubName(p.rival))}. Responde antes del ${esc(fmtDT(deadline(f.j)))}.</span></div><div class="row"><a class="btn light" href="#disponibilidad-${f.j}">Responder</a></div></div>`; });
  return h;
}
function availSummary(j,{compact=false}={}){
  const a=availFor(j); const seg=(k,c)=>a[k].length? `<i style="flex:${a[k].length};background:${c}" title="${AV_LABEL[k]}: ${a[k].length}"></i>`:'';
  return `<div class="avsum"><div class="avbar">${seg('yes','var(--win)')}${seg('maybe','var(--brass)')}${seg('no','var(--loss)')}${seg('none','var(--surface2)')}</div>
    <div class="avlegend"><span><b>${a.yes.length}</b> disponibles</span><span><b>${a.maybe.length}</b> pendientes de confirmar</span><span><b>${a.no.length}</b> no disponibles</span><span><b>${a.none.length}</b> sin responder</span><span class="pc">Disponibilidad <b>${dec(a.pct*100)} %</b></span></div></div>`;
}
function availBlock(f){
  const j=f.j, a=availFor(j), mine=me? avOf(me,j) : null, open=availOpen(f), dl=deadline(j);
  let h=`<div class="panel"><div class="row" style="justify-content:space-between;align-items:baseline"><b>Disponibilidad</b><span class="muted small">${open? 'Plazo hasta el '+esc(fmtDT(dl)) : deadlinePassed(j)? 'Plazo cerrado' : 'Se abre cuando el capitán la solicite'}</span></div>
    ${availSummary(j)}
    ${me && (open||mine)? `<div class="row" style="margin:6px 0 4px"><span class="small">Tu respuesta: <b>${mine? AV_LABEL[mine.s] : 'sin responder'}</b></span>${open?`<a class="btn sm ${mine?'ghost':'brass'}" href="#disponibilidad-${j}">${mine?'Cambiar':'Responder'}</a>`:''}</div>`:''}
    <div class="avail stagger" style="margin-top:10px">${['yes','maybe','no'].flatMap(k=>a[k].map(id=>`<span class="${k}">${avatar(player(id),'sm')}${esc(pname(id))}</span>`)).join('')}</div></div>`;
  return h;
}
function mvpCard(j){
  const p=S.published[jid(j)]; if(!p?.mvp) return `<p class="source">MVP de la jornada: pendiente de la votación del equipo.</p>`;
  const open=ui.revealed[j]; const pl=player(p.mvp);
  return `<button class="mvp press ${open?'open':''}" data-act="reveal" data-j="${j}" style="margin-top:16px">${avatar(pl)}<span><span class="k">MVP de la jornada ${j}</span><span class="n hid">${esc(pl?.name||'')}</span><span class="tap">Toca para revelarlo</span></span></button>`;
}
function momentsList(){
  const items=[];
  playedJornadas().slice().reverse().forEach(j=>{ if(!poloFix(j)) return; const c=cronica(j), p=S.published[jid(j)], t=tie(j);
    if(t?.moment) items.push({j,t:t.moment,s:'Momento de la jornada'}); if(p?.mvp) items.push({j,t:`${pname(p.mvp)}, MVP de la jornada ${j}.`,s:'Votación del equipo'}); if(c) items.push({j,t:c.txt,s:'Crónica automática'}); });
  if(!items.length) return `<div class="empty">Aquí aparecerán las crónicas, los MVP y los momentos de cada jornada.</div>`;
  return `<ul class="insights stagger">${items.slice(0,6).map(i=>`<li><a href="#jornada-${i.j}" style="text-decoration:none">${esc(i.t)}</a><small>J${i.j}, ${esc(i.s)}</small></li>`).join('')}</ul>`;
}
function rubberRow(r,i,f){
  const c=rubberCalc(r), tr=tieFromRubbers(f.j); const skip = r.type==='D' && !c.res && !(tr&&tr.needsDoubles) && !(r.polo||[]).length;
  const who=(r.polo||[]).length? r.polo.map(id=>plink(id)).join(' y ') : '<span class="muted">Por designar</span>';
  return `<div class="rubber ${skip?'skip':''}"><span class="rn">${r.type==='D'?'D':r.n}</span><div><div class="p">${who}</div><div class="r">${RUBBERS[i].label} contra ${esc(clubName(persp(f).rival))}${skip?'. Solo si hay 2-2':''}</div></div>
  <div class="sets">${c.sets.length? c.sets.map(s=>s.join('-')).join('  ') : '–'}${r.note?`<small>${esc(r.note)}</small>`:''}<div style="margin-top:4px">${resBadge(c.res)}</div></div></div>`;
}

function vLiga(){
  const st=standings(), evo=playedJornadas().map(j=>({j,v:standings(j).find(r=>r.id===POLO).pos})), nx=nextPoloFix();
  let h=`<div class="wrap"><div class="pagehead"><h1>La liga</h1><p class="lede">${esc(S.comp.name)}, ${esc(S.comp.memorial)}. ${esc(S.comp.group)}. Siete clubes, catorce jornadas a doble vuelta; cada jornada descansa uno.</p></div>
  <section class="sec"><div class="sec-h"><h2>Clasificación</h2></div>${standingsTable(st)}<p class="source">${standingsSource()}</p></section>
  <section class="sec"><div class="sec-h"><h2>Evolución del Polo</h2></div>${evo.length? lineChart(evo,{invert:true,min:1,max:S.teams.length,unit:'º'}) : '<div class="empty">Sin jornadas disputadas.</div>'}</section>
  <section class="sec"><div class="sec-h"><h2>Calendario</h2><div class="chips"><button class="chip" data-act="liga-filter" data-v="0" aria-pressed="${!ui.ligaAll}">Solo el Polo</button><button class="chip" data-act="liga-filter" data-v="1" aria-pressed="${ui.ligaAll}">Todo</button></div></div><ul class="jlist stagger">`;
  for(let j=1;j<=NJ();j++){ const fs=S.fixtures.filter(f=>f.j===j), pf=fs.find(f=>f.home===POLO||f.away===POLO), d=fs[0];
    if(!ui.ligaAll){ if(pf){ const p=persp(pf);
        h+=`<li><a class="jrow ${nx&&nx.j===j?'next':''}" href="#jornada-${j}"><span class="jn">${j}<small>${esc(fdate(d))}</small></span><span><span class="vs">${p.home?'Polo contra '+esc(clubName(p.rival)):esc(clubName(p.rival))+' contra Polo'}</span><div class="meta">${p.home?'En casa':'Fuera'}, ${esc(d.time)} h</div></span><span class="score">${p.played?`${resBadge(p.ps>p.rs?'W':'L')} ${pf.hs}-${pf.as}`:'<span class="muted small">Pendiente</span>'}</span></a></li>`;
      } else h+=`<li><a class="jrow rest" href="#jornada-${j}"><span class="jn">${j}<small>${esc(fdate(d))}</small></span><span class="vs">Descansa el Polo</span><span></span></a></li>`;
    } else h+=`<li style="padding:12px 0;border-bottom:1px solid var(--line)"><a href="#jornada-${j}" style="text-decoration:none;display:flex;justify-content:space-between"><b>Jornada ${j}</b><span class="muted small">${esc(fdate(d,{weekday:'long',day:'numeric',month:'long'}))}</span></a>
      <table style="margin-top:4px"><tbody>${fs.map(f=>`<tr class="${f===pf?'us':''}"><td>${esc(team(f.home).name)} <span class="muted">contra</span> ${esc(team(f.away).name)}</td><td>${isPlayed(f)?`<b>${f.hs}-${f.as}</b>`:'<span class="muted">Pendiente</span>'}</td></tr>`).join('')}${pf?'':'<tr><td class="muted">Descansa: Polo</td><td></td></tr>'}</tbody></table></li>`; }
  return h+`</ul><p class="source">Fuente: calendario oficial FCT. Todos los partidos a las 15:00 en las pistas del club local.</p></section></div>`;
}

function vJornada(j){
  if(!(j>=1&&j<=NJ())) return vNotFound();
  const fs=S.fixtures.filter(f=>f.j===j), pf=fs.find(f=>f.home===POLO||f.away===POLO);
  let h=`<div class="wrap"><div class="pagehead"><div class="row" style="justify-content:space-between"><a class="textlink" href="#liga">Calendario</a><span class="row">${j>1?`<a class="chip" href="#jornada-${j-1}">J${j-1}</a>`:''}${j<NJ()?`<a class="chip" href="#jornada-${j+1}">J${j+1}</a>`:''}</span></div>
    <h1 style="margin-top:14px">Jornada ${j}</h1><p class="lede">${esc(fdate(fs[0],{weekday:'long',day:'numeric',month:'long',year:'numeric'}))}, ${esc(fs[0].time)} h</p></div>`;
  if(!pf) h+=`<section class="sec"><div class="empty">El Polo descansa en esta jornada.</div></section>`;
  else { const p=persp(pf), c=cronica(j), t=tie(j);
    h+=`<section class="sec">${scoreboard(pf,true)}${c?`<p class="cronica">${esc(c.txt)}<small>Crónica generada a partir de los resultados confirmados.${c.partial?' Faltan los resultados individuales.':''}</small></p>`:''}</section>`;
    if(S.published[jid(j)]) h+=`<section class="sec">${mvpCard(j)}${awardsLine(j)}${t?.moment?`<p class="cronica" style="font-size:1rem"><b>Momento de la jornada.</b> ${esc(t.moment)}</p>`:''}${pubVotes(j)}</section>`;
    const pst=posters(j);
    if(lineupVisible(j) && lineupList(j).length) h+=`<section class="sec"><div class="sec-h"><h2>Convocatoria</h2>${isAdmin&&!t.lineupPub?'<span class="muted small">Borrador, solo la ven los administradores</span>':''}</div>${lineupStrip(j)}<div class="row" style="margin-top:14px"><button class="btn" data-act="poster-open" data-j="${j}">Ver el cartel</button>${isAdmin?`<button class="btn ghost sm" data-act="go-admin" data-j="${j}" data-t="conv">Editar</button>`:''}</div></section>`;
    h+=`<section class="sec"><div class="sec-h"><h2>Partidos</h2></div>${pst? pst+`<div style="margin-top:14px">${t.rubbers.map((r,i)=>rubberRow(r,i,pf)).join('')}</div>` : '<div class="empty">El orden de juego aparecerá cuando el capitán publique la convocatoria.</div>'}</section>`;
    if(!isPlayed(pf)) h+=`<section class="sec"><div class="sec-h"><h2>Disponibilidad</h2>${isAdmin?`<button class="textlink" data-act="go-admin" data-j="${j}" data-t="disp">Panel del capitán</button>`:''}</div>${availBlock(pf)}</section>`;
    h+=`<section class="sec"><div class="sec-h"><h2>Porra</h2></div>${porraBlock(pf)}</section>`;
    if(pendingSurveys().includes(j)) h+=`<section class="sec"><div class="callout"><div><b>Tu encuesta de esta jornada</b><span>Solo la responden quienes jugaron.</span></div><div class="row"><a class="btn light" href="#votar">Responder</a></div></div></section>`;
    const hist=teamStats().vs[p.rival];
    h+=`<section class="sec"><div class="sec-h"><h2>Contra ${esc(clubName(p.rival))}</h2></div>${crest(p.rival,'')}${hist? `<p>Esta temporada: ${hist.w} ${hist.w===1?'victoria':'victorias'} y ${hist.l} ${hist.l===1?'derrota':'derrotas'}, ${hist.rw}-${hist.rl} en partidos.</p>`:'<p class="muted">Primer enfrentamiento de la temporada.</p>'}</section>`; }
  h+=`<section class="sec"><div class="sec-h"><h2>Resto de la jornada</h2></div><table><tbody>${fs.filter(f=>f!==pf).map(f=>`<tr><td>${esc(team(f.home).name)} <span class="muted">contra</span> ${esc(team(f.away).name)}</td><td>${isPlayed(f)?`<b>${f.hs}-${f.as}</b>`:'<span class="muted">Pendiente</span>'}</td></tr>`).join('')}</tbody></table><p class="source">Fuente: FCT.</p></section></div>`;
  return h;
}
function awardsLine(j){ const p=S.published[jid(j)]; if(!p) return '';
  return `<div class="awards stagger" style="margin-top:16px"><div class="award"><span>MVP</span><b>${p.mvp?plink(p.mvp):'–'}</b></div><div class="award"><span>Revelación</span><b>${p.rev?plink(p.rev):'–'}</b></div><div class="award"><span>Mejor partido</span><b>${p.best? esc(RUBBERS[+p.best-1]?.label||p.best):'–'}</b></div><div class="award"><span>Nota del equipo</span><b>${p.ratings?.q_jornada? dec(p.ratings.q_jornada):'–'}</b></div></div>`; }
function pubVotes(j){ const p=S.published[jid(j)]; if(!p?.votes) return ''; const qs=S.survey.questions.filter(q=>q.scope==='peer'&&p.votes[q.id]); if(!qs.length) return '';
  return `<div class="rgrid" style="margin-top:24px">${qs.map(q=>{ const top=Object.entries(p.votes[q.id]).sort((a,b)=>b[1]-a[1]).slice(0,3);
    return `<div class="rank"><h3>${esc(q.text)}</h3><ol class="stagger">${top.map(([pid,n])=>`<li>${avatar(player(pid),'sm')}${plink(pid)}<b>${n}</b></li>`).join('')}</ol></div>`; }).join('')}</div><p class="source">Votos agregados de ${p.n||0} ${p.n===1?'respuesta':'respuestas'}. No se muestra quién votó a quién.</p>`; }
const PORRA_OPTS=[[4,0],[3,1],[3,2],[2,3],[1,3],[0,4]];
function porraBlock(f){
  const k=jid(f.j), locked=Date.now()>=kickoff(f).getTime(), p=persp(f), mine=me? picks[me]?.j?.[k] : null;
  const all=Object.entries(picks).map(([pid,v])=>({pid,pk:v.j?.[k]})).filter(x=>x.pk);
  let h='';
  if(!locked && me) h+=`<p class="muted small">¿Cómo acabará? Se cierra al empezar la jornada.</p><div class="chips" style="margin:10px 0">${PORRA_OPTS.map(([a,b])=>`<button class="chip" data-act="pick" data-j="${f.j}" data-p="${a}" data-r="${b}" aria-pressed="${mine&&mine.p===a&&mine.r===b}">Polo ${a}-${b}</button>`).join('')}</div>`;
  if(all.length) h+=`<table class="stagger" style="margin-top:6px"><tbody>${all.map(x=>{ let pts=''; if(isPlayed(f)){ const s=porraPoints(x.pk,p); pts=`<b>${s} ${s===1?'punto':'puntos'}</b>`; } return `<tr><td>${plink(x.pid)}</td><td>Polo ${x.pk.p}-${x.pk.r}</td><td>${pts}</td></tr>`; }).join('')}</tbody></table>`;
  else h+=`<p class="muted small">Todavía no hay pronósticos.</p>`;
  return h;
}
function porraPoints(pk,p){ if(!p.played) return 0; if(pk.p===p.ps&&pk.r===p.rs) return 3; if((pk.p>pk.r)===(p.ps>p.rs)) return 1; return 0; }

function vEquipo(){
  const cap=S.players.find(p=>p.captain);
  return `<div class="wrap"><div class="pagehead"><h1>El equipo</h1><p class="lede">Plantilla del Polo A para la temporada ${esc(S.seasonId||viewSeason)}, en el orden de la lista del equipo. Capitán: ${esc(cap?.name||'')}. Toca a un jugador para ver sus números.</p></div>
  <section class="sec"><div class="pgrid stagger">${S.players.filter(p=>p.active!==false).sort((a,b)=>a.order-b.order).map(p=>{ const st=playerStats(p.id);
    return `<button class="pcard" data-player="${esc(p.id)}">${avatar(p)}<span><span class="nm">${esc(p.name)}${p.captain?'<span class="cap">Capitán</span>':''}</span><span class="sub">Nº ${p.order}, ${esc(p.cat)}</span></span><span class="rec">${st.pj? st.w+'-'+st.l : '<span class="muted small">0 PJ</span>'}</span></button>`; }).join('')}</div>
  <p class="source">Fuente: listado FCT del equipo. Balance: partidos con resultado introducido.</p></section></div>`;
}
function vJugador(id){
  const p=player(id); if(!p) return vNotFound(); const st=playerStats(id), ins=insights(id), own=me===id;
  let h=`<div class="wrap"><div class="phead">${avatar(p,'lg')}<div><h1>${esc(p.name)}</h1><p>${esc(p.full)}. Nº ${p.order} del equipo, ${esc(p.cat)}, ${p.pts} puntos de ranking FCT.${p.captain?' Capitán.':''}</p></div></div>
  <section class="sec"><div class="row" style="gap:22px;align-items:center">${ring(st.pj?st.wr:null,'victorias')}<div class="figs stagger" style="flex:1;min-width:260px">
    <div class="fig"><b>${count(st.pj)}</b><span>jugados</span></div><div class="fig"><b>${st.w}-${st.l}</b><span>balance</span></div><div class="fig"><b>${st.sw}-${st.sl}</b><span>sets</span></div><div class="fig"><b>${st.streak.n?(st.streak.t==='W'?'+':'−')+st.streak.n:'–'}</b><span>racha</span></div></div></div>
    <div class="row" style="justify-content:space-between;margin-top:14px"><span>${formStrip(st.seq,8)} <span class="muted small">últimos partidos</span></span><a class="textlink" href="#stats" data-act="cmp" data-id="${esc(id)}">Comparar con un compañero</a></div></section>
  <section class="sec"><div class="split"><div><div class="sec-h"><h2>Lectura del rendimiento</h2></div>${ins.length? `<ul class="insights stagger">${ins.map(i=>`<li>${esc(i.t)}<small>Fuente: ${esc(i.s)}</small></li>`).join('')}</ul>` : '<div class="empty">El análisis aparecerá cuando tenga partidos con resultado o votos publicados.</div>'}</div>
    <div><div class="sec-h"><h2>Perfil</h2></div>${profileMeters(id,st)}</div></div></section>`;
  h+=availProfile(id);
  if(own) h+=privateBlock();
  h+=`<section class="sec"><div class="sec-h"><h2>Partido a partido</h2></div>${st.matches.length? `<div class="tscroll"><table><thead><tr><th>Jornada</th><th class="l">Contra</th><th>Partido</th><th>Marcador</th><th>Resultado</th></tr></thead><tbody class="stagger">${st.matches.map(m=>`<tr><td><a href="#jornada-${m.j}">J${m.j}</a></td><td class="l">${esc(clubName(persp(poloFix(m.j)).rival))}</td><td>${m.r.type==='D'?'Dobles':'Ind. '+m.r.n}</td><td>${m.c.sets.map(s=>s.join('-')).join(' ')}</td><td>${resBadge(m.c.res)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">Sin partidos con resultado todavía.</div>'}</section>`;
  const vs=Object.entries(st.vs);
  h+=`<section class="sec"><div class="split"><div><div class="sec-h"><h2>Por posición</h2></div>${Object.keys(st.byPos).length? `<table><tbody>${Object.entries(st.byPos).map(([n,v])=>`<tr><td>${n==='D'?'Dobles':'Individual '+n}</td><td>${v.w}-${v.l}</td><td>${pct(v.w,v.w+v.l)}%</td></tr>`).join('')}</tbody></table>`:'<div class="empty">Sin datos.</div>'}</div>
    <div><div class="sec-h"><h2>Por club rival</h2></div>${vs.length? `<table><tbody>${vs.map(([c,v])=>`<tr><td>${esc(clubName(c))}</td><td>${v.w}-${v.l}</td></tr>`).join('')}</tbody></table>`:'<div class="empty">Sin datos.</div>'}</div></div></section></div>`;
  return h;
}
function profileMeters(id,st){
  const mx=Math.max(1,...S.players.map(p=>totalVotes(p.id)));
  return [meter('Rendimiento','% de victorias',st.pj?st.wr:null,st.pj?pct(st.w,st.pj)+'%':'–'),
    meter('Consistencia','jornadas con balance ≥ 0',st.njor?st.consist:null,st.njor?Math.round(st.consist*st.njor)+'/'+st.njor:'–'),
    meter('Juegos ganados','% del total',st.gw+st.gl?st.gw/(st.gw+st.gl):null,st.gw+st.gl?pct(st.gw,st.gw+st.gl)+'%':'–'),
    meter('Actitud','votos de compañeros',votesFor(id,'q_actitud')/mx,votesFor(id,'q_actitud')),
    meter('Compañerismo','votos de compañeros',votesFor(id,'q_companero')/mx,votesFor(id,'q_companero')),
    meter('Reconocimiento','votos totales',totalVotes(id)/mx,totalVotes(id))].join('');
}
function privateBlock(){
  const ins=privateInsights(), r=selfSeries('s_rend');
  const dims=SELF_DIMS.map(([k,l])=>{ const s=selfSeries(k), avg=s.length? sum(s.map(x=>x.v))/s.length : null; return meter(l,'tu media',avg?avg/10:null,avg?dec(avg):'–','sv'); }).join('');
  const notes=myBallot?.j? Object.entries(myBallot.j).sort((a,b)=>+b[0].slice(1)-+a[0].slice(1)).map(([k,v])=>v.a?.s_mejorar?`<li class="sv">${esc(v.a.s_mejorar)}<small>J${k.slice(1)}, lo que querías mejorar</small></li>`:'').join('') : '';
  return `<section class="sec"><div class="panel"><div class="sec-h"><h2>Tu lectura privada</h2></div><p class="muted small" style="margin-top:-6px">Solo tú ves este bloque, además de los administradores que gestionan las encuestas. Son tus propias respuestas, no datos oficiales.</p>
    <div class="split" style="margin-top:12px"><div>${dims}${r.length>=2? lineChart(r,{min:1,max:10,h:150,labels:false}):''}</div><div>${ins.length||notes? `<ul class="insights">${ins.map(t=>`<li class="sv">${esc(t)}<small>Fuente: tus encuestas</small></li>`).join('')}${notes}</ul>` : '<div class="empty">Responde a las encuestas de cada jornada y aquí verás tu evolución.</div>'}</div></div></div></section>`;
}

function vStats(){
  const tabs=[['equipo','Equipo'],['jugadores','Jugadores'],['disponibilidad','Disponibilidad'],['rankings','Rankings'],['records','Récords']];
  let h=`<div class="wrap"><div class="pagehead"><h1>Estadísticas</h1><p class="lede">Calculadas con los resultados introducidos. Las encuestas solo alimentan los rankings de votos.</p></div>
  <div class="chips" style="margin-top:18px">${tabs.map(([k,l])=>`<button class="chip" data-act="stats-tab" data-v="${k}" aria-pressed="${ui.statsTab===k}">${l}</button>`).join('')}</div>`;
  return h+(ui.statsTab==='equipo'?statsEquipo():ui.statsTab==='jugadores'?statsJugadores():ui.statsTab==='disponibilidad'?statsDisponibilidad():ui.statsTab==='rankings'?statsRankings():statsRecords())+`</div>`;
}
function statsEquipo(){
  const ts=teamStats(), evo=playedJornadas().map(j=>({j,v:standings(j).find(r=>r.id===POLO).pos}));
  let h=`<section class="sec"><div class="figs stagger"><div class="fig"><b>${ts.tw}-${ts.tl}</b><span>eliminatorias</span></div><div class="fig"><b>${ts.rw+ts.rl? count(pct(ts.rw,ts.rw+ts.rl),'%'):'–'}</b><span>partidos ganados (${ts.rw}-${ts.rl})</span></div><div class="fig"><b>${ts.sw}-${ts.sl}</b><span>sets</span></div><div class="fig"><b>${ts.dbl.w}-${ts.dbl.l}</b><span>dobles decisivos</span></div></div>
    <p class="source">Eliminatorias y partidos: marcador oficial. Sets, juegos y dobles: partidos con marcador introducido.</p></section>
  <section class="sec"><div class="sec-h"><h2>Partidos por jornada</h2></div>${barsChart(ts.byJ.map(b=>({j:b.j,a:b.ps,b:b.rs})))}<div class="legend"><span><i style="background:var(--win)"></i>Ganados</span><span><i style="background:var(--loss)"></i>Perdidos</span></div></section>
  <section class="sec"><div class="split"><div><div class="sec-h"><h2>Contra cada club</h2></div><table><tbody class="stagger">${S.teams.filter(t=>t.id!==POLO).map(t=>{ const v=ts.vs[t.id]; return `<tr><td>${esc(t.name)}</td><td>${v?v.w+'-'+v.l:'<span class="muted">Pendiente</span>'}</td><td>${v?v.rw+'-'+v.rl:''}</td></tr>`; }).join('')}</tbody></table></div>
  <div><div class="sec-h"><h2>Posición</h2></div>${evo.length? lineChart(evo,{invert:true,min:1,max:S.teams.length,unit:'º',h:200}):'<div class="empty">Sin datos.</div>'}</div></div></section>`;
  const sv=Object.entries(S.published).filter(([,p])=>p.ratings?.q_jornada).map(([k,p])=>({j:+k.slice(1),v:p.ratings.q_jornada}));
  if(sv.length) h+=`<section class="sec"><div class="sec-h"><h2>Nota del equipo a cada jornada</h2></div>${lineChart(sv,{min:1,max:10,h:160})}<p class="source">Media de la encuesta publicada.</p></section>`;
  return h;
}
function statsJugadores(){
  const rows=S.players.filter(p=>p.active!==false).map(p=>({p,st:playerStats(p.id)})), key=ui.sortKey;
  const val=r=> key==='wr'?r.st.wr : key==='sd'?r.st.sw-r.st.sl : key==='gd'?r.st.gw-r.st.gl : key==='pj'?r.st.pj : key==='streak'?r.st.bestStreak : r.st.w;
  rows.sort((a,b)=>val(b)-val(a)||b.st.pj-a.st.pj||a.p.order-b.p.order);
  const th=(k,l)=>`<th><button data-act="sort" data-v="${k}">${l}${key===k?' ↓':''}</button></th>`;
  let h=`<section class="sec"><div class="tscroll"><table><thead><tr><th>Jugador</th>${th('pj','PJ')}${th('w','G')}<th>P</th>${th('wr','%')}${th('sd','Sets')}${th('gd','Juegos')}${th('streak','Racha')}<th class="l">Forma</th></tr></thead><tbody class="stagger">
    ${rows.map(({p,st})=>`<tr><td>${plink(p.id)}</td><td>${st.pj}</td><td>${st.w}</td><td>${st.l}</td><td>${st.pj?pct(st.w,st.pj)+'%':'–'}</td><td>${st.sw}-${st.sl}</td><td>${st.gw}-${st.gl}</td><td>${st.bestStreak}</td><td class="l">${formStrip(st.seq)}</td></tr>`).join('')}</tbody></table></div></section>`;
  const opts=sel=>S.players.map(p=>`<option value="${esc(p.id)}" ${sel===p.id?'selected':''}>${esc(p.name)}</option>`).join('');
  const a=ui.cmpA||S.players[0].id, b=ui.cmpB||(a===S.players[1].id?S.players[0].id:S.players[1].id), A=playerStats(a), Bs=playerStats(b);
  const rowsC=[['Jugados',A.pj,Bs.pj],['Victorias',A.w,Bs.w],['% victorias',A.pj?pct(A.w,A.pj):0,Bs.pj?pct(Bs.w,Bs.pj):0],['Dif. de sets',A.sw-A.sl,Bs.sw-Bs.sl],['Dif. de juegos',A.gw-A.gl,Bs.gw-Bs.gl],['Mejor racha',A.bestStreak,Bs.bestStreak],['MVP',mvpCount(a),mvpCount(b)],['Votos',totalVotes(a),totalVotes(b)],['% disponible',Math.round((availStats(a).pct||0)*100),Math.round((availStats(b).pct||0)*100)],['Convocatorias',availStats(a).conv,availStats(b).conv]];
  const mx=rowsC.map(([,x,y])=>Math.max(Math.abs(x),Math.abs(y),1));
  h+=`<section class="sec"><div class="sec-h"><h2>Cara a cara</h2></div><div class="row" style="flex-wrap:nowrap"><select data-act="cmp-a" aria-label="Jugador A">${opts(a)}</select><span class="muted">y</span><select data-act="cmp-b" aria-label="Jugador B">${opts(b)}</select></div>
    <div class="row" style="justify-content:space-between;margin:16px 0 4px">${avatar(player(a),'lg')}${avatar(player(b),'lg')}</div>
    ${rowsC.map(([l,x,y],i)=>`<div style="display:grid;grid-template-columns:1fr auto 1fr;gap:10px;align-items:center;padding:8px 0;border-bottom:1px solid var(--line)">
      <div class="meter" style="grid-template-columns:1fr 40px;padding:0"><span class="bar" style="transform:scaleX(-1)"><i data-w="${Math.round(Math.max(0,x)/mx[i]*100)}"></i></span><b style="${x>y?'':'font-weight:400'}">${x}</b></div>
      <span class="muted small" style="min-width:90px;text-align:center">${l}</span>
      <div class="meter" style="grid-template-columns:40px 1fr;padding:0"><b style="text-align:left;${y>x?'':'font-weight:400'}">${y}</b><span class="bar"><i class="sv" data-w="${Math.round(Math.max(0,y)/mx[i]*100)}"></i></span></div></div>`).join('')}</section>`;
  return h;
}
function statsRankings(){
  const f=ui.rankFilter==='season'? null : +ui.rankFilter, pl=S.players.filter(p=>p.active!==false);
  const mk=(title,def,fn,fmt=v=>v)=>{ const list=pl.map(p=>({p,v:fn(p.id)})).filter(x=>x.v!=null).sort((a,b)=>b.v-a.v).slice(0,5);
    return `<div class="rank"><h3>${title}</h3><p class="def">${def}</p>${list.length? `<ol class="stagger">${list.map(x=>`<li>${avatar(x.p,'sm')}${plink(x.p.id)}<b>${fmt(x.v)}</b></li>`).join('')}</ol>`:'<div class="empty">Sin datos todavía.</div>'}</div>`; };
  const evo=id=>{ const st=playerStats(id), js=[...st.jornadas].sort((a,b)=>a-b); if(js.length<4) return null; const wr=a=>{ let w=0,n=0; a.forEach(j=>{ w+=st.byJ[j].w; n+=st.byJ[j].w+st.byJ[j].l; }); return n?w/n:0; }; return Math.round((wr(js.slice(-3))-wr(js.slice(0,-3)))*100); };
  const porra=id=>{ const v=picks[id]; if(!v) return null; let s=0; Object.entries(v.j||{}).forEach(([k,pk])=>{ const fx=poloFix(+k.slice(1)); if(fx&&isPlayed(fx)&&(!f||f===+k.slice(1))) s+=porraPoints(pk,persp(fx)); }); return s; };
  return `<section class="sec"><select data-act="rank-filter" style="max-width:280px"><option value="season">Temporada ${esc(S.seasonId||viewSeason)} completa</option>${Array.from({length:NJ()},(_,i)=>i+1).filter(j=>poloFix(j)).map(j=>`<option value="${j}" ${ui.rankFilter==j?'selected':''}>Jornada ${j}</option>`).join('')}</select></section>
  <section class="sec"><div class="sec-h"><h2>En la pista</h2></div><div class="rgrid">
    ${mk('Victorias','Partidos ganados.',id=>playerStats(id,f).w||null)}
    ${mk('Porcentaje de victorias','Mínimo 2 partidos.',id=>{ const s=playerStats(id,f); return s.pj>=2?Math.round(s.wr*100):null; },v=>v+'%')}
    ${mk('Consistencia','Jornadas con balance positivo o igualado, mínimo 2.',id=>{ const s=playerStats(id,f); return s.njor>=2?Math.round(s.consist*100):null; },v=>v+'%')}
    ${mk('Evolución','% de victorias en sus 3 últimas jornadas frente a las anteriores, mínimo 4.',id=>f?null:evo(id),v=>(v>0?'+':'')+v)}</div></section>
  <section class="sec"><div class="sec-h"><h2>En el vestuario</h2></div><div class="rgrid">
    ${mk('MVP','Veces MVP de la jornada.',id=>mvpCount(id,f)||null)}
    ${mk('Mejor actitud','Votos de los compañeros.',id=>votesFor(id,'q_actitud',f)||null)}
    ${mk('Mejor compañero','Votos de los compañeros.',id=>votesFor(id,'q_companero',f)||null)}
    ${mk('Más votado','Votos recibidos en todas las preguntas.',id=>totalVotes(id,f)||null)}
    ${mk('Porra','3 puntos por marcador exacto, 1 por acertar el ganador.',id=>porra(id))}
    ${mk('Disponibilidad','% de jornadas cerradas en las que dijo «disponible».',id=>{ const a=availStats(id); return a.total? Math.round(a.pct*100) : null; },v=>v+'%')}
    ${mk('Convocatorias','Veces convocado.',id=>availStats(id).conv||null)}</div><p class="source">Votos de las encuestas publicadas por el capitán.</p></section>`;
}
function statsRecords(){
  const all=[]; S.players.forEach(p=>playerStats(p.id).matches.forEach(m=>{ if(m.r.type==='S'||m.r.polo[0]===p.id) all.push({p,...m}); }));
  const ts=teamStats(), recs=[], top=fn=>S.players.map(p=>({p,v:fn(playerStats(p.id))})).sort((a,b)=>b.v-a.v)[0];
  const bt=ts.byJ.slice().sort((a,b)=>(b.ps-b.rs)-(a.ps-a.rs))[0]; if(bt&&bt.ps>bt.rs) recs.push(['Mayor victoria por equipos',`Polo ${bt.ps}-${bt.rs} ${clubName(bt.rival)}, J${bt.j}`]);
  const lg=all.slice().sort((a,b)=>(b.c.gw+b.c.gl)-(a.c.gw+a.c.gl))[0]; if(lg) recs.push(['Partido con más juegos',`${lg.r.polo.map(pname).join(' y ')}: ${lg.c.sets.map(s=>s.join('-')).join(' ')}, J${lg.j}`]);
  let t=top(s=>s.bestStreak); if(t&&t.v>=2) recs.push(['Racha más larga',`${t.p.name}, ${t.v} victorias seguidas`]);
  t=top(s=>s.bagels); if(t&&t.v) recs.push(['Más sets ganados 6-0',`${t.p.name}, ${t.v}`]);
  t=top(s=>s.comebacks); if(t&&t.v) recs.push(['Más remontadas',`${t.p.name}, ${t.v}`]);
  t=top(s=>s.three.w); if(t&&t.v) recs.push(['Más victorias a tres sets',`${t.p.name}, ${t.v}`]);
  const mv=S.players.map(p=>({p,v:mvpCount(p.id)})).sort((a,b)=>b.v-a.v)[0]; if(mv&&mv.v) recs.push(['Más veces MVP',`${mv.p.name}, ${mv.v}`]);
  const nThree=all.filter(x=>x.c.three).length, nTb=sum(all.map(x=>x.c.tbs));
  return `<section class="sec"><div class="sec-h"><h2>Récords de la temporada</h2></div>${recs.length? `<table><tbody class="stagger">${recs.map(([a,b])=>`<tr><td class="muted">${esc(a)}</td><td>${esc(b)}</td></tr>`).join('')}</tbody></table>`:'<div class="empty">Los récords aparecerán cuando haya resultados individuales.</div>'}</section>
  <section class="sec"><div class="sec-h"><h2>Curiosidades</h2></div><ul class="insights stagger"><li>${all.length} partidos con marcador introducido.</li><li>${nThree} se han ido al tercer set y ${nTb} sets se han decidido en tie-break.</li><li>${ts.dbl.w+ts.dbl.l} dobles decisivos jugados (${ts.dbl.w} ganados).</li><li>${playedJornadas().length} de ${NJ()} jornadas disputadas en la liga.</li></ul></section>`;
}


/* ---------------- Disponibilidad: página del jugador ---------------- */
function vDisponibilidad(j){
  const f=poloFix(j); if(!f) return vNotFound();
  const p=persp(f), mine=avOf(me,j), note=noteOf(me,j), dl=deadline(j), locked=(deadlinePassed(j)||isPlayed(f)) && !isAdmin;
  const draft = ui.avDraft && ui.avDraft.j===j ? ui.avDraft : (ui.avDraft={j, s:mine?.s||null, c:note?.c||''});
  const opt=(k,ico,sub)=>`<button class="avopt ${k} press" data-act="av-pick" data-v="${k}" aria-pressed="${draft.s===k}" ${locked?'disabled':''}><span class="ico">${ico}</span><span><b>${AV_LABEL[k]}</b><small>${sub}</small></span></button>`;
  return `<div class="wrap"><div class="survey" style="padding-top:28px">
    <p class="qsec">Jornada ${j}, disponibilidad</p>
    <div class="avhead">${crest(p.rival,'')}<div><h1 class="q" style="margin:0">Polo contra ${esc(clubName(p.rival))}</h1><p class="muted" style="margin:4px 0 0">${esc(fdate(f,{weekday:'long',day:'numeric',month:'long'}))}, ${esc(f.time)} h. ${p.home?'En casa.':'Fuera, en las pistas del '+esc(clubName(p.rival))+'.'}</p></div></div>
    <div class="notice" style="margin:16px 0">${locked? 'El plazo para responder terminó el '+esc(fmtDT(dl))+'. Si necesitas cambiar algo, habla con el capitán.' : 'Puedes cambiar tu respuesta hasta el <b>'+esc(fmtDT(dl))+'</b>.'}</div>
    <div class="avopts">${opt('yes','✓','Cuenta conmigo')}${opt('maybe','?','Lo confirmo antes del plazo')}${opt('no','✕','Esta vez no puedo')}</div>
    <label class="f" for="av-c">Comentario para el capitán (opcional, solo lo ven los capitanes)</label>
    <textarea id="av-c" data-act="av-text" ${locked?'disabled':''} placeholder="Por ejemplo: puedo jugar a partir de las 12:00">${esc(draft.c||'')}</textarea>
    <div class="chips" style="margin-top:8px">${AV_CHIPS.map(c=>`<button class="chip" data-act="av-chip" data-v="${esc(c)}" ${locked?'disabled':''}>${esc(c)}</button>`).join('')}</div>
    <div class="row" style="margin-top:18px;justify-content:space-between"><span class="muted small">${mine?.at? 'Última respuesta '+relTime(mine.at)+': '+AV_LABEL[mine.s] : 'Aún no has respondido'}</span>
      <button class="btn brass" data-act="av-save" data-j="${j}" ${locked||!draft.s?'disabled':''}>${mine?'Actualizar respuesta':'Enviar respuesta'}</button></div>
    <section class="sec"><div class="sec-h"><h2 style="font-size:1.4rem">Cómo va el equipo</h2><a href="#jornada-${j}">Ver la jornada</a></div>${availSummary(j)}</section>
  </div></div>`;
}
function lineupStrip(j){
  const roles=rolesOf(j), list=lineupList(j);
  return `<div class="lineup stagger">${list.map(pid=>{ const pl=player(pid), r=roles[pid]||[]; return `<button class="lucard press" data-player="${esc(pid)}">${avatar(pl)}<span class="nm">${esc(pl?.name||'')}</span><span class="rl ${r[0]==='Suplente'?'sub':''}">${esc(r.join(' + '))}</span></button>`; }).join('')}</div>`;
}
/* ---------------- Estadísticas de disponibilidad ---------------- */
function avStrip(seq){ return `<span class="avstrip">${seq.map(x=>`<i class="${x.s} ${x.c?'c':''}" title="J${x.j}: ${AV_LABEL[x.s]}${x.c?', convocado':''}"></i>`).join('')}</span>`; }
function statsDisponibilidad(){
  const rows=S.players.filter(p=>p.active!==false).map(p=>({p,a:availStats(p.id)}));
  const key=ui.avSort||'pct'; const v=r=> key==='pct'? (r.a.pct??-1) : key==='conv'? r.a.conv : key==='none'? r.a.none : key==='ync'? r.a.yesNotConv : r.a.yes;
  rows.sort((x,y)=>v(y)-v(x)||x.p.order-y.p.order);
  const js=closedJornadas(); const th=(k,l)=>`<th><button data-act="av-sort" data-v="${k}">${l}${key===k?' ↓':''}</button></th>`;
  const team=js.map(j=>{ const a=availFor(j); return {j,v:a.total? Math.round(a.yes.length*100/a.total) : 0}; });
  return `<section class="sec"><p class="lede">Disponibilidad declarada frente a convocatoria. Cuentan las jornadas del Polo con el plazo cerrado o ya disputadas (${js.length}). «Sin respuesta» se cuenta aparte de «No disponible».</p></section>
  <section class="sec"><div class="tscroll"><table><thead><tr><th>Jugador</th><th>Jornadas</th>${th('yes','Disp.')}<th>No</th><th>Pend.</th>${th('none','Sin resp.')}${th('pct','%')}${th('conv','Convoc.')}${th('ync','Disp. no conv.')}<th class="l">Evolución</th></tr></thead><tbody class="stagger">
    ${rows.map(({p,a})=>`<tr><td>${plink(p.id)}</td><td>${a.total}</td><td>${a.yes}</td><td>${a.no}</td><td>${a.maybe}</td><td>${a.none}</td><td><b>${a.pct==null?'–':dec(a.pct*100)+' %'}</b></td><td>${a.conv}</td><td>${a.yesNotConv}</td><td class="l">${avStrip(a.seq)}</td></tr>`).join('')}</tbody></table></div>
    <div class="legend"><span><i style="background:var(--win)"></i>Disponible</span><span><i style="background:var(--brass)"></i>Pendiente</span><span><i style="background:var(--loss)"></i>No disponible</span><span><i style="background:var(--surface2)"></i>Sin respuesta</span><span><i style="background:transparent;box-shadow:inset 0 0 0 2px var(--ink)"></i>Convocado</span></div></section>
  ${team.length?`<section class="sec"><div class="sec-h"><h2>Disponibilidad del equipo por jornada</h2></div>${barsPct(team)}</section>`:''}`;
}
function barsPct(items,h=160){
  const W=600,pad={l:30,r:8,t:10,b:24},n=Math.max(1,NJ()),bw=(W-pad.l-pad.r)/n; let g='';
  [0,50,100].forEach(v=>{ const y=pad.t+(1-v/100)*(h-pad.t-pad.b); g+=`<line x1="${pad.l}" x2="${W-pad.r}" y1="${y}" y2="${y}" stroke="var(--line)"/><text x="${pad.l-6}" y="${y+4}" text-anchor="end">${v}%</text>`; });
  for(let j=1;j<=n;j++){ const it=items.find(i=>i.j===j), cx=pad.l+(j-.5)*bw; g+=`<text x="${cx}" y="${h-6}" text-anchor="middle">J${j}</text>`;
    if(it){ const hh=it.v/100*(h-pad.t-pad.b); g+=`<rect class="br" style="--k:${j}" x="${cx-bw*.3}" y="${h-pad.b-hh}" width="${bw*.6}" height="${hh}" rx="3" fill="var(--green2)"/>`; } }
  return `<svg class="chart" viewBox="0 0 ${W} ${h}" role="img">${g}</svg>`;
}
function availProfile(pid){
  const a=availStats(pid);
  return `<section class="sec"><div class="sec-h"><h2>Disponibilidad</h2></div>${a.total? `<div class="figs stagger"><div class="fig"><b>${a.pct==null?'–':count(Math.round(a.pct*100),'%')}</b><span>disponible (${a.yes} de ${a.total})</span></div><div class="fig"><b>${a.no}/${a.maybe}</b><span>no disponible / pendiente</span></div><div class="fig"><b>${a.none}</b><span>sin responder</span></div><div class="fig"><b>${a.conv}</b><span>convocatorias${a.yesNotConv?`, ${a.yesNotConv} disponible sin convocar`:''}</span></div></div><div style="margin-top:12px">${avStrip(a.seq)}</div>` : '<div class="empty">Aún no hay jornadas con el plazo de disponibilidad cerrado.</div>'}</section>`;
}

/* ---------------- Votar ---------------- */
function vVotar(){
  let h=`<div class="wrap"><div class="pagehead"><h1>Votar</h1><p class="lede">Quién juega antes de la jornada, encuesta para los que jugaron después, MVP y porra.</p></div>`;
  if(!me) return h+`<section class="sec"><div class="notice">Tu usuario de administrador no está ligado a ningún jugador. <button class="textlink" data-act="unskip">Elegir mi nombre</button></div></section></div>`;
  const nx=nextPoloFix();
  if(nx) h+=`<section class="sec"><div class="sec-h"><h2>Jornada ${nx.j}</h2><a href="#jornada-${nx.j}">Ver jornada</a></div>${availBlock(nx)}</section>`;
  const pend=pendingSurveys();
  if(ui.survey) h+=`<section class="sec">${surveyCard()}</section>`;
  else if(pend.length) h+=`<section class="sec">${pend.map(j=>`<div class="panel done" style="margin-bottom:12px"><p class="q">Encuesta de la jornada ${j}</p><p class="muted">${surveyQuestions().length} preguntas rápidas. Las de compañeros se publican solo como votos agregados; lo tuyo y los comentarios son privados.</p><button class="btn brass" data-act="survey-start" data-j="${j}">Empezar</button></div>`).join('')}</section>`;
  else { const done=Object.keys(myBallot?.j||{}).sort((a,b)=>+b.slice(1)-+a.slice(1));
    h+=`<section class="sec"><div class="empty">No tienes encuestas pendientes. Se abren cuando se cargan los resultados de una jornada en la que has jugado.</div>${done.length?`<p class="source">Respondidas: ${done.map(k=>`J${k.slice(1)} <button class="textlink" data-act="survey-start" data-j="${k.slice(1)}">cambiar</button>`).join(', ')}</p>`:''}</section>`; }
  if(nx) h+=`<section class="sec"><div class="sec-h"><h2>Porra de la jornada ${nx.j}</h2></div>${porraBlock(nx)}</section>`;
  const pubs=Object.keys(S.published).filter(k=>S.published[k].mvp).sort((a,b)=>+b.slice(1)-+a.slice(1));
  if(pubs.length) h+=`<section class="sec"><div class="sec-h"><h2>MVP de la temporada</h2></div><div class="stagger">${pubs.map(k=>mvpCard(+k.slice(1))).join('')}</div></section>`;
  return h+`</div>`;
}
const surveyQuestions = () => S.survey.questions.filter(q=>q.text&&q.type);
function surveyCard(){
  const qs=surveyQuestions(), j=ui.survey.j, i=ui.survey.step;
  if(i>=qs.length) return `<div class="survey"><div class="prog"><i style="width:100%"></i></div><p class="q">Todo listo</p><p class="qsec">Revisa si quieres o envía tus respuestas de la jornada ${j}.</p><div class="nav"><button class="btn ghost" data-act="survey-prev">Atrás</button><button class="btn brass" data-act="survey-send">Enviar respuestas</button></div></div>`;
  const q=qs[i], a=ui.survey.a[q.id]; let body='';
  if(q.type==='scale') body=`<div class="scale">${Array.from({length:10},(_,n)=>`<button data-act="ans" data-q="${q.id}" data-v="${n+1}" aria-pressed="${a===n+1}">${n+1}</button>`).join('')}</div>`;
  else if(q.type==='player'){ const list=participants(j).map(player).filter(Boolean).filter(p=>p.id!==me);
    body=`<div class="picker">${list.map(p=>`<button data-act="ans" data-q="${q.id}" data-v="${esc(p.id)}" aria-pressed="${a===p.id}">${avatar(p)}${esc(p.name)}</button>`).join('')}</div>`; }
  else body=`<textarea data-act="ans-text" data-q="${q.id}" placeholder="Escribe aquí (opcional)" style="margin:20px 0">${esc(a||'')}</textarea>`;
  return `<div class="survey"><div class="qsec">Jornada ${j}. ${esc(SCOPE_LABEL[q.scope]||'')}, ${i+1} de ${qs.length}</div><div class="prog"><i style="width:${Math.round(i*100/qs.length)}%"></i></div>
    <div class="qbody" key="${i}"><p class="q">${esc(q.text)}</p>${body}</div>
    <div class="nav"><button class="btn ghost" data-act="survey-prev" ${i===0?'disabled':''}>Atrás</button><button class="btn" data-act="survey-next">${a!=null&&a!==''?'Siguiente':'Saltar'}</button></div></div>`;
}

/* ---------------- Puerta de acceso ---------------- */
function vLogin(){
  return `<div class="gatebox">${courtSVG()}<span class="ball" aria-hidden="true"></span><div class="inner">
    <p class="hero-comp">${esc(S.comp.name)}, ${esc(S.comp.group)}</p><h1 class="hero-title" aria-label="Polo A">${titleLetters('Polo A')}</h1>
    <p class="hero-sub">${route().startsWith('disponibilidad-')? 'Entra para decir si puedes jugar la jornada '+esc(route().slice(15))+'.' : 'La app privada del equipo masculino absoluto del Real Club de Polo de Barcelona.'}</p>
    <button class="gbtn" data-act="signin"><svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>Entrar con Google</button>
    <p class="small" style="color:var(--onGreenMuted);margin-top:14px">Después eliges tu nombre de la lista del equipo. Solo se hace una vez: tu nombre queda ligado a tu Gmail en cualquier dispositivo.</p></div></div>`;
}
function vClaim(){
  const taken=new Set(Object.keys(claims).filter(pid=>claims[pid]?.email!==authUser.email));
  return `<div class="wrap" style="padding-top:30px;padding-bottom:40px"><p class="muted small">Has entrado como ${esc(authUser.email)}. <button class="textlink" data-act="signout">Cambiar de cuenta</button></p>
    <h1 class="q" style="font-size:clamp(2.2rem,8vw,3.2rem);margin-top:10px">¿Quién eres?</h1><p class="muted">Elige tu nombre de la lista del equipo. Quedará ligado a este Gmail.</p>
    <div class="claimgrid stagger">${S.players.filter(p=>p.active!==false).sort((a,b)=>a.order-b.order).map(p=>`<button data-act="claim" data-id="${esc(p.id)}" ${taken.has(p.id)?'disabled':''}>${avatar(p)}<span>${esc(p.name)}${taken.has(p.id)?'<br><span class="muted small" style="font-weight:400">ya elegido</span>':''}</span></button>`).join('')}</div>
    ${isAdmin?`<p style="margin-top:20px"><button class="textlink" data-act="skip">Soy administrador y no juego</button></p>`:''}
    <p class="source">¿Tu nombre aparece como elegido y no has sido tú? Avisa al capitán para que lo libere.</p></div>`;
}

/* ---------------- Administración ---------------- */
function vAdmin(){
  if(!isAdmin) return `<div class="wrap"><div class="pagehead"><h1>Administración</h1></div><div class="notice">Solo los administradores pueden gestionar la temporada.</div></div>`;
  const tabs=[['jornada','Centro de jornada'],['plantilla','Plantilla y fotos'],['calendario','Liga y calendario'],['preguntas','Encuesta'],['temporadas','Temporadas y ajustes']];
  const t=ui.adminTab;
  return `<div class="wrap"><div class="pagehead"><h1>Administración</h1><p class="lede">Todo se edita aquí y se actualiza solo en el resto de la app.${viewSeason!==currentSeason()?` <b>Estás editando la temporada ${esc(viewSeason)}.</b>`:''}</p></div>
    <div class="atabs">${tabs.map(([k,l])=>`<button class="chip" data-act="admin-tab" data-v="${k}" aria-pressed="${t===k}">${l}</button>`).join('')}</div>
    ${t==='jornada'?aJornada():t==='plantilla'?aPlantilla():t==='calendario'?aCalendario():t==='preguntas'?aPreguntas():aTemporadas()}</div>`;
}
function jSelect(act,cur,onlyPolo=true){ return `<select data-act="${act}" style="max-width:360px">${Array.from({length:NJ()},(_,i)=>i+1).filter(j=>!onlyPolo||poloFix(j)).map(j=>{ const f=poloFix(j); return `<option value="${j}" ${cur===j?'selected':''}>Jornada ${j}${f?', '+(f.home===POLO?'Polo contra '+team(f.away).short:team(f.home).short+' contra Polo')+', '+fdate(f):''}</option>`; }).join('')}</select>`; }
function adminJ(){ if(ui.adminJ && poloFix(ui.adminJ)) return ui.adminJ; const nx=nextPoloFix(); if(nx) return nx.j; const l=lastPoloPlayed(); if(l) return l.j; const f=S.fixtures.find(x=>x.home===POLO||x.away===POLO); return f? f.j : null; }
function aJornada(){
  const j=adminJ(); if(!j) return `<div class="empty">No hay eliminatorias del Polo en el calendario. Añádelas en «Liga y calendario».</div>`;
  const f=poloFix(j), p=persp(f), t=tie(j)||blankTie(), a=availFor(j), agg=aggregate(jid(j)), parts=participants(j), pub=S.published[jid(j)];
  const steps=[
    ['disp','Disponibilidad pedida', !!t.availReq, t.availReq? relTime(t.availReq.at) : 'Pendiente'],
    ['disp','Respuestas', a.total>0 && a.answered===a.total, `${a.answered} de ${a.total}`],
    ['conv','Convocatoria', !!t.lineupPub, t.lineupPub? 'Publicada' : (t.convocados?.length? 'Borrador' : 'Pendiente')],
    ['cartel','Cartel', !!t.poster?.at, t.poster?.at? 'Compartido '+relTime(t.poster.at) : 'Pendiente'],
    ['res','Resultados', isPlayed(f), isPlayed(f)? `Polo ${p.ps}-${p.rs}` : 'Pendiente'],
    ['enc','Encuesta', parts.length>0 && agg.n>=parts.length && isPlayed(f), isPlayed(f)? `${agg.n} de ${parts.length}` : 'Tras el partido'],
    ['enc','Premios', !!pub, pub? 'Publicados' : 'Pendiente']];
  const sub=ui.jTab;
  const subs=[['disp','Disponibilidad'],['conv','Convocatoria'],['cartel','Cartel'],['res','Resultados'],['enc','Encuesta y MVP']];
  return `<section class="sec" style="padding-top:8px">${jSelect('admin-j',j)}
    <p style="margin:12px 0 0;font-stretch:72%;font-weight:750;font-size:1.5rem">Polo contra ${esc(clubName(p.rival))}</p><p class="muted small" style="margin:2px 0 0">${esc(fdate(f,{weekday:'long',day:'numeric',month:'long'}))}, ${esc(f.time)} h, ${p.home?'en casa':'fuera'}. <button class="textlink" data-act="admin-tab" data-v="calendario">Cambiar fecha u hora</button></p>
    <ol class="pipe stagger">${steps.map(([k,l,ok,d],i)=>`<li><button data-act="jtab" data-v="${k}" class="${ok?'ok':''} ${sub===k?'cur':''}"><span class="n">${ok?'✓':i+1}</span><span><b>${l}</b><small>${esc(d)}</small></span></button></li>`).join('')}</ol>
    <div class="chips" style="margin-top:6px">${subs.map(([k,l])=>`<button class="chip" data-act="jtab" data-v="${k}" aria-pressed="${sub===k}">${l}</button>`).join('')}</div></section>
    ${sub==='disp'?aDisp(j):sub==='conv'?aConv(j):sub==='cartel'?aCartel(j):sub==='res'?aResultados(j):aMvp(j)}`;
}
/* --- WhatsApp --- */
const appLink = h => location.origin + location.pathname + '#' + h;
function msgVars(j){ const f=poloFix(j), p=persp(f); return {rival:clubName(p.rival), fecha:fdate(f,{weekday:'long',day:'numeric',month:'long'}), hora:f.time, limite:fmtDT(deadline(j)), enlace:appLink('disponibilidad-'+j), enlaceJornada:appLink('jornada-'+j), jornada:j, lugar:p.home?'en casa':'fuera, en las pistas del '+clubName(p.rival)}; }
const fillMsg = (tpl,v) => String(tpl||'').replace(/\{(\w+)\}/g,(m,k)=>v[k]!=null? v[k] : m);
function composeText(kind,j){ const v=msgVars(j), a=availFor(j);
  if(kind==='rem') v.pendientes=a.none.map(pname).join(', ')||'nadie';
  if(kind==='lineup'){ const roles=rolesOf(j); v.lista=lineupList(j).map(pid=>`• ${pname(pid)}: ${(roles[pid]||[]).join(' + ')}`).join('\n'); }
  return fillMsg(S.msgs[kind], v); }
function composer(kind,j,title){
  const c=ui.compose&&ui.compose.kind===kind&&ui.compose.j===j? ui.compose : null;
  if(!c) return '';
  return `<div class="panel composer"><b>${title}</b><p class="muted small" style="margin:4px 0 10px">Revísalo y edítalo antes de enviarlo. WhatsApp no deja elegir el grupo desde un enlace: al abrirse, elige el grupo del equipo.</p>
    <textarea id="compose-text" rows="10">${esc(c.text)}</textarea>
    <div class="row" style="margin-top:10px"><button class="btn brass" data-act="wa-send" data-kind="${kind}" data-j="${j}"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.3-.4.7-1.4.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6a2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.3-.2-.5-.3z"/></svg>Abrir WhatsApp</button>
      ${navigator.share?`<button class="btn ghost" data-act="wa-share" data-kind="${kind}" data-j="${j}">Compartir…</button>`:''}<button class="btn ghost" data-act="wa-copy" data-kind="${kind}" data-j="${j}">Copiar texto</button><button class="btn ghost sm" data-act="compose-close">Cancelar</button></div></div>`;
}
function respChart(j){
  const k=jid(j), ev=[]; Object.entries(avail).forEach(([pid,d])=>(d.h?.[k]||[]).forEach(e=>ev.push({pid,...e})));
  if(!ev.length) return '';
  ev.sort((a,b)=>a.at-b.at); const t0=Math.min(tie(j)?.availReq?.at||ev[0].at, ev[0].at), t1=Math.max(Date.now(), ev.at(-1).at+1), st={}; const pts=[];
  ev.forEach(e=>{ st[e.pid]=e.s; pts.push({t:e.at, n:Object.keys(st).length, y:Object.values(st).filter(x=>x==='yes').length}); });
  const W=600,H=170,pad={l:28,r:10,t:10,b:24}, tot=Math.max(1,availFor(j).total);
  const X=t=>pad.l+(t-t0)/(t1-t0||1)*(W-pad.l-pad.r), Y=v=>pad.t+(1-v/tot)*(H-pad.t-pad.b);
  const step=key=>{ let d=`M${X(t0)},${Y(0)}`, prev=0; pts.forEach(q=>{ d+=`L${X(q.t)},${Y(prev)}L${X(q.t)},${Y(q[key])}`; prev=q[key]; }); return d+`L${X(t1)},${Y(prev)}`; };
  let g=''; [0,Math.round(tot/2),tot].forEach(v=>g+=`<line x1="${pad.l}" x2="${W-pad.r}" y1="${Y(v)}" y2="${Y(v)}" stroke="var(--line)"/><text x="${pad.l-6}" y="${Y(v)+4}" text-anchor="end">${v}</text>`);
  g+=`<text x="${pad.l}" y="${H-6}">${new Date(t0).toLocaleDateString('es-ES',{day:'numeric',month:'short'})}</text><text x="${W-pad.r}" y="${H-6}" text-anchor="end">ahora</text>`;
  return `<div class="sec-h" style="margin-top:22px"><h3>Evolución de las respuestas</h3></div><svg class="chart" viewBox="0 0 ${W} ${H}">${g}<path class="ln" d="${step('n')}" fill="none" stroke="var(--muted)" stroke-width="2"/><path class="ln" d="${step('y')}" fill="none" stroke="var(--win)" stroke-width="2.5"/></svg><div class="legend"><span><i style="background:var(--muted)"></i>Han respondido</span><span><i style="background:var(--win)"></i>Disponibles</span></div>`;
}
function aDisp(j){
  const f=poloFix(j), t=tie(j)||blankTie(), a=availFor(j), dl=deadline(j);
  const dlv=new Date(dl.getTime()-dl.getTimezoneOffset()*6e4).toISOString().slice(0,16);
  const row=(pid,k)=>{ const v=avOf(pid,j), n=noteOf(pid,j), hist=(avail[pid]?.h?.[jid(j)]||[]).length, ph=phones[pid];
    return `<li><div class="row" style="gap:10px;flex-wrap:nowrap">${avatar(player(pid),'sm')}<div style="flex:1;min-width:0"><b>${esc(pname(pid))}</b>${n?.c?`<div class="small">«${esc(n.c)}»</div>`:''}<div class="muted small">${v?.at? relTime(v.at) : 'Sin respuesta'}${hist>1? ', cambió '+(hist-1)+(hist>2?' veces':' vez'):''}</div></div>
      ${k==='none'? (ph? `<button class="btn sm ghost" data-act="wa-one" data-pid="${esc(pid)}" data-j="${j}">Recordar</button>` : '<span class="muted small">sin teléfono</span>') : ''}
      <select data-act="av-admin" data-pid="${esc(pid)}" data-j="${j}" aria-label="Anotar a mano" style="width:auto;min-height:32px;padding:4px 8px;font-size:.8rem"><option value="">Anotar</option><option value="yes">Disponible</option><option value="maybe">Pendiente</option><option value="no">No disponible</option></select></div></li>`; };
  return `<section class="sec"><div class="split"><div><div class="row" style="gap:20px;align-items:center">${ring(a.total? a.pct : null,'disponible')}<div style="flex:1">${availSummary(j)}</div></div>
      <p class="muted small">${a.yes.length} disponibles de ${a.total} jugadores en plantilla. ${t.availReq? 'Pedida '+relTime(t.availReq.at)+(t.availReq.n>1?' ('+t.availReq.n+' envíos)':'')+'.' : 'Aún no se ha pedido por WhatsApp.'}${(t.remLog||[]).length? ' Recordatorios enviados: '+t.remLog.length+'.' : ''}</p>
      <div class="row" style="margin-top:12px"><button class="btn brass" data-act="compose" data-kind="req" data-j="${j}">Solicitar disponibilidad</button><button class="btn ghost" data-act="compose" data-kind="rem" data-j="${j}" ${a.none.length?'':'disabled'}>Recordar a quien no ha respondido (${a.none.length})</button><a class="btn ghost sm" href="#disponibilidad-${j}">Ver la encuesta</a></div>
      ${composer('req',j,'Mensaje para el grupo')}${composer('rem',j,'Recordatorio para el grupo')}
      <div class="panel" style="margin-top:16px"><label class="f" style="margin-top:0" for="dl">Fecha límite para responder</label><div class="row"><input type="datetime-local" id="dl" value="${dlv}" style="max-width:260px"><button class="btn sm" data-act="dl-save" data-j="${j}">Guardar plazo</button>${t.deadline?`<button class="btn sm ghost" data-act="dl-reset" data-j="${j}">Usar el plazo por defecto</button>`:''}</div><p class="muted small" style="margin:6px 0 0">Por defecto, ${S.rules.deadlineDays} días antes a las ${esc(S.rules.deadlineTime)}. Pasado el plazo, solo los administradores pueden cambiar respuestas.</p></div>
      ${respChart(j)}</div>
    <div>${['yes','maybe','no','none'].map(k=>`<div class="avgroup ${k}"><h3>${AV_LABEL[k]} <span class="muted">${a[k].length}</span></h3>${a[k].length?`<ul class="avlist">${a[k].map(pid=>row(pid,k)).join('')}</ul>`:'<p class="muted small">Nadie.</p>'}</div>`).join('')}
      <p class="source">Los recordatorios individuales usan el teléfono guardado en «Plantilla y fotos». Los comentarios solo los ven los administradores y su autor.</p></div></div></section>`;
}
function aConv(j){
  const t=tie(j)||blankTie(), a=availFor(j), conv=new Set(t.convocados?.length? t.convocados : a.yes);
  const order=[...a.yes,...a.maybe,...a.none,...a.no];
  const badge=pid=>{ const v=avOf(pid,j)?.s||'none'; return `<em class="av-${v}">${{yes:'disponible',maybe:'pendiente',no:'no disponible',none:'sin respuesta'}[v]}</em>`; };
  const popts=sel=>`<option value="">Elegir</option>`+order.map(id=>`<option value="${esc(id)}" ${sel===id?'selected':''}>${esc(pname(id))}${conv.has(id)?'':' (no convocado)'}</option>`).join('');
  const assigned=new Set(t.rubbers.flatMap(r=>r.polo||[])); const subs=[...conv].filter(x=>!assigned.has(x));
  const dupe=t.rubbers.filter(r=>r.type==='S').map(r=>r.polo[0]).filter(Boolean); const hasDupe=new Set(dupe).size!==dupe.length;
  const warn=[...assigned].filter(x=>(avOf(x,j)?.s||'none')!=='yes');
  return `<section class="sec"><div class="sec-h"><h2>Convocados</h2><span class="muted small">${conv.size} seleccionados</span></div>
    <div class="cvgrid">${order.map(id=>{ const n=noteOf(id,j); return `<label title="${esc(n?.c||'')}"><input type="checkbox" name="conv" value="${esc(id)}" ${conv.has(id)?'checked':''}> ${esc(pname(id))}${badge(id)}</label>`; }).join('')}</div></section>
  <section class="sec"><div class="sec-h"><h2>Orden de juego</h2></div><p class="muted small">4 individuales y la pareja de dobles por si queda 2-2. Los convocados sin partido asignado quedan como suplentes.</p>
    ${t.rubbers.map((r,i)=>`<div class="redit" data-r="${i}" style="grid-template-columns:150px 1fr 1fr"><span class="rn">${RUBBERS[i].label}${r.type==='D'?'<small>Solo si queda 2-2</small>':''}</span><select name="p1">${popts(r.polo[0])}</select>${r.type==='D'?`<select name="p2">${popts(r.polo[1])}</select>`:'<span></span>'}</div>`).join('')}
    <p class="small" style="margin-top:10px">Suplentes: ${subs.length? subs.map(pname).join(', ') : 'ninguno'}.</p>
    ${hasDupe?'<div class="notice" style="margin-top:8px">Hay un jugador repetido en los individuales.</div>':''}
    ${warn.length?`<div class="notice" style="margin-top:8px">Sin «disponible» confirmado: ${warn.map(pname).join(', ')}.</div>`:''}
    <div class="row" style="margin-top:16px"><button class="btn ghost" data-act="conv-save" data-j="${j}">Guardar borrador</button>${t.lineupPub?`<button class="btn ghost" data-act="conv-pub" data-j="${j}" data-v="0">Retirar publicación</button><button class="btn brass" data-act="conv-save" data-j="${j}" data-pub="1">Guardar y mantener publicada</button>`:`<button class="btn brass" data-act="conv-save" data-j="${j}" data-pub="1">Publicar convocatoria</button>`}</div>
    ${t.lineupPub?`<div class="row" style="margin-top:12px"><button class="btn ghost" data-act="compose" data-kind="lineup" data-j="${j}">Anunciar por WhatsApp</button><button class="btn ghost" data-act="jtab" data-v="cartel">Preparar el cartel</button></div>`:''}
    ${composer('lineup',j,'Anuncio de la convocatoria')}</section>`;
}
function posterOpts(j){ const t=tie(j)||{}; const p=t.poster||{}; const f=poloFix(j);
  return {fmt:p.fmt||'story', bg:p.bg||(photos._team?'team':'court'), title:p.title||'Convocatoria', sub:p.sub||`Jornada ${j}, ${S.comp.name.replace(/^\d+a /,'')}`, tagline:p.tagline||'¡Vamos Polo!', showSubs:p.showSubs!==false, order:p.order||[], hidden:p.hidden||[]}; }
function aCartel(j){
  const t=tie(j); if(!t || !lineupList(j).length) return `<section class="sec"><div class="empty">Primero elige los convocados y el orden de juego en «Convocatoria».</div></section>`;
  const o=posterOpts(j), all=(()=>{ const save=t.poster; t.poster={...(save||{}),hidden:[]}; const l=lineupList(j); t.poster=save; return l; })(), roles=rolesOf(j);
  return `<section class="sec"><div class="split"><div>
    <div class="chips">${[['story','Vertical 9:16'],['square','Cuadrado'],['wide','Horizontal']].map(([k,l])=>`<button class="chip" data-act="poster-set" data-k="fmt" data-v="${k}" aria-pressed="${o.fmt===k}">${l}</button>`).join('')}</div>
    <div class="chips" style="margin-top:8px">${[['court','Pista'],['team','Foto del equipo']].map(([k,l])=>`<button class="chip" data-act="poster-set" data-k="bg" data-v="${k}" aria-pressed="${o.bg===k}" ${k==='team'&&!photos._team?'disabled title="Sube la foto del equipo en Temporadas y ajustes"':''}>${l}</button>`).join('')}</div>
    <label class="f">Título</label><input type="text" id="pt-title" value="${esc(o.title)}">
    <label class="f">Subtítulo</label><input type="text" id="pt-sub" value="${esc(o.sub)}">
    <label class="f">Lema</label><input type="text" id="pt-tag" value="${esc(o.tagline)}">
    <label class="f">Jugadores en el cartel (orden y visibilidad)</label>
    <ul class="plist">${all.map((pid,i)=>`<li><label><input type="checkbox" data-act="poster-hide" data-pid="${esc(pid)}" ${o.hidden.includes(pid)?'':'checked'}> ${esc(pname(pid))} <span class="muted small">${esc((roles[pid]||[]).join(' + '))}</span></label><span><button class="iconbtn" data-act="poster-move" data-pid="${esc(pid)}" data-d="-1" ${i===0?'disabled':''} aria-label="Subir">↑</button><button class="iconbtn" data-act="poster-move" data-pid="${esc(pid)}" data-d="1" ${i===all.length-1?'disabled':''} aria-label="Bajar">↓</button></span></li>`).join('')}</ul>
    <div class="row" style="margin-top:12px"><button class="btn ghost sm" data-act="poster-texts" data-j="${j}">Aplicar textos</button>${t.poster&&Object.keys(t.poster).length?`<button class="btn ghost sm" data-act="poster-reset" data-j="${j}">Volver al diseño automático</button>`:''}</div>
    </div><div><canvas id="poster-canvas" data-j="${j}" class="pcanvas"></canvas>
    <div class="row" style="margin-top:12px"><button class="btn brass" data-act="poster-dl" data-j="${j}">Descargar imagen</button>${navigator.share?`<button class="btn" data-act="poster-share" data-j="${j}">Compartir</button>`:''}</div>
    <p class="muted small">Se compone solo según el número de jugadores. Las fotos salen de sus perfiles.</p></div></div></section>`;
}
function aResultados(j){
  const f=poloFix(j), t=tie(j)||blankTie(), p=persp(f), conv=new Set(t.convocados||[]);
  const order=[...S.players.filter(x=>conv.has(x.id)), ...S.players.filter(x=>!conv.has(x.id)&&x.active!==false)].map(x=>x.id);
  const popts=sel=>`<option value="">Elegir</option>`+order.map(id=>`<option value="${esc(id)}" ${sel===id?'selected':''}>${esc(pname(id))}</option>`).join('');
  return `<section class="sec"><p class="muted small">Marcador desde el punto de vista del Polo, sets separados por espacios: <b>6-4 3-6 6-3</b>. El resultado se calcula solo; fuerza uno a mano para W.O. o abandono. Los jugadores vienen de la convocatoria; cámbialos si hubo cambios de última hora.</p>
    ${t.rubbers.map((r,i)=>`<div class="redit" data-r="${i}"><span class="rn">${RUBBERS[i].label}${r.type==='D'?'<small>Solo si queda 2-2</small>':''}</span>
      <select name="p1" aria-label="Jugador">${popts(r.polo[0])}</select>${r.type==='D'?`<select name="p2" aria-label="Pareja">${popts(r.polo[1])}</select>`:'<span></span>'}
      <input type="text" name="score" placeholder="6-4 6-3" value="${esc(r.score)}">
      <select name="res"><option value="">Auto</option><option value="W" ${r.res==='W'?'selected':''}>Gana Polo</option><option value="L" ${r.res==='L'?'selected':''}>Pierde Polo</option></select>
      <input type="text" name="note" placeholder="Nota: W.O., abandono…" value="${esc(r.note)}" style="grid-column:2 / -1"></div>`).join('')}
    <label class="f" for="moment">Momento de la jornada (público)</label><input type="text" id="moment" value="${esc(t.moment||'')}">
    <div class="panel" style="margin-top:16px"><b>Marcador por equipos</b><p class="muted small" style="margin:4px 0 10px">Se calcula solo con los 4 individuales (y el dobles si hubo 2-2). Si solo tienes el oficial, escríbelo aquí.</p>
      <div class="row"><label>Polo <input type="number" id="ps" min="0" max="5" value="${p.ps??''}" style="width:80px"></label><label>${esc(clubName(p.rival))} <input type="number" id="rs" min="0" max="5" value="${p.rs??''}" style="width:80px"></label></div></div>
    <div class="row" style="margin-top:16px"><button class="btn brass" data-act="save-tie" data-j="${j}">Guardar resultados</button><a class="textlink" href="#jornada-${j}">Ver la jornada</a></div></section>`;
}
function aggregate(k){
  const out={n:0,votes:{},ratings:{},texts:[],who:[]}, sums={}, cnt={};
  Object.entries(ballots).forEach(([pid,b])=>{ const r=b.j?.[k]; if(!r) return; out.n++; out.who.push(pid);
    S.survey.questions.forEach(q=>{ const v=r.a?.[q.id]; if(v==null||v==='') return;
      if(q.scope==='peer'){ (out.votes[q.id] ||= {}); out.votes[q.id][v]=(out.votes[q.id][v]||0)+1; }
      else if(q.scope==='team'&&q.type==='scale'){ sums[q.id]=(sums[q.id]||0)+(+v); cnt[q.id]=(cnt[q.id]||0)+1; }
      else if(q.type==='text') out.texts.push({pid,q:q.text,v}); }); });
  Object.keys(sums).forEach(q=>out.ratings[q]=sums[q]/cnt[q]); return out;
}
function mvpSuggestion(j,agg){
  const t=tie(j), c=new Set(participants(j)); Object.keys(agg.votes.q_destacado||{}).forEach(x=>c.add(x));
  const rows=[...c].filter(player).map(pid=>{ let sp=0; (t?.rubbers||[]).forEach(r=>{ if(!(r.polo||[]).includes(pid)) return; const x=rubberCalc(r); if(!x.res) return; sp+=(x.res==='W'?2:0)+.5*(x.sw-x.sl)+.05*(x.gw-x.gl)+(x.comeback?.5:0)+(r.type==='D'&&x.res==='W'?.5:0); });
    return {pid,sp,vv:(agg.votes.q_destacado?.[pid]||0)+(agg.votes.q_determinante?.[pid]||0)}; });
  const ms=Math.max(.0001,...rows.map(r=>r.sp)), mv=Math.max(.0001,...rows.map(r=>r.vv));
  rows.forEach(r=>r.score=.5*Math.max(0,r.sp)/ms+.5*r.vv/mv); return rows.sort((a,b)=>b.score-a.score);
}
function aMvp(j){
  const k=jid(j);
  const agg=aggregate(k), sug=mvpSuggestion(j,agg), pub=S.published[k]||{}, parts=participants(j), closed=!!S.survey.closed?.[k];
  const missing=parts.filter(pid=>!agg.who.includes(pid));
  const opts=sel=>`<option value="">Sin asignar</option>`+S.players.map(p=>`<option value="${esc(p.id)}" ${sel===p.id?'selected':''}>${esc(p.name)}</option>`).join('');
  const rev=Object.entries(agg.votes.q_sorpresa||{}).sort((a,b)=>b[1]-a[1])[0]?.[0];
  let h=`<section class="sec"><div class="panel"><b>Encuesta de la jornada ${j}: ${closed?'cerrada':isPlayed(poloFix(j))?'abierta para los que jugaron':'se abrirá al cargar el resultado'}</b>
    <p class="muted small" style="margin:6px 0 10px">${agg.n} de ${parts.length} han respondido.${missing.length?' Faltan: '+missing.map(pname).join(', ')+'.':''}</p>
    <button class="btn sm ghost" data-act="survey-toggle" data-j="${j}">${closed?'Reabrir encuesta':'Cerrar encuesta'}</button></div></section>
  <section class="sec"><div class="sec-h"><h2>Respuestas</h2></div><p>${Object.entries(agg.ratings).map(([q,v])=>`${esc(S.survey.questions.find(x=>x.id===q)?.text||q)} <b>${dec(v)}</b>`).join('. ')||'<span class="muted">Sin respuestas todavía.</span>'}</p>
    ${Object.keys(agg.votes).length?`<div class="rgrid" style="margin-top:12px">${Object.entries(agg.votes).map(([q,vs])=>`<div class="rank"><h3>${esc(S.survey.questions.find(x=>x.id===q)?.text||q)}</h3><ol>${Object.entries(vs).sort((a,b)=>b[1]-a[1]).map(([pid,n])=>`<li>${avatar(player(pid),'sm')}<span>${esc(pname(pid))}</span><b>${n}</b></li>`).join('')}</ol></div>`).join('')}</div>`:''}</section>
  <section class="sec"><div class="sec-h"><h2>MVP sugerido</h2></div><p class="muted small">50 % rendimiento en pista y 50 % votos de «más destacado» y «más determinante». Tú decides.</p>
    ${sug.length?`<table><thead><tr><th>Jugador</th><th>Pista</th><th>Votos</th><th>Índice</th></tr></thead><tbody>${sug.map(r=>`<tr><td>${esc(pname(r.pid))}</td><td>${dec(r.sp)}</td><td>${r.vv}</td><td><b>${Math.round(r.score*100)}</b></td></tr>`).join('')}</tbody></table>`:'<div class="empty">Sin participantes ni votos.</div>'}</section>
  <section class="sec"><div class="sec-h"><h2>Publicar premios</h2></div>
    <label class="f">MVP oficial</label><select id="pub-mvp">${opts(pub.mvp||sug[0]?.pid)}</select>
    <label class="f">Revelación</label><select id="pub-rev">${opts(pub.rev||rev)}</select>
    <label class="f">Mejor partido</label><select id="pub-best"><option value="">Sin asignar</option>${(tie(j)?.rubbers||[]).filter(r=>(r.polo||[]).length).map(r=>`<option value="${r.n}" ${+pub.best===r.n?'selected':''}>${RUBBERS[r.n-1].label}: ${esc(r.polo.map(pname).join(' y '))}</option>`).join('')}</select>
    <p class="muted small" style="margin-top:10px">Se publican los votos agregados y las notas medias. Nunca quién votó a quién, ni las autovaloraciones, ni los comentarios.</p>
    <div class="row" style="margin-top:12px"><button class="btn brass" data-act="publish" data-j="${j}">${S.published[k]?'Actualizar publicación':'Publicar jornada '+j}</button>${S.published[k]?`<button class="btn ghost sm" data-act="unpublish" data-j="${j}">Retirar</button>`:''}</div></section>
  ${agg.texts.length?`<section class="sec"><div class="sec-h"><h2>Comentarios privados</h2></div><ul class="insights">${agg.texts.map(x=>`<li>${esc(x.v)}<small>${esc(pname(x.pid))}, ${esc(x.q)}</small></li>`).join('')}</ul></section>`:''}`;
  return h;
}
function aPreguntas(){
  const sc=v=>Object.entries(SCOPE_LABEL).map(([k,l])=>`<option value="${k}" ${v===k?'selected':''}>${l}</option>`).join('');
  const ty=v=>[['scale','Nota 1-10'],['player','Elegir jugador'],['text','Texto libre']].map(([k,l])=>`<option value="${k}" ${v===k?'selected':''}>${l}</option>`).join('');
  return `<section class="sec"><div class="sec-h"><h2>Preguntas de la encuesta</h2></div><p class="muted small">«Sobre tus compañeros» se publica como votos agregados y solo deja elegir entre los que jugaron. «Sobre el equipo» como nota media. «Sobre ti» y «Comentarios» son privados.</p>
    <div id="qlist">${S.survey.questions.map((q,i)=>`<div class="qedit" data-i="${i}"><input type="text" name="text" value="${esc(q.text)}" aria-label="Pregunta"><select name="scope">${sc(q.scope)}</select><select name="type">${ty(q.type)}</select><button class="iconbtn" data-act="q-del" data-i="${i}" aria-label="Eliminar">✕</button></div>`).join('')}</div>
    <div class="row" style="margin-top:14px"><button class="btn ghost sm" data-act="q-add">Añadir pregunta</button><button class="btn brass" data-act="q-save">Guardar preguntas</button><button class="btn ghost sm" data-act="q-reset">Restaurar</button></div></section>`;
}
function aPlantilla(){
  return `<section class="sec"><div class="sec-h"><h2>Plantilla</h2><span class="muted small">${S.players.length} jugadores</span></div><p class="muted small">Cada foto se sube una vez y se usa en toda la app: perfiles, equipo, rankings, convocatorias y carteles. El teléfono solo lo ven los administradores y sirve para los recordatorios individuales por WhatsApp.</p>
    <div id="plist">${S.players.slice().sort((a,b)=>a.order-b.order).map(p=>`<div class="pedit" data-id="${esc(p.id)}">
      <button class="phbtn" data-act="crop" data-target="${esc(p.id)}" title="Subir o recortar la foto">${avatar(p)}<span>${photos[p.id]?'Cambiar':'Subir'} foto</span></button>
      <div class="pf"><label>Nombre<input type="text" name="name" value="${esc(p.name)}"></label><label>Nombre completo<input type="text" name="full" value="${esc(p.full)}"></label></div>
      <div class="pf sm"><label>Orden<input type="number" name="order" value="${p.order}"></label><label>Categoría<input type="text" name="cat" value="${esc(p.cat)}"></label><label>Puntos FCT<input type="number" name="pts" value="${p.pts??0}"></label><label>Teléfono<input type="tel" name="phone" value="${esc(phones[p.id]||'')}" placeholder="+34 600 000 000"></label></div>
      <div class="row small" style="gap:12px"><label><input type="radio" name="captain" value="${esc(p.id)}" ${p.captain?'checked':''}> Capitán</label><label><input type="checkbox" name="active" ${p.active!==false?'checked':''}> En plantilla</label>${photos[p.id]?`<button class="textlink" data-act="photo-del" data-target="${esc(p.id)}">Quitar foto</button>`:''}<span class="muted">${claims[p.id]? 'Entra como '+esc(claims[p.id].email) : 'Aún no ha entrado'}</span>${claims[p.id]?`<button class="textlink" data-act="unclaim" data-pid="${esc(p.id)}">Liberar acceso</button>`:''}</div></div>`).join('')}</div>
    <div class="row" style="margin-top:14px"><button class="btn brass" data-act="players-save">Guardar plantilla</button></div>
    <div class="panel" style="margin-top:24px"><b>Añadir jugador</b><div class="row" style="margin-top:10px"><input type="text" id="np-name" placeholder="Nombre corto" style="max-width:200px"><input type="text" id="np-full" placeholder="Nombre completo" style="max-width:240px"><input type="text" id="np-cat" placeholder="Categoría" style="max-width:140px"><button class="btn sm" data-act="player-add">Añadir</button></div></div></section>`;
}
function aCalendario(){
  const j=ui.calJ || currentJ() || 1, fs=S.fixtures.filter(f=>f.j===j), topts=sel=>S.teams.map(t=>`<option value="${t.id}" ${sel===t.id?'selected':''}>${esc(t.short)}</option>`).join('');
  const js=[...new Set(S.fixtures.map(f=>f.j))].sort((a,b)=>a-b);
  return `<section class="sec"><div class="sec-h"><h2>Competición</h2></div>
    <label class="f">Nombre</label><input type="text" id="c-name" value="${esc(S.comp.name)}"><label class="f">Grupo</label><input type="text" id="c-group" value="${esc(S.comp.group)}"><label class="f">Memorial o subtítulo</label><input type="text" id="c-mem" value="${esc(S.comp.memorial||'')}">
    <div class="row" style="margin-top:12px"><button class="btn brass sm" data-act="comp-save">Guardar competición</button></div></section>
  <section class="sec"><div class="sec-h"><h2>Clubes</h2></div><div id="tlist">${S.teams.map(t=>`<div class="qedit" data-id="${t.id}" style="grid-template-columns:1fr 1fr 90px 40px"><input type="text" name="name" value="${esc(t.name)}" aria-label="Nombre del club"><input type="text" name="short" value="${esc(t.short)}" aria-label="Nombre corto"><input type="text" name="abbr" value="${esc(t.abbr)}" aria-label="Siglas">${t.id===POLO?'<span></span>':`<button class="iconbtn" data-act="team-del" data-id="${t.id}" aria-label="Quitar club">✕</button>`}</div>`).join('')}</div>
    <div class="row" style="margin-top:12px"><button class="btn brass sm" data-act="teams-save">Guardar clubes</button><input type="text" id="nt-name" placeholder="Nuevo club" style="max-width:220px"><button class="btn sm ghost" data-act="team-add">Añadir club</button></div></section>
  <section class="sec"><div class="sec-h"><h2>Calendario y resultados</h2></div>
    <div class="row"><select data-act="cal-j" style="max-width:260px">${js.map(x=>`<option value="${x}" ${x===j?'selected':''}>Jornada ${x}</option>`).join('')}</select><button class="btn sm ghost" data-act="jornada-add">Añadir jornada</button></div>
    <div id="flist" style="margin-top:12px">${fs.map(f=>`<div class="qedit" data-k="${S.fixtures.indexOf(f)}" style="grid-template-columns:140px 90px 1fr 1fr 60px 60px 40px"><input type="date" name="date" value="${f.date}"><input type="time" name="time" value="${f.time}"><select name="home">${topts(f.home)}</select><select name="away">${topts(f.away)}</select><input type="number" name="hs" min="0" max="5" value="${f.hs??''}" aria-label="Local"><input type="number" name="as" min="0" max="5" value="${f.as??''}" aria-label="Visitante"><button class="iconbtn" data-act="fix-del" data-k="${S.fixtures.indexOf(f)}" aria-label="Quitar enfrentamiento">✕</button></div>`).join('')||'<div class="empty">Sin enfrentamientos en esta jornada.</div>'}</div>
    <div class="row" style="margin-top:10px"><button class="btn sm ghost" data-act="fix-add" data-j="${j}">Añadir enfrentamiento</button><label class="small">Cambiar la fecha de toda la jornada <input type="date" id="jdate" style="max-width:170px"></label><button class="btn sm ghost" data-act="jdate" data-j="${j}">Aplicar</button></div>
    <p class="muted small">Cambiar fecha u hora actualiza solo el calendario, la portada, la página de la jornada, el plazo de disponibilidad y los mensajes.</p>
    <div class="row" style="margin-top:12px"><button class="btn brass" data-act="fixtures-save" data-j="${j}">Guardar jornada ${j}</button></div></section>
  <section class="sec"><div class="sec-h"><h2>Clasificación oficial</h2></div><p class="muted small">Copia el orden que publica la FCT. Mientras corresponda a la última jornada disputada, la app lo respeta tal cual.</p>
    <label class="f">Tras la jornada</label><input type="number" id="off-j" min="0" max="${NJ()}" value="${S.official?.asOf??''}" style="max-width:100px">
    <div id="offlist" style="margin-top:8px">${S.teams.map((_,i)=>`<div class="row" style="padding:4px 0"><span style="width:24px">${i+1}</span><select style="max-width:280px">${topts(S.official?.order?.[i])}</select></div>`).join('')}</div>
    <div class="row" style="margin-top:12px"><button class="btn brass sm" data-act="official-save">Guardar orden oficial</button></div></section>`;
}
const currentSeason = () => meta?.current || SEASON_ID;
function aTemporadas(){
  const list=meta?.seasons?.length? meta.seasons : [SEASON_ID];
  const vars='{rival} {fecha} {hora} {lugar} {limite} {enlace} {enlaceJornada} {jornada} {pendientes} {nombre} {lista}';
  return `<section class="sec"><div class="sec-h"><h2>Temporadas</h2></div>
    <table><tbody>${list.map(id=>`<tr><td><b>${esc(id)}</b>${id===currentSeason()?' <span class="tag">actual</span>':''}${id===viewSeason?' <span class="tag">viendo</span>':''}</td><td>${id!==viewSeason?`<button class="btn sm ghost" data-act="season-view" data-id="${esc(id)}">Ver</button>`:''} ${id!==currentSeason()?`<button class="btn sm ghost" data-act="season-current" data-id="${esc(id)}">Hacer actual</button>`:''}</td></tr>`).join('')}</tbody></table>
    <div class="panel" style="margin-top:16px"><b>Nueva temporada</b><p class="muted small" style="margin:4px 0 10px">Las temporadas anteriores se conservan enteras: resultados, disponibilidad, encuestas y MVP. La nueva copia plantilla y clubes; el calendario empieza vacío.</p>
      <div class="row"><input type="text" id="ns-id" placeholder="2027-28" style="max-width:140px"><label class="small"><input type="checkbox" id="ns-copy" checked> Copiar plantilla y clubes</label><button class="btn sm" data-act="season-new">Crear temporada</button></div></div></section>
  <section class="sec"><div class="sec-h"><h2>Foto del equipo</h2></div>${photos._team?`<img src="${esc(photos._team.d)}" alt="" style="border-radius:12px;max-height:240px;object-fit:cover;width:100%">`:'<div class="empty">Aún no hay foto. Saldrá a pantalla completa en la portada y como fondo opcional de los carteles.</div>'}
    <div class="row" style="margin-top:12px"><button class="btn brass" data-act="crop" data-target="_team">${photos._team?'Cambiar':'Subir'} foto del equipo</button>${photos._team?'<button class="btn ghost sm" data-act="photo-del" data-target="_team">Quitar</button>':''}</div></section>
  <section class="sec"><div class="sec-h"><h2>Mensajes de WhatsApp</h2></div><p class="muted small">Variables: ${esc(vars)}</p>
    ${[['req','Solicitud de disponibilidad'],['rem','Recordatorio al grupo'],['remOne','Recordatorio individual'],['lineup','Anuncio de convocatoria']].map(([k,l])=>`<label class="f">${l}</label><textarea id="msg-${k}" rows="6">${esc(S.msgs[k])}</textarea>`).join('')}
    <div class="row" style="margin-top:12px"><button class="btn brass sm" data-act="msgs-save">Guardar mensajes</button><button class="btn ghost sm" data-act="msgs-reset">Restaurar</button></div></section>
  <section class="sec"><div class="sec-h"><h2>Reglas</h2></div><div class="row"><label>Victoria <input type="number" id="r-win" value="${S.rules.win}" style="width:80px"></label><label>Derrota <input type="number" id="r-loss" value="${S.rules.loss}" style="width:80px"></label></div>
    <div class="row" style="margin-top:10px"><label>Avisar en la app <input type="number" id="r-av" value="${S.rules.availDays}" min="1" max="21" style="width:70px"> días antes</label><label>Plazo por defecto <input type="number" id="r-dd" value="${S.rules.deadlineDays}" min="0" max="14" style="width:70px"> días antes, a las <input type="time" id="r-dt" value="${esc(S.rules.deadlineTime)}" style="width:120px"></label></div>
    <div class="row" style="margin-top:12px"><button class="btn sm" data-act="rules-save">Guardar reglas</button></div></section>
  <section class="sec"><div class="sec-h"><h2>Copia de seguridad</h2></div><textarea readonly style="min-height:110px;font-size:.75rem" onclick="this.select()">${esc(JSON.stringify(S))}</textarea>
  ${B.mode==='demo'?'<div class="row" style="margin-top:12px"><button class="btn ghost sm" data-act="demo-reset">Borrar los datos de la vista previa</button></div>':''}</section>`;
}
const vNotFound = () => `<div class="wrap"><div class="pagehead"><h1>No encontrado</h1><p class="lede"><a class="textlink" href="#inicio">Volver al inicio</a></p></div></div>`;

/* ===================== EFECTOS ===================== */
function afterRender(root){
  root.querySelectorAll('.stagger').forEach(l=>[...l.children].forEach((c,i)=>c.style.setProperty('--i',Math.min(i,14))));
  requestAnimationFrame(()=>requestAnimationFrame(()=>{
    root.querySelectorAll('[data-w]').forEach(el=>el.style.width=el.dataset.w+'%');
    root.querySelectorAll('.ring .v').forEach(el=>el.style.strokeDashoffset=el.dataset.off);
  }));
  const pc=root.querySelector('#poster-canvas'); if(pc) drawPoster(pc,+pc.dataset.j);
  const els=root.querySelectorAll('[data-count]'); if(RM.matches) return;
  els.forEach(el=>{ const to=+el.dataset.count, suf=el.dataset.suf||''; if(!isFinite(to)||to===0) return; const t0=performance.now(), d=900;
    const step=t=>{ const k=Math.min(1,(t-t0)/d), e=1-Math.pow(1-k,3); el.textContent=Math.round(to*e)+suf; if(k<1) requestAnimationFrame(step); }; requestAnimationFrame(step); });
}
function confetti(x,y,n=90){
  if(RM.matches) return; let c=$('#fx'); if(!c){ c=document.createElement('canvas'); c.id='fx'; document.body.appendChild(c); }
  const dpr=devicePixelRatio||1; c.width=innerWidth*dpr; c.height=innerHeight*dpr; const g=c.getContext('2d'); g.scale(dpr,dpr);
  const cols=['#E2C47C','#F1F4EF','#2A7A5F','#C9A85A','#D7E86A']; const P=Array.from({length:n},()=>({x,y,vx:(Math.random()-.5)*12,vy:-Math.random()*13-4,r:Math.random()*6+3,c:cols[Math.random()*cols.length|0],a:Math.random()*6,va:(Math.random()-.5)*.4,life:0}));
  const tick=()=>{ g.clearRect(0,0,innerWidth,innerHeight); let alive=0; P.forEach(p=>{ p.life++; p.vy+=.38; p.vx*=.985; p.x+=p.vx; p.y+=p.vy; p.a+=p.va; if(p.y<innerHeight+20&&p.life<160){ alive++; g.save(); g.translate(p.x,p.y); g.rotate(p.a); g.fillStyle=p.c; g.globalAlpha=Math.max(0,1-p.life/160); g.fillRect(-p.r/2,-p.r/4,p.r,p.r/2); g.restore(); } }); if(alive) requestAnimationFrame(tick); else g.clearRect(0,0,innerWidth,innerHeight); };
  tick();
}
/* Hoja rápida de jugador */
function openSheet(pid){
  const p=player(pid); if(!p) return; const st=playerStats(pid);
  let bg=$('.sheet-bg'), sh=$('.sheet'); if(!bg){ bg=document.createElement('div'); bg.className='sheet-bg'; sh=document.createElement('div'); sh.className='sheet'; sh.setAttribute('role','dialog'); sh.setAttribute('aria-modal','true'); document.body.append(bg,sh); bg.addEventListener('click',closeSheet); }
  const vs=Object.entries(st.vs);
  sh.innerHTML=`<div class="handle"></div><div class="top">${avatar(p,'lg')}<div><h2>${esc(p.name)}</h2><p class="muted small" style="margin:4px 0 0">Nº ${p.order}, ${esc(p.cat)}${p.captain?', capitán':''}</p></div></div>
    <div class="row" style="gap:20px;margin-top:18px;align-items:center">${ring(st.pj?st.wr:null,'victorias')}<div class="figs stagger" style="flex:1;grid-template-columns:repeat(2,1fr)"><div class="fig"><b>${st.w}-${st.l}</b><span>balance</span></div><div class="fig"><b>${count(mvpCount(pid))}</b><span>MVP</span></div><div class="fig" style="border-left:0;padding-left:0;border-top:1px solid var(--line)"><b>${st.sw}-${st.sl}</b><span>sets</span></div><div class="fig" style="border-top:1px solid var(--line)"><b>${st.streak.n?(st.streak.t==='W'?'+':'−')+st.streak.n:'–'}</b><span>racha</span></div></div></div>
    <div style="margin-top:14px">${formStrip(st.seq,8)} <span class="muted small">últimos partidos</span></div>
    <div style="margin-top:10px">${meter('Juegos ganados','% del total',st.gw+st.gl?st.gw/(st.gw+st.gl):null,st.gw+st.gl?pct(st.gw,st.gw+st.gl)+'%':'–')}${meter('Votos','de los compañeros',totalVotes(pid)/Math.max(1,...S.players.map(x=>totalVotes(x.id))),totalVotes(pid),'sv')}</div>
    ${(()=>{ const av=availStats(pid); return av.total? meter('Disponibilidad',av.yes+' de '+av.total+' jornadas',av.pct,dec(av.pct*100)+'%') : ''; })()}
    ${vs.length?`<p class="small muted" style="margin:10px 0 0">${vs.map(([c,v])=>`${esc(team(c).short)} ${v.w}-${v.l}`).join(', ')}</p>`:''}
    <div class="row" style="margin-top:18px"><a class="btn" href="#jugador-${esc(pid)}" data-act="close-sheet">Ver ficha completa</a><button class="btn ghost" data-act="close-sheet">Cerrar</button></div>`;
  requestAnimationFrame(()=>{ bg.classList.add('on'); sh.classList.add('on'); afterRender(sh); });
  let y0=null; sh.ontouchstart=e=>{ if(sh.scrollTop<=0) y0=e.touches[0].clientY; }; sh.ontouchend=e=>{ if(y0!=null && e.changedTouches[0].clientY-y0>90) closeSheet(); y0=null; };
}
function closeSheet(){ $('.sheet-bg')?.classList.remove('on'); $('.sheet')?.classList.remove('on'); }
/* Presentación de partido */
let stageTimers=[];
function present(j,i){
  const f=poloFix(j), r=tie(j)?.rubbers?.[i]; if(!f||!r) return; const p=persp(f), c=rubberCalc(r);
  let st=$('.stage'); if(!st){ st=document.createElement('div'); st.className='stage'; st.setAttribute('role','dialog'); st.setAttribute('aria-modal','true'); document.body.appendChild(st); }
  const ids=r.polo||[]; const pls=ids.map(player).filter(Boolean);
  const leftName = pls.length? pls.map(x=>x.name.split(' ')[0]).join(' y ') : 'Por designar';
  const ghost = pls.length? pls[0].name.split(' ').slice(-1)[0] : 'POLO';
  const ps = ids.length===1? playerStats(ids[0]) : null; const cs=clubSeason(p.rival); const vsRec = ps?.vs?.[p.rival];
  const avs = pls.length? pls.map(x=>avatar(x, pls.length>1?'lg':'xl')).join('') : avatar(null,'xl');
  st.innerHTML=`<div class="beam l"></div><div class="beam r"></div><button class="x" data-act="stage-close">Cerrar</button>
    <div class="ribbon">${RUBBERS[i].label}, jornada ${j}. ${p.home?'En casa':'Fuera'}, ${esc(fdate(f,{weekday:'long',day:'numeric',month:'long'}))}</div>
    <div class="versus"><div class="vside l"><span class="ghost">${esc(ghost)}</span><span class="duo" style="justify-content:center">${avs}</span><span class="nm">${esc(leftName)}</span><span class="meta">Real Club de Polo${pls.length===1?', nº '+pls[0].order:''}</span></div>
      <div class="vside r"><span class="ghost">${esc(team(p.rival).short)}</span>${crest(p.rival,'lg')}<span class="nm">${esc(team(p.rival).short)}</span><span class="meta">${esc(clubName(p.rival))}</span></div>
      <span class="vs">VS</span><span class="wave"></span><span class="wave w2"></span></div><div class="flash"></div>
    <div class="tape">${c.res?`<p style="text-align:center;font-stretch:62%;font-weight:800;font-size:2rem;margin:0 0 14px">${c.sets.map(s=>s.join('-')).join('  ')} ${resBadge(c.res)}</p>`:''}
      <div class="cols"><div><h3>${esc(leftName)} esta temporada</h3><dl>${ps? `<dt>Partidos</dt><dd>${ps.w}-${ps.l}</dd><dt>% victorias</dt><dd>${ps.pj?pct(ps.w,ps.pj)+'%':'–'}</dd><dt>Racha</dt><dd>${ps.streak.n?(ps.streak.t==='W'?'+':'−')+ps.streak.n:'–'}</dd><dt>Contra este club</dt><dd>${vsRec? vsRec.w+'-'+vsRec.l : 'Primera vez'}</dd>` : pls.length? pls.map(x=>{ const s=playerStats(x.id); return `<dt>${esc(x.name)}</dt><dd>${s.w}-${s.l}</dd>`; }).join('') : '<dt>Jugador</dt><dd>Por designar</dd>'}</dl></div>
        <div><h3>${esc(team(p.rival).short)} esta temporada</h3><dl><dt>Posición</dt><dd>${cs.pj?cs.pos+'º':'–'}</dd><dt>Eliminatorias</dt><dd>${cs.g||0}-${cs.p||0}</dd><dt>Partidos</dt><dd>${cs.rw||0}-${cs.rl||0}</dd><dt>Puntos</dt><dd>${cs.pts||0}</dd></dl></div></div>
      <div class="row" style="justify-content:center;margin-top:10px">${ids.length? ids.map(id=>`<button class="btn light sm" data-player="${esc(id)}">Ficha de ${esc(pname(id).split(' ')[0])}</button>`).join(''):''}<button class="btn ghost sm" style="color:#fff;border-color:rgba(255,255,255,.3)" data-act="stage-close">Volver</button></div></div>
    <button class="skip" data-act="stage-skip">Saltar</button>`;
  stageTimers.forEach(clearTimeout); stageTimers=[]; st.className='stage';
  requestAnimationFrame(()=>{ st.classList.add('on'); document.body.style.overflow='hidden';
    if(RM.matches){ st.classList.add('s1','s2','s3','s4','s5'); return; }
    const seq=[[50,'s1'],[550,'s2'],[1150,'s3'],[1800,'s4'],[2700,'s5']];
    seq.forEach(([t,cl])=>stageTimers.push(setTimeout(()=>{ st.classList.add(cl); if(cl==='s4'){ st.classList.add('shake'); navigator.vibrate?.([30,40,60]); const b=st.querySelector('.vs').getBoundingClientRect(); confetti(b.left+b.width/2,b.top+b.height/2,50); setTimeout(()=>st.classList.remove('shake'),500); } },t)));
  });
}
function stageSkip(){ const st=$('.stage'); stageTimers.forEach(clearTimeout); st?.classList.add('s1','s2','s3','s4','s5'); }
function stageClose(){ stageTimers.forEach(clearTimeout); const st=$('.stage'); if(st){ st.classList.remove('on'); } document.body.style.overflow=''; }

/* ===================== FOTOS: subir, recortar y encuadrar ===================== */
let crop=null;
function openCropper(target, pick){
  const team=target==='_team', aspect=team? 16/9 : 3/4, outW=team? 1600 : 600, outH=Math.round(outW/aspect);
  let m=$('.cropper'); if(!m){ m=document.createElement('div'); m.className='cropper'; m.setAttribute('role','dialog'); m.setAttribute('aria-modal','true'); document.body.appendChild(m); }
  m.innerHTML=`<div class="cbox"><div class="row" style="justify-content:space-between"><b>${team?'Foto del equipo':'Foto de '+esc(pname(target))}</b><button class="iconbtn" data-act="crop-close" aria-label="Cerrar">✕</button></div>
    <div class="cview" style="aspect-ratio:${aspect}"><canvas></canvas>${team?'':'<span class="cguide"></span>'}<p class="chint">Elige una imagen</p></div>
    <label class="f">Zoom</label><input type="range" min="1" max="4" step="0.01" value="1" class="czoom">
    <p class="muted small" style="margin:6px 0 0">Arrastra para encuadrar. ${team?'Formato 16:9.':'Formato vertical 3:4: deja la cara en el tercio superior; los círculos usan esa zona.'}</p>
    <div class="row" style="margin-top:14px"><label class="btn ghost sm">Elegir imagen<input type="file" accept="image/*" class="cfile" hidden></label><span style="flex:1"></span><button class="btn ghost sm" data-act="crop-close">Cancelar</button><button class="btn brass" data-act="crop-save" disabled>Guardar foto</button></div></div>`;
  m.classList.add('on'); document.body.style.overflow='hidden';
  const cv=m.querySelector('canvas'), view=m.querySelector('.cview'), zoom=m.querySelector('.czoom'), file=m.querySelector('.cfile'), save=m.querySelector('[data-act=crop-save]');
  crop={target,aspect,outW,outH,img:null,z:1,ox:0,oy:0,cv,view};
  const fit=()=>{ const r=view.getBoundingClientRect(), dpr=devicePixelRatio||1; cv.width=r.width*dpr; cv.height=r.height*dpr; crop.vw=r.width; crop.vh=r.height; };
  const base=()=>Math.max(crop.vw/crop.img.width, crop.vh/crop.img.height);
  const clamp=()=>{ const s=base()*crop.z, w=crop.img.width*s, h=crop.img.height*s; crop.ox=Math.min(0,Math.max(crop.vw-w,crop.ox)); crop.oy=Math.min(0,Math.max(crop.vh-h,crop.oy)); };
  const draw=()=>{ if(!crop?.img) return; clamp(); const g=cv.getContext('2d'), dpr=devicePixelRatio||1, s=base()*crop.z; g.setTransform(dpr,0,0,dpr,0,0); g.clearRect(0,0,crop.vw,crop.vh); g.drawImage(crop.img,crop.ox,crop.oy,crop.img.width*s,crop.img.height*s);
    g.strokeStyle='rgba(255,255,255,.35)'; g.lineWidth=1; for(let i=1;i<3;i++){ g.beginPath(); g.moveTo(crop.vw*i/3,0); g.lineTo(crop.vw*i/3,crop.vh); g.moveTo(0,crop.vh*i/3); g.lineTo(crop.vw,crop.vh*i/3); g.stroke(); } };
  const load=src=>{ const im=new Image(); im.onload=()=>{ crop.img=im; crop.z=1; zoom.value=1; fit(); const s=base(); crop.ox=(crop.vw-im.width*s)/2; crop.oy=team? (crop.vh-im.height*s)/2 : 0; view.querySelector('.chint').hidden=true; save.disabled=false; draw(); }; im.src=src; };
  crop.draw=draw;
  file.onchange=()=>{ const f=file.files[0]; if(!f) return; const rd=new FileReader(); rd.onload=()=>load(rd.result); rd.readAsDataURL(f); };
  zoom.oninput=()=>{ if(!crop.img) return; const cx=crop.vw/2, cy=crop.vh/2, s0=base()*crop.z; crop.z=+zoom.value; const s1=base()*crop.z; crop.ox=cx-(cx-crop.ox)*s1/s0; crop.oy=cy-(cy-crop.oy)*s1/s0; draw(); };
  let drag=null; cv.onpointerdown=e=>{ drag={x:e.clientX,y:e.clientY,ox:crop.ox,oy:crop.oy}; cv.setPointerCapture(e.pointerId); };
  cv.onpointermove=e=>{ if(!drag) return; crop.ox=drag.ox+e.clientX-drag.x; crop.oy=drag.oy+e.clientY-drag.y; draw(); }; cv.onpointerup=()=>drag=null;
  cv.onwheel=e=>{ e.preventDefault(); zoom.value=Math.min(4,Math.max(1,+zoom.value-e.deltaY*.002)); zoom.oninput(); };
  if(photos[target]?.d && !pick) setTimeout(()=>load(photos[target].d),30); else file.click();
}
function closeCropper(){ $('.cropper')?.classList.remove('on'); document.body.style.overflow=''; crop=null; }
async function saveCrop(){
  if(!crop?.img) return; const o=document.createElement('canvas'); o.width=crop.outW; o.height=crop.outH; const g=o.getContext('2d'), k=crop.outW/crop.vw, s=Math.max(crop.vw/crop.img.width,crop.vh/crop.img.height)*crop.z;
  g.fillStyle='#0A2A20'; g.fillRect(0,0,o.width,o.height); g.imageSmoothingQuality='high'; g.drawImage(crop.img,crop.ox*k,crop.oy*k,crop.img.width*s*k,crop.img.height*s*k);
  let q=.86, d=o.toDataURL('image/webp',q); if(!d.startsWith('data:image/webp')) d=o.toDataURL('image/jpeg',q);
  while(d.length>850000 && q>.4){ q-=.12; d=o.toDataURL(d.startsWith('data:image/webp')?'image/webp':'image/jpeg',q); }
  const target=crop.target; photos[target]={d,at:Date.now()}; closeCropper(); renderQuiet();
  await safe(()=>B.set('photos/'+target,photos[target]),'Foto guardada');
}

/* ===================== CARTEL DE CONVOCATORIA ===================== */
const FMT={story:[1080,1920],square:[1080,1080],wide:[1920,1080]};
const imgCache={};
function loadImg(src){ if(!src) return Promise.resolve(null); if(!imgCache[src]) imgCache[src]=new Promise(r=>{ const i=new Image(); i.onload=()=>r(i); i.onerror=()=>r(null); i.src=src; }); return imgCache[src]; }
function coverImg(g,im,x,y,w,h,fx=.5,fy=.5){ const s=Math.max(w/im.width,h/im.height), dw=im.width*s, dh=im.height*s; g.drawImage(im,x+(w-dw)*fx,y+(h-dh)*fy,dw,dh); }
function dtext(g,t,x,y,{size,weight=700,cond=false,color='#fff',maxW=1e9,align='left',min=10,ls=0}){
  let s=size; const native='fontStretch' in g, sc=cond&&!native? .74 : 1;
  const set=()=>{ g.font=`${weight} ${s}px Archivo, "Arial Narrow", Arial, sans-serif`; if(native) g.fontStretch=cond?'extra-condensed':'normal'; if('letterSpacing' in g) g.letterSpacing=ls? ls+'px':'0px'; };
  set(); while(g.measureText(t).width*sc>maxW && s>min){ s-=2; set(); }
  g.fillStyle=color; g.textAlign=align; g.textBaseline='alphabetic';
  if(sc!==1){ g.save(); g.translate(x,y); g.scale(sc,1); g.fillText(t,0,0); g.restore(); } else g.fillText(t,x,y);
  if('letterSpacing' in g) g.letterSpacing='0px'; return s;
}
function rrect(g,x,y,w,h,r){ g.beginPath(); g.moveTo(x+r,y); g.arcTo(x+w,y,x+w,y+h,r); g.arcTo(x+w,y+h,x,y+h,r); g.arcTo(x,y+h,x,y,r); g.arcTo(x,y,x+w,y,r); g.closePath(); }
function gridFit(n,w,h,ratio,gap){ let best=null; for(let c=1;c<=n;c++){ const r=Math.ceil(n/c), cw=Math.min((w-gap*(c-1))/c,((h-gap*(r-1))/r)*ratio); if(!best||cw>best.cw+0.5) best={c,r,cw,ch:cw/ratio}; } return best; }
async function drawCard(g,x,y,w,h,pid,role,U){
  const pl=player(pid), im=await loadImg(photos[pid]?.d), r=Math.max(10,w*.06);
  g.save(); rrect(g,x,y,w,h,r); g.clip();
  const bgG=g.createLinearGradient(x,y,x+w,y+h); bgG.addColorStop(0,'#1B5A46'); bgG.addColorStop(1,'#0A2A20'); g.fillStyle=bgG; g.fillRect(x,y,w,h);
  if(im) coverImg(g,im,x,y,w,h,.5,.2);
  else { const ini=(pl?.name||'?').split(' ').map(s=>s[0]).slice(0,2).join(''); dtext(g,ini,x+w/2,y+h*.5,{size:w*.42,weight:800,cond:true,color:'rgba(226,196,124,.55)',align:'center'}); }
  const sh=g.createLinearGradient(0,y+h*.42,0,y+h); sh.addColorStop(0,'rgba(6,24,18,0)'); sh.addColorStop(1,'rgba(6,24,18,.96)'); g.fillStyle=sh; g.fillRect(x,y+h*.42,w,h*.58);
  g.restore();
  g.save(); rrect(g,x,y,w,h,r); g.lineWidth=Math.max(2,3*U); g.strokeStyle='rgba(226,196,124,.85)'; g.stroke(); g.restore();
  const pad=w*.07, nm=(pl?.name||'').split(' '), first=nm.length>1? nm.slice(0,-1).join(' ') : '', last=nm.at(-1)||'';
  const ls=dtext(g,last.toUpperCase(),x+pad,y+h-pad,{size:w*.17,weight:800,cond:true,maxW:w-pad*2});
  if(first) dtext(g,first,x+pad,y+h-pad-ls*1.02,{size:Math.max(12,w*.085),weight:500,color:'#D9E3DD',maxW:w-pad*2});
  if(role){ const fs=Math.max(12,w*.062); g.font=`700 ${fs}px Archivo, Arial, sans-serif`; if('fontStretch' in g) g.fontStretch='normal'; const tw=g.measureText(role).width, ph=fs*1.7;
    g.fillStyle=role==='Suplente'?'rgba(241,244,239,.88)':'#E2C47C'; rrect(g,x+pad*.8,y+pad*.8,tw+fs*1.2,ph,ph/2); g.fill(); dtext(g,role,x+pad*.8+fs*.6,y+pad*.8+ph*.68,{size:fs,weight:700,color:'#0A2A20'}); }
}
async function drawPoster(cv,j){
  const o=posterOpts(j), [W,H]=FMT[o.fmt]; cv.width=W; cv.height=H; const g=cv.getContext('2d');
  try{ await Promise.all([document.fonts.load('800 80px Archivo'),document.fonts.load('500 40px Archivo')]); }catch(e){}
  const f=poloFix(j), p=persp(f), roles=rolesOf(j), U=Math.min(W,H)/1080, M=64*U;
  let list=lineupList(j); const isSub=pid=>(roles[pid]||[])[0]==='Suplente'; if(!o.showSubs) list=list.filter(x=>!isSub(x));
  const main=list.filter(x=>!isSub(x)), subs=list.filter(isSub);
  g.fillStyle='#0A2A20'; g.fillRect(0,0,W,H);
  if(o.bg==='team' && photos._team){ const im=await loadImg(photos._team.d); if(im){ coverImg(g,im,0,0,W,H,.5,.35); g.fillStyle='rgba(6,24,18,.74)'; g.fillRect(0,0,W,H); } }
  let rg=g.createRadialGradient(W*.15,H*.1,0,W*.15,H*.1,W*.8); rg.addColorStop(0,'rgba(42,122,95,.45)'); rg.addColorStop(1,'rgba(42,122,95,0)'); g.fillStyle=rg; g.fillRect(0,0,W,H);
  rg=g.createRadialGradient(W*.9,H*.95,0,W*.9,H*.95,W*.7); rg.addColorStop(0,'rgba(148,114,42,.35)'); rg.addColorStop(1,'rgba(148,114,42,0)'); g.fillStyle=rg; g.fillRect(0,0,W,H);
  g.save(); g.strokeStyle='rgba(226,196,124,.13)'; g.lineWidth=2*U; const cw=W*.86, chh=H*.9, cx=(W-cw)/2, cy=(H-chh)/2; g.strokeRect(cx,cy,cw,chh); g.strokeRect(cx+cw*.1,cy,cw*.8,chh); g.beginPath(); g.moveTo(cx+cw*.1,cy+chh*.25); g.lineTo(cx+cw*.9,cy+chh*.25); g.moveTo(cx+cw*.1,cy+chh*.75); g.lineTo(cx+cw*.9,cy+chh*.75); g.moveTo(W/2,cy+chh*.25); g.lineTo(W/2,cy+chh*.75); g.stroke(); g.restore();
  const wide=o.fmt==='wide', hx=M, hw=wide? W*.36 : W-M*2;
  let y=M+34*U;
  dtext(g,'REAL CLUB DE POLO DE BARCELONA',hx,y,{size:28*U,weight:700,color:'#E2C47C',maxW:hw,ls:3*U});
  y+=(o.fmt==='story'?180:wide?150:128)*U; const ts=dtext(g,o.title,hx-4*U,y,{size:(o.fmt==='story'?190:wide?170:140)*U,weight:800,cond:true,maxW:hw});
  y+=46*U; dtext(g,o.sub,hx,y,{size:32*U,weight:500,color:'#A9BDB3',maxW:hw});
  y+=(o.fmt==='story'?92:70)*U;
  const cr=(o.fmt==='story'?46:40)*U, ccx=hx+cr, ccy=y-cr*.62;
  g.save(); g.beginPath(); g.arc(ccx,ccy,cr,0,Math.PI*2); g.fillStyle='#EEF3EF'; g.fill(); g.lineWidth=3*U; g.strokeStyle='#E2C47C'; g.stroke(); g.restore();
  dtext(g,team(p.rival).abbr,ccx,ccy+cr*.28,{size:cr*.72,weight:800,cond:true,color:'#0A2A20',align:'center',maxW:cr*1.6});
  dtext(g,'contra '+clubName(p.rival),hx+cr*2+18*U,y,{size:(o.fmt==='story'?60:50)*U,weight:800,cond:true,maxW:hw-cr*2-18*U});
  y+=(o.fmt==='story'?58:48)*U;
  const dline=fdate(f,{weekday:'long',day:'numeric',month:'long'}); dtext(g,`${dline.charAt(0).toUpperCase()+dline.slice(1)}, ${f.time} h. ${p.home?'En casa.':'Fuera.'}`,hx,y,{size:32*U,weight:600,color:'#F1F4EF',maxW:hw});
  const footH=90*U;
  const fy=H-M;
  dtext(g,o.tagline,hx,fy,{size:(wide?64:58)*U,weight:800,cond:true,color:'#E2C47C',maxW:wide? hw : (W-M*2)*.6});
  dtext(g,S.comp.group,wide? hx : W-M,wide? fy-80*U : fy,{size:24*U,weight:500,color:'#A9BDB3',align:wide?'left':'right',maxW:wide? hw : (W-M*2)*.4});
  const gx=wide? W*.42 : M, gw=wide? W-M-gx : W-M*2, gy=wide? M : y+56*U, gh=(wide? H-M : fy-footH)-gy;
  if(!list.length){ dtext(g,'Convocatoria pendiente',gx+gw/2,gy+gh/2,{size:48*U,weight:700,color:'#A9BDB3',align:'center'}); return; }
  const gap=(list.length>8?16:22)*U, labH=subs.length? 44*U : 0;
  let Lm=gridFit(main.length||1,gw,gh,.78,gap), Ls=null;
  if(subs.length){ let best=null;
    for(let sh=.16; sh<=.5; sh+=.02){ const m=gridFit(main.length||1,gw,gh*(1-sh)-labH,.78,gap), sb=gridFit(subs.length,gw,gh*sh,.78,gap);
      if(sb.cw < m.cw*.55) continue; const score=m.cw + Math.min(sb.cw,m.cw*.72)*.35; if(!best||score>best.score) best={score,m,sb}; }
    if(!best){ const m=gridFit(main.length||1,gw,gh*.6-labH,.78,gap); best={m,sb:gridFit(subs.length,gw,gh*.4,.78,gap)}; }
    Lm=best.m; Ls=best.sb; const cap=Lm.cw*.72; if(Ls.cw>cap){ Ls={...Ls,cw:cap,ch:cap/.78}; } }
  const sizeOf=(L,n)=>L? Math.ceil(n/L.c)*L.ch+(Math.ceil(n/L.c)-1)*gap : 0;
  const usedM=main.length? sizeOf(Lm,main.length) : 0, usedS=Ls? sizeOf(Ls,subs.length) : 0;
  const total=usedM+(Ls? labH+gap*.5+usedS : 0); let yy=gy+Math.max(0,(gh-total)/2);
  const place=async(ids,L,y0)=>{ let k=0; for(let r=0;k<ids.length;r++){ const inRow=Math.min(L.c,ids.length-k), rowW=inRow*L.cw+(inRow-1)*gap; let x0=gx+(gw-rowW)/2;
      for(let c=0;c<inRow;c++){ const pid=ids[k++]; await drawCard(g,x0,y0,L.cw,L.ch,pid,(roles[pid]||[]).join(' + '),U); x0+=L.cw+gap; } y0+=L.ch+gap; } };
  if(main.length){ await place(main,Lm,yy); yy+=usedM; }
  if(Ls){ yy+=gap*.5; g.save(); g.strokeStyle='rgba(226,196,124,.4)'; g.lineWidth=2*U; const lw=Math.min(gw*.25,160*U); g.beginPath(); g.moveTo(gx+gw/2-lw-90*U,yy+labH*.42); g.lineTo(gx+gw/2-90*U,yy+labH*.42); g.moveTo(gx+gw/2+90*U,yy+labH*.42); g.lineTo(gx+gw/2+lw+90*U,yy+labH*.42); g.stroke(); g.restore();
    dtext(g,'Suplentes',gx+gw/2,yy+labH*.6,{size:26*U,weight:700,color:'#E2C47C',align:'center'}); yy+=labH; await place(subs,Ls,yy); }
}
function posterBlob(cv){ return new Promise(r=>cv.toBlob(r,'image/png')); }
async function posterExport(j,how,cvEl){
  const cv=cvEl||document.createElement('canvas'); if(!cvEl) await drawPoster(cv,j);
  const o=posterOpts(j), name=`polo-convocatoria-j${j}-${o.fmt}.png`, blob=await posterBlob(cv); if(!blob) return toast('No se ha podido generar la imagen');
  const file=new File([blob],name,{type:'image/png'});
  if(how==='share' && navigator.canShare && navigator.canShare({files:[file]})){ try{ await navigator.share({files:[file],title:'Convocatoria jornada '+j}); markPoster(j); }catch(e){} return; }
  const url=URL.createObjectURL(blob), a=document.createElement('a'); a.href=url; a.download=name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),4000); markPoster(j);
  if(how==='share') toast('Este navegador no comparte imágenes: se ha descargado');
}
function markPoster(j){ if(!isAdmin) return; const t=ensureTie(j); t.poster={...(t.poster||{}),at:Date.now()}; saveState('Cartel listo'); }
function openPosterModal(j){
  let m=$('.pmodal'); if(!m){ m=document.createElement('div'); m.className='pmodal'; m.setAttribute('role','dialog'); m.setAttribute('aria-modal','true'); document.body.appendChild(m); }
  const o=posterOpts(j);
  m.innerHTML=`<div class="pmbox"><div class="row" style="justify-content:space-between"><b>Convocatoria, jornada ${j}</b><button class="iconbtn" data-act="pm-close" aria-label="Cerrar">✕</button></div>
    <div class="chips" style="margin:10px 0">${[['story','Vertical'],['square','Cuadrado'],['wide','Horizontal']].map(([k,l])=>`<button class="chip" data-act="pm-fmt" data-j="${j}" data-v="${k}" aria-pressed="${(ui.pmFmt||o.fmt)===k}">${l}</button>`).join('')}</div>
    <canvas class="pcanvas"></canvas><div class="row" style="margin-top:12px"><button class="btn brass" data-act="pm-dl" data-j="${j}">Descargar</button>${navigator.share?`<button class="btn" data-act="pm-share" data-j="${j}">Compartir</button>`:''}</div></div>`;
  m.classList.add('on'); document.body.style.overflow='hidden';
  const t=tie(j), save=t.poster; t.poster={...(save||{}),fmt:ui.pmFmt||o.fmt}; drawPoster(m.querySelector('canvas'),j).then(()=>{ t.poster=save; });
}
function closePosterModal(){ $('.pmodal')?.classList.remove('on'); document.body.style.overflow=''; }

/* ===================== WHATSAPP ===================== */
function waPhone(raw){ let d=String(raw||'').replace(/[^\d+]/g,''); if(d.startsWith('+')) d=d.slice(1); else if(d.startsWith('00')) d=d.slice(2); else if(d.length===9) d='34'+d; return d; }
function waOpen(text,phone){ const url=`https://wa.me/${phone||''}?text=${encodeURIComponent(text)}`; const l=document.createElement('a'); l.href=url; l.target='_blank'; l.rel='noopener'; document.body.appendChild(l); l.click(); l.remove(); }
function logSend(kind,j,extra){ const t=ensureTie(j), now=Date.now();
  if(kind==='req') t.availReq={at:now,n:(t.availReq?.n||0)+1};
  else if(kind==='rem') t.remLog=[...(t.remLog||[]),{at:now,...(extra||{})}].slice(-40);
  else if(kind==='lineup') t.lineupAnnounced=now;
  saveState(kind==='req'?'Solicitud registrada':kind==='lineup'?'Anuncio registrado':'Recordatorio registrado'); }

/* ===================== ROUTER Y RENDER ===================== */
const route = () => (location.hash||'#inicio').slice(1)||'inicio';
function render(){
  const app=$('#app'), gate=!authReady || !authUser || (!me && !adminSkip);
  document.body.classList.toggle('gate', gate);
  let html, nav=route();
  if(!authReady) html=`<div class="gatebox">${courtSVG()}</div>`;
  else if(!authUser) html=vLogin();
  else if(!me && !adminSkip) html=vClaim();
  else { const r=nav;
    if(r==='inicio') html=vInicio(); else if(r==='liga') html=vLiga();
    else if(r.startsWith('jornada-')){ html=vJornada(+r.slice(8)); nav='liga'; }
    else if(r==='equipo') html=vEquipo();
    else if(r.startsWith('jugador-')){ html=vJugador(r.slice(8)); nav='equipo'; }
    else if(r.startsWith('disponibilidad-')){ html=vDisponibilidad(+r.slice(15)); nav='votar'; }
    else if(r==='stats') html=vStats(); else if(r==='votar') html=vVotar(); else if(r==='admin') html=vAdmin(); else html=vNotFound();
    html+=`<footer class="wrap">Datos oficiales: Federació Catalana de Tennis. App privada del equipo masculino absoluto del Real Club de Polo de Barcelona.${S.updatedAt?' Actualizado el '+new Date(S.updatedAt).toLocaleString('es-ES',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})+'.':''}</footer>`; }
  app.innerHTML=`<div class="page">${html}</div>`;
  document.querySelectorAll('[data-nav]').forEach(a=>{ if(a.dataset.nav===nav) a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current'); });
  $('.adminlink').classList.toggle('on',isAdmin);
  const mb=$('.mebtn'); if(mb) mb.innerHTML = me? avatar(player(me)) : (authUser? `<span class="av">${esc((authUser.email||'?')[0].toUpperCase())}</span>`:'');
  const dot=document.querySelector('.tabbar [data-nav="votar"]'); if(dot){ dot.querySelector('.dot')?.remove(); const nx=nextPoloFix(); if(pendingSurveys().length || (nx&&me&&availOpen(nx)&&!avOf(me,nx.j))) dot.insertAdjacentHTML('beforeend','<span class="dot"></span>'); }
  afterRender(app);
}
function editing(){ const a=document.activeElement; return a && a.closest('#app') && /INPUT|TEXTAREA|SELECT/.test(a.tagName); }
function softRender(){ if($('.cropper.on')||$('.pmodal.on')){ ui.pendingRender=true; return; } if(editing()||ui.survey&&route()==='votar'&&document.activeElement?.tagName==='TEXTAREA'){ ui.pendingRender=true; return; } renderQuiet(); }
function renderQuiet(){ // re-render sin repetir la animación de entrada
  const y=scrollY; render(); const pg=$('#app .page'); if(pg) pg.style.animation='none'; $('#app').querySelectorAll('.stagger>*').forEach(c=>c.style.animation='none'); scrollTo(0,y);
}
document.addEventListener('focusout',()=>setTimeout(()=>{ if(ui.pendingRender&&!editing()){ ui.pendingRender=false; renderQuiet(); } },150));
let lastRoute=null;
window.addEventListener('hashchange',()=>{ ui.survey=null; ui.avDraft=null; ui.compose=null; closeSheet(); stageClose(); closePosterModal(); render(); if(route()!==lastRoute) scrollTo(0,0); lastRoute=route(); });
function toast(m){ const t=$('#toast'); if(!t) return; t.textContent=m; t.classList.add('on'); clearTimeout(toast._t); toast._t=setTimeout(()=>t.classList.remove('on'),2600); }

/* ===================== ESCRITURA ===================== */
let chain=Promise.resolve();
function saveState(msg='Guardado'){ S.updatedAt=Date.now(); const body=clone(S);
  chain=chain.then(()=>B.set(SEASON_PATH,body)).then(()=>toast(msg)).catch(e=>toast('No se ha podido guardar: '+(e?.code||e?.message||'error'))); renderQuiet(); }
async function safe(fn,ok){ try{ await fn(); if(ok) toast(ok); }catch(e){ toast(e?.message?.includes('elegido')? e.message : 'No se ha podido guardar: '+(e?.code||e?.message||'error')); } }

document.addEventListener('click', async e=>{
  const pl=e.target.closest('[data-player]'); if(pl){ e.preventDefault(); stageClose(); openSheet(pl.dataset.player); return; }
  const pr=e.target.closest('[data-present]'); if(pr){ const [j,i]=pr.dataset.present.split(':').map(Number); present(j,i); return; }
  const el=e.target.closest('[data-act]'); if(!el) return; const a=el.dataset.act;
  if(a==='signin') B.signIn();
  else if(a==='signout'){ B.signOut(); closeSheet(); }
  else if(a==='me'){ if(me) openSheet(me); else if(authUser && confirm('¿Cerrar sesión?')) B.signOut(); }
  else if(a==='skip'){ adminSkip=true; render(); }
  else if(a==='unskip'){ adminSkip=false; render(); }
  else if(a==='claim'){ const id=el.dataset.id; await safe(()=>B.claim(id)); }
  else if(a==='unclaim'){ const pid=el.dataset.pid, c=claims[pid]; if(!confirm('¿Liberar '+pname(pid)+'? Tendrá que volver a elegir su nombre.')) return; await safe(async()=>{ await B.del('claims/'+pid); if(c?.uid) await B.del('users/'+c.uid).catch(()=>{}); },'Liberado'); }
  else if(a==='close-sheet') closeSheet();
  else if(a==='stage-close') stageClose();
  else if(a==='stage-skip') stageSkip();
  else if(a==='reveal'){ const j=+el.dataset.j; if(!ui.revealed[j]){ ui.revealed[j]=true; el.classList.add('open'); const b=el.getBoundingClientRect(); confetti(b.left+b.width/2,b.top+30); navigator.vibrate?.(40); } }
  else if(a==='liga-filter'){ ui.ligaAll=el.dataset.v==='1'; render(); }
  else if(a==='stats-tab'){ ui.statsTab=el.dataset.v; render(); }
  else if(a==='sort'){ ui.sortKey=el.dataset.v; renderQuiet(); }
  else if(a==='cmp'){ ui.cmpA=el.dataset.id; ui.statsTab='jugadores'; }
  else if(a==='admin-tab'){ ui.adminTab=el.dataset.v; render(); }
  else if(a==='avail'){ if(!me) return; const k=jid(+el.dataset.j); const cur=avail[me]||{j:{}}; const next={j:{...(cur.j||{}),[k]:el.dataset.v},at:Date.now()};
    avail[me]=next; renderQuiet(); if(el.dataset.v==='yes'){ const b=el.getBoundingClientRect(); confetti(b.left+b.width/2,b.top,40); }
    await safe(()=>B.set(SEASON_PATH+'/avail/'+me,next), el.dataset.v==='yes'?'Apuntado: juegas':'Anotado: no puedes'); }
  else if(a==='pick'){ if(!me) return; const k=jid(+el.dataset.j), cur=picks[me]||{j:{}}; const next={j:{...(cur.j||{}),[k]:{p:+el.dataset.p,r:+el.dataset.r}},at:Date.now()}; picks[me]=next; renderQuiet(); await safe(()=>B.set(SEASON_PATH+'/picks/'+me,next),'Pronóstico guardado'); }
  else if(a==='survey-start'){ const j=+el.dataset.j; ui.survey={j,step:0,a:{...(myBallot?.j?.[jid(j)]?.a||{})}}; render(); scrollTo({top:0}); }
  else if(a==='survey-prev'){ ui.survey.step=Math.max(0,ui.survey.step-1); renderQuiet(); }
  else if(a==='survey-next'){ ui.survey.step++; renderQuiet(); }
  else if(a==='ans'){ const q=S.survey.questions.find(x=>x.id===el.dataset.q); ui.survey.a[el.dataset.q]=q?.type==='scale'? +el.dataset.v : el.dataset.v; renderQuiet(); setTimeout(()=>{ if(ui.survey){ ui.survey.step++; renderQuiet(); } },220); }
  else if(a==='survey-send'){ const k=jid(ui.survey.j); const body={j:{...(myBallot?.j||{}),[k]:{a:ui.survey.a,at:Date.now()}}};
    try{ await B.set(SEASON_PATH+'/ballots/'+me,body); myBallot=body; ui.survey=null; render(); toast('Respuestas enviadas'); confetti(innerWidth/2,innerHeight/3); }catch(err){ toast('No se ha podido enviar: '+(err?.code||err?.message||'error')); } }
  else if(a==='save-tie'){ const j=+el.dataset.j, t=ensureTie(j);
    document.querySelectorAll('.redit').forEach(row=>{ const r=t.rubbers[+row.dataset.r]; const g=n=>row.querySelector(`[name=${n}]`)?.value??'';
      r.polo=[g('p1'),r.type==='D'?g('p2'):''].filter(Boolean); r.score=g('score').trim(); r.res=g('res')||null; r.note=g('note').trim(); });
    t.moment=$('#moment').value.trim();
    const f=poloFix(j), calc=tieFromRubbers(j), home=f.home===POLO; let ps=$('#ps').value, rs=$('#rs').value;
    if(calc.complete || (calc.singles===4 && calc.decided===5)){ ps=calc.w; rs=calc.l; }
    if(ps!==''&&rs!==''){ f.hs=home?+ps:+rs; f.as=home?+rs:+ps; } else { f.hs=null; f.as=null; }
    if(calc.needsDoubles && !t.rubbers[4].res) toast('2-2: falta el resultado del dobles'); saveState('Jornada '+j+' guardada'); }
  else if(a==='survey-toggle'){ const k=jid(+el.dataset.j); S.survey.closed={...(S.survey.closed||{})}; if(S.survey.closed[k]) delete S.survey.closed[k]; else S.survey.closed[k]=true; saveState(S.survey.closed[k]?'Encuesta cerrada':'Encuesta reabierta'); }
  else if(a==='publish'){ const j=+el.dataset.j, k=jid(j), agg=aggregate(k);
    S.published[k]={mvp:$('#pub-mvp').value||null,rev:$('#pub-rev').value||null,best:$('#pub-best').value||null,votes:agg.votes,ratings:agg.ratings,n:agg.n,at:Date.now()}; saveState('Jornada '+j+' publicada'); confetti(innerWidth/2,innerHeight/2); }
  else if(a==='unpublish'){ delete S.published[jid(+el.dataset.j)]; saveState('Publicación retirada'); }
  else if(a==='q-add'){ readQuestions(); S.survey.questions.push({id:'q_'+Date.now().toString(36),scope:'peer',type:'player',text:'Nueva pregunta'}); renderQuiet(); }
  else if(a==='q-del'){ readQuestions(); S.survey.questions.splice(+el.dataset.i,1); renderQuiet(); }
  else if(a==='q-save'){ readQuestions(); saveState('Preguntas guardadas'); }
  else if(a==='q-reset'){ S.survey.questions=DEFAULT_Q.map(q=>({...q})); saveState('Preguntas restauradas'); }
  else if(a==='players-save'){ const cap=document.querySelector('input[name=captain]:checked')?.value;
    const ph={...phones}; let phChanged=false;
    document.querySelectorAll('#plist [data-id]').forEach(row=>{ const p=player(row.dataset.id); if(!p) return; const g=n=>row.querySelector(`[name=${n}]`);
      p.name=g('name').value.trim()||p.name; p.full=g('full').value.trim()||p.name; p.order=+g('order').value||p.order; p.cat=g('cat').value.trim(); p.pts=+g('pts').value||0; p.active=g('active').checked; p.captain=p.id===cap;
      const v=g('phone').value.trim(); if((ph[p.id]||'')!==v){ phChanged=true; if(v) ph[p.id]=v; else delete ph[p.id]; } });
    if(phChanged){ phones=ph; safe(()=>B.set('private/phones',{map:ph})); }
    saveState('Plantilla guardada'); }
  else if(a==='player-add'){ const name=$('#np-name').value.trim(); if(!name) return toast('Escribe el nombre'); let id=slug(name); while(player(id)) id+='-2';
    S.players.push({id,name,full:$('#np-full').value.trim()||name,cat:$('#np-cat').value.trim(),pts:0,order:Math.max(...S.players.map(p=>p.order))+1,captain:false,active:true}); saveState(name+' añadido'); }
  else if(a==='teams-save'){ document.querySelectorAll('#tlist [data-id]').forEach(row=>{ const t=team(row.dataset.id); ['name','short','abbr'].forEach(n=>{ const v=row.querySelector(`[name=${n}]`).value.trim(); if(v) t[n]=v; }); }); saveState('Clubes guardados'); }
  else if(a==='fixtures-save'){ document.querySelectorAll('#flist [data-k]').forEach(row=>{ const f=S.fixtures[+row.dataset.k], g=n=>row.querySelector(`[name=${n}]`).value; f.date=g('date')||f.date; f.time=g('time')||f.time; f.home=g('home'); f.away=g('away'); const hs=g('hs'),as=g('as'); if(hs!==''&&as!==''){ f.hs=+hs; f.as=+as; } else { f.hs=null; f.as=null; } }); saveState('Jornada '+el.dataset.j+' guardada'); }
  else if(a==='official-save'){ const order=[...document.querySelectorAll('#offlist select')].map(x=>x.value); if(new Set(order).size!==order.length) return toast('Hay clubes repetidos'); S.official={asOf:+$('#off-j').value||0,order}; saveState('Clasificación oficial guardada'); }
  else if(a==='rules-save'){ S.rules={...S.rules,win:+$('#r-win').value,loss:+$('#r-loss').value,availDays:Math.max(1,Math.min(14,+$('#r-av').value||6))}; saveState('Reglas guardadas'); }
  else if(a==='go-admin'){ ui.adminTab='jornada'; ui.adminJ=+el.dataset.j; ui.jTab=el.dataset.t||'disp'; location.hash='admin'; }
  else if(a==='jtab'){ ui.jTab=el.dataset.v; ui.compose=null; render(); }
  else if(a==='av-pick'){ ui.avDraft.s=el.dataset.v; const ta=$('#av-c'); if(ta) ui.avDraft.c=ta.value; renderQuiet(); }
  else if(a==='av-chip'){ const ta=$('#av-c'); const c=(ta?.value||'').trim(); ui.avDraft.c = c? (c.includes(el.dataset.v)? c : c+'. '+el.dataset.v) : el.dataset.v; renderQuiet(); }
  else if(a==='av-save'){ const j=+el.dataset.j, k=jid(j), now=Date.now(), d=ui.avDraft; if(!me||!d?.s) return; d.c=($('#av-c')?.value||'').trim();
    const cur=avail[me]||{}; const prev=avOf(me,j);
    const next={j:{...(cur.j||{}),[k]:{s:d.s,at:now}}, h:{...(cur.h||{}),[k]:[...((cur.h||{})[k]||[]),{s:d.s,at:now}].slice(-30)}};
    avail[me]=next; const curN=notes[me]||{}, prevC=curN.j?.[k]?.c||'';
    try{ await B.set(SEASON_PATH+'/avail/'+me,next);
      if(d.c!==prevC){ const nn={j:{...(curN.j||{}),[k]:{c:d.c,at:now}}, h:{...(curN.h||{}),[k]:[...((curN.h||{})[k]||[]),{c:d.c,at:now}].slice(-20)}}; notes[me]=nn; await B.set(SEASON_PATH+'/availNotes/'+me,nn); }
      toast(prev? 'Respuesta actualizada' : 'Respuesta enviada'); if(d.s==='yes'){ const b=el.getBoundingClientRect(); confetti(b.left+b.width/2,b.top,50); } renderQuiet();
    }catch(err){ toast('No se ha podido guardar: '+(err?.code||err?.message||'error')); } }
  else if(a==='compose'){ const j=+el.dataset.j, kind=el.dataset.kind; ui.compose={kind,j,text:composeText(kind,j)}; renderQuiet(); setTimeout(()=>$('#compose-text')?.focus(),50); }
  else if(a==='compose-close'){ ui.compose=null; renderQuiet(); }
  else if(a==='wa-send'||a==='wa-share'||a==='wa-copy'){ const j=+el.dataset.j, kind=el.dataset.kind, text=$('#compose-text')?.value||''; ui.compose.text=text;
    if(a==='wa-send') waOpen(text);
    else if(a==='wa-share'){ try{ await navigator.share({text}); }catch(e){ return; } }
    else { try{ await navigator.clipboard.writeText(text); toast('Texto copiado'); }catch(e){ toast('Selecciona el texto y cópialo a mano'); return; } }
    logSend(kind,j,kind==='rem'?{n:availFor(j).none.length}:null); }
  else if(a==='wa-one'){ const j=+el.dataset.j, pid=el.dataset.pid; const text=fillMsg(S.msgs.remOne,{...msgVars(j),nombre:pname(pid).split(' ')[0]}); waOpen(text,waPhone(phones[pid])); logSend('rem',j,{pid}); }
  else if(a==='dl-save'){ const j=+el.dataset.j, v=$('#dl').value; if(!v) return toast('Elige fecha y hora'); ensureTie(j).deadline=v; saveState('Plazo guardado'); }
  else if(a==='dl-reset'){ const t=ensureTie(+el.dataset.j); delete t.deadline; saveState('Plazo por defecto'); }
  else if(a==='conv-save'){ const j=+el.dataset.j, t=ensureTie(j);
    const conv=[...document.querySelectorAll('input[name=conv]:checked')].map(x=>x.value);
    document.querySelectorAll('.redit').forEach(row=>{ const r=t.rubbers[+row.dataset.r]; const g=n=>row.querySelector(`[name=${n}]`)?.value??''; r.polo=[g('p1'),r.type==='D'?g('p2'):''].filter(Boolean); });
    const assigned=new Set(t.rubbers.flatMap(r=>r.polo)); assigned.forEach(x=>{ if(!conv.includes(x)) conv.push(x); });
    t.convocados=conv; t.subs=conv.filter(x=>!assigned.has(x));
    if(el.dataset.pub==='1'){ if(!t.lineupPub) t.lineupPubAt=Date.now(); t.lineupPub=true; }
    saveState(el.dataset.pub==='1'?'Convocatoria publicada':'Borrador guardado'); if(el.dataset.pub==='1') confetti(innerWidth/2,innerHeight/2,60); }
  else if(a==='conv-pub'){ const t=ensureTie(+el.dataset.j); t.lineupPub=el.dataset.v==='1'; saveState(t.lineupPub?'Publicada':'Publicación retirada'); }
  else if(a==='poster-set'){ const j=adminJ(), t=ensureTie(j); t.poster={...(t.poster||{}),[el.dataset.k]:el.dataset.v}; saveState('Cartel actualizado'); }
  else if(a==='poster-texts'){ const t=ensureTie(+el.dataset.j); t.poster={...(t.poster||{}),title:$('#pt-title').value.trim(),sub:$('#pt-sub').value.trim(),tagline:$('#pt-tag').value.trim()}; saveState('Textos aplicados'); }
  else if(a==='poster-move'){ const j=adminJ(), t=ensureTie(j), save=t.poster||{}; t.poster={...save,hidden:[]}; const all=lineupList(j); t.poster=save; const i=all.indexOf(el.dataset.pid), k=i+(+el.dataset.d); if(k<0||k>=all.length) return; [all[i],all[k]]=[all[k],all[i]]; t.poster={...save,order:all}; saveState('Orden actualizado'); }
  else if(a==='poster-reset'){ const t=ensureTie(+el.dataset.j); t.poster={at:t.poster?.at}; saveState('Diseño automático'); }
  else if(a==='poster-dl'||a==='poster-share'){ posterExport(+el.dataset.j, a==='poster-share'?'share':'dl', $('#poster-canvas')); }
  else if(a==='poster-open'){ ui.pmFmt=null; openPosterModal(+el.dataset.j); }
  else if(a==='pm-fmt'){ ui.pmFmt=el.dataset.v; openPosterModal(+el.dataset.j); }
  else if(a==='pm-dl'||a==='pm-share'){ posterExport(+el.dataset.j, a==='pm-share'?'share':'dl', $('.pmodal canvas')); }
  else if(a==='pm-close') closePosterModal();
  else if(a==='crop') openCropper(el.dataset.target);
  else if(a==='crop-close') closeCropper();
  else if(a==='crop-save') saveCrop();
  else if(a==='photo-del'){ const t=el.dataset.target; if(!confirm('¿Quitar la foto?')) return; delete photos[t]; renderQuiet(); await safe(()=>B.del('photos/'+t),'Foto quitada'); }
  else if(a==='comp-save'){ S.comp={name:$('#c-name').value.trim()||S.comp.name, group:$('#c-group').value.trim(), memorial:$('#c-mem').value.trim()}; saveState('Competición guardada'); }
  else if(a==='team-add'){ const n=$('#nt-name').value.trim(); if(!n) return toast('Escribe el nombre del club'); let id=slug(n); while(S.teams.find(t=>t.id===id)) id+='-2'; S.teams.push({id,name:n,short:n,abbr:n.split(/\s+/).map(w=>w[0]).join('').slice(0,4).toUpperCase()}); saveState(n+' añadido'); }
  else if(a==='team-del'){ const id=el.dataset.id; if(S.fixtures.some(f=>f.home===id||f.away===id)) return toast('Quita antes sus enfrentamientos del calendario'); S.teams=S.teams.filter(t=>t.id!==id); saveState('Club quitado'); }
  else if(a==='jornada-add'){ const n=NJ()+1, last=S.fixtures.filter(f=>f.j===NJ())[0]; let d=new Date(); if(last){ d=new Date(last.date+'T12:00:00'); d.setDate(d.getDate()+7); } const others=S.teams.filter(t=>t.id!==POLO);
    S.fixtures.push({j:n,date:d.toISOString().slice(0,10),time:last?.time||'15:00',home:POLO,away:others[0]?.id||POLO,hs:null,as:null}); ui.calJ=n; saveState('Jornada '+n+' añadida'); }
  else if(a==='fix-add'){ const j=+el.dataset.j, ref=S.fixtures.find(f=>f.j===j); S.fixtures.push({j,date:ref?.date||new Date().toISOString().slice(0,10),time:ref?.time||'15:00',home:S.teams[0].id,away:S.teams[1]?.id||S.teams[0].id,hs:null,as:null}); saveState('Enfrentamiento añadido'); }
  else if(a==='fix-del'){ const k=+el.dataset.k, f=S.fixtures[k]; if(!f||!confirm('¿Quitar '+team(f.home).short+' contra '+team(f.away).short+'?')) return; S.fixtures.splice(k,1); saveState('Enfrentamiento quitado'); }
  else if(a==='jdate'){ const v=$('#jdate').value; if(!v) return toast('Elige la fecha'); S.fixtures.filter(f=>f.j===+el.dataset.j).forEach(f=>f.date=v); saveState('Fecha de la jornada cambiada'); }
  else if(a==='msgs-save'){ ['req','rem','remOne','lineup'].forEach(k=>{ const v=$('#msg-'+k)?.value; if(v!=null) S.msgs[k]=v; }); saveState('Mensajes guardados'); }
  else if(a==='msgs-reset'){ S.msgs={...DEFAULT_MSGS}; saveState('Mensajes restaurados'); }
  else if(a==='season-view'){ switchSeason(el.dataset.id); }
  else if(a==='season-current'){ const m={...(meta||{seasons:[SEASON_ID]}),current:el.dataset.id}; meta=m; await safe(()=>B.set('meta/app',m),'Temporada actual: '+el.dataset.id); render(); }
  else if(a==='season-new'){ const id=($('#ns-id').value||'').trim(); if(!/^[\w-]{2,20}$/.test(id)) return toast('Usa un nombre como 2027-28');
    const list=meta?.seasons?.length? meta.seasons : [SEASON_ID]; if(list.includes(id)) return toast('Esa temporada ya existe');
    const copy=$('#ns-copy').checked, base=normalize(null);
    const ns={...base, seasonId:id, comp:clone(S.comp), rules:clone(S.rules), msgs:clone(S.msgs), survey:{closed:{},questions:clone(S.survey.questions)}, teams: copy? clone(S.teams) : [clone(team(POLO))], players: copy? clone(S.players) : [], fixtures:[], ties:{}, published:{}, official:{asOf:0,order:[]}, updatedAt:Date.now()};
    await safe(async()=>{ await B.set('seasons/'+id,ns); meta={current:id,seasons:[...list,id]}; await B.set('meta/app',meta); },'Temporada '+id+' creada'); switchSeason(id); }
  else if(a==='demo-reset'){ if(confirm('¿Borrar todos los datos de la vista previa?')){ await B.reset(); location.reload(); } }
});
document.addEventListener('change', e=>{ const el=e.target, a=el.dataset?.act;
  if(a==='admin-j'){ ui.adminJ=+el.value; ui.compose=null; render(); }
  else if(a==='cal-j'){ ui.calJ=+el.value; render(); }
  else if(a==='poster-hide'){ const j=adminJ(), t=ensureTie(j), h=new Set(t.poster?.hidden||[]); el.checked? h.delete(el.dataset.pid) : h.add(el.dataset.pid); t.poster={...(t.poster||{}),hidden:[...h]}; saveState('Cartel actualizado'); }
  else if(a==='av-admin'){ const j=+el.dataset.j, pid=el.dataset.pid, k=jid(j), now=Date.now(), cur=avail[pid]||{};
    const next= el.value? {j:{...(cur.j||{}),[k]:{s:el.value,at:now,by:'capitán'}}, h:{...(cur.h||{}),[k]:[...((cur.h||{})[k]||[]),{s:el.value,at:now,by:'capitán'}].slice(-30)}} : null;
    if(next){ avail[pid]=next; safe(()=>B.set(SEASON_PATH+'/avail/'+pid,next),'Anotado para '+pname(pid)); renderQuiet(); } } else if(a==='rank-filter'){ ui.rankFilter=el.value; renderQuiet(); }
  else if(a==='cmp-a'){ ui.cmpA=el.value; renderQuiet(); } else if(a==='cmp-b'){ ui.cmpB=el.value; renderQuiet(); } });
document.addEventListener('input', e=>{ const el=e.target; if(el.dataset?.act==='ans-text'&&ui.survey) ui.survey.a[el.dataset.q]=el.value; if(el.dataset?.act==='av-text'&&ui.avDraft) ui.avDraft.c=el.value; if(el.id==='compose-text'&&ui.compose) ui.compose.text=el.value; });
document.addEventListener('keydown', e=>{ if(e.key==='Escape'){ closeSheet(); stageClose(); closePosterModal(); closeCropper(); } });
function readQuestions(){ document.querySelectorAll('#qlist .qedit').forEach(row=>{ const q=S.survey.questions[+row.dataset.i]; if(!q) return; q.text=row.querySelector('[name=text]').value.trim(); q.scope=row.querySelector('[name=scope]').value; q.type=row.querySelector('[name=type]').value; if(q.scope==='peer') q.type='player'; }); S.survey.questions=S.survey.questions.filter(q=>q.text); }

/* ===================== ARRANQUE ===================== */
function unsubAll(){ subs.forEach(u=>{ try{u()}catch(e){} }); subs=[]; if(mineSub){ try{mineSub()}catch(e){} mineSub=null; } }
function watchMine(){ if(mineSub){ try{mineSub()}catch(e){} mineSub=null; } if(me && !isAdmin) mineSub=B.watchDoc(SEASON_PATH+'/ballots/'+me, d=>{ myBallot=d; softRender(); }); else myBallot=me? ballots[me]||null : null; }
if(B.mode==='demo'){ const d=document.createElement('div'); d.className='demo'; d.textContent='Vista previa: datos solo en este navegador'; document.body.appendChild(d); }
let dataSubs=[];
function subscribeData(){ // se rehace al identificarse o al cambiar de temporada
  dataSubs.forEach(u=>{ try{u()}catch(e){} }); dataSubs=[];
  if(!me && !isAdmin) return;
  dataSubs.push(B.watchDoc('meta/app', d=>{ meta=d; if(!ui.seasonPicked && d?.current && d.current!==viewSeason){ switchSeason(d.current,true); return; } softRender(); }));
  dataSubs.push(B.watchColl('photos', m=>{ photos=m; softRender(); }));
  dataSubs.push(B.watchDoc(SEASON_PATH, d=>{ S=d? normalize(clone(d)) : (viewSeason===SEASON_ID? seed() : normalize({seasonId:viewSeason,fixtures:[],ties:{},published:{},official:{asOf:0,order:[]}})); softRender(); }));
  dataSubs.push(B.watchColl(SEASON_PATH+'/avail', m=>{ avail=m; softRender(); }));
  dataSubs.push(B.watchColl(SEASON_PATH+'/picks', m=>{ picks=m; softRender(); }));
  if(isAdmin){ dataSubs.push(B.watchColl(SEASON_PATH+'/ballots', m=>{ ballots=m; if(me) myBallot=m[me]||null; softRender(); }));
    dataSubs.push(B.watchColl(SEASON_PATH+'/availNotes', m=>{ notes=m; softRender(); }));
    dataSubs.push(B.watchDoc('private/phones', d=>{ phones=d?.map||{}; softRender(); })); }
  else if(me) dataSubs.push(B.watchDoc(SEASON_PATH+'/availNotes/'+me, d=>{ notes={[me]:d||{}}; softRender(); }));
}
function switchSeason(id,auto){ if(!auto) ui.seasonPicked=true; viewSeason=id; SEASON_PATH='seasons/'+id; avail={}; picks={}; ballots={}; notes={}; myBallot=null; ui.adminJ=null; ui.calJ=null; subscribeData(); watchMine(); render(); }
B.onAuth(async u=>{
  unsubAll(); dataSubs.forEach(x=>{ try{x()}catch(e){} }); dataSubs=[];
  authUser=u; me=null; isAdmin=false; adminSkip=false; claims={}; avail={}; picks={}; ballots={}; myBallot=null; S=seed();
  if(!u){ authReady=true; render(); return; }
  isAdmin=await B.isAdmin(u.email,u.uid);
  try{ await B.relink(); }catch(e){}
  subs.push(B.watchColl('claims', m=>{ claims=m; softRender(); }));
  let first=true;
  subs.push(B.watchDoc('users/'+u.uid, d=>{ const nm=d?.pid||null;
    if(nm!==me || first){ first=false; me=nm; subscribeData(); watchMine(); authReady=true; render(); } else softRender(); }));
});
lastRoute=route(); render();
